#!/bin/sh
echo Current version is `ls -l pkg/current | awk '{print $NF}'`
