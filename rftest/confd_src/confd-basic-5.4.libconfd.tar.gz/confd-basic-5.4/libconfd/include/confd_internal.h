
#ifndef _CONFD_INTERNAL_H
#define _CONFD_INTERNAL_H 1

#include <stdarg.h>

#ifndef HAVE_REGEX_H
#define HAVE_REGEX_H 0
#endif

#include "erl_interface.h"
#include "ei.h"

/* for confd_do_connect() */
#define CLIENT_CAPI         3
#define CLIENT_CDB          5
#define CLIENT_MAAPI        7
#define CLIENT_STREAM       8
#define CLIENT_EVENT_MGR   11
#define CLIENT_HA          17

#define IPC_PROTO_OK                      0
#define IPC_PROTO_BAD_VSN                 1
#define IPC_PROTO_BAD_SIZES               2
#define IPC_PROTO_WANT_CHALLENGE   (1 << 7)  // ORed with CLIENT_XXX


/* Used internally by confd_lib.c */
#define CONFD_TRANS_REPLY_OK               101
#define CONFD_TRANS_REPLY_ERROR            102
#define CONFD_DATA_REPLY_VALUE            103
#define CONFD_DATA_REPLY_OK               104
#define CONFD_DATA_REPLY_ERROR            105

#define get_int16(s) ((((unsigned char*)  (s))[0] << 8) | \
                      (((unsigned char*)  (s))[1]))


#define put_int16(i, s) {((unsigned char*)(s))[0] = ((i) >> 8) & 0xff; \
                        ((unsigned char*)(s))[1] = (i)         & 0xff;}



#define get_int32(s) ((((unsigned char*) (s))[0] << 24) | \
                      (((unsigned char*) (s))[1] << 16) | \
                      (((unsigned char*) (s))[2] << 8)  | \
                      (((unsigned char*) (s))[3]))

#define put_int32(i, s) {((char*)(s))[0] = (char)((i) >> 24) & 0xff; \
                         ((char*)(s))[1] = (char)((i) >> 16) & 0xff; \
                         ((char*)(s))[2] = (char)((i) >> 8)  & 0xff; \
                         ((char*)(s))[3] = (char)((i)        & 0xff);}



/* avoid warnings when passing u_int32_t to void * on 64-bit */
#define INT2VOID(i) ((void *)((uintptr_t)(i)))


#ifdef DISABLE_THREADS
#define PTHREAD_KEY_T                       void*
#define PTHREAD_MUTEX_T                     void*
#define PTHREAD_MUTEX_INITIALIZER           NULL
#define PTHREAD_KEY_CREATE(key, destructor)
#define PTHREAD_SETSPECIFIC(key, value)     ((key) = (value))
#define PTHREAD_GETSPECIFIC(key)            (key)
#define PTHREAD_MUTEX_INIT(mutex, attr)
#define PTHREAD_MUTEX_LOCK(mutex)           (*((char *)(mutex)) = 0)
#define PTHREAD_MUTEX_UNLOCK(mutex)
#define PTHREAD_MUTEX_DESTROY(mutex)
#define PTHREAD_SELF()                      0
#else
#include <pthread.h>
#define PTHREAD_KEY_T                       pthread_key_t
#define PTHREAD_MUTEX_T                     pthread_mutex_t
#define PTHREAD_KEY_CREATE                  pthread_key_create
#define PTHREAD_SETSPECIFIC                 pthread_setspecific
#define PTHREAD_GETSPECIFIC                 pthread_getspecific
#define PTHREAD_MUTEX_INIT                  pthread_mutex_init
#define PTHREAD_MUTEX_LOCK                  pthread_mutex_lock
#define PTHREAD_MUTEX_UNLOCK                pthread_mutex_unlock
#define PTHREAD_MUTEX_DESTROY               pthread_mutex_destroy
#define PTHREAD_SELF                        pthread_self
#endif  /* DISABLE_THREADS */


/* we can send the following ha orders to confd */
enum confd_ha_order_type {
    CONFD_HA_ORDER_BEMASTER   = 1,
    CONFD_HA_ORDER_BESLAVE    = 2,
    CONFD_HA_ORDER_BENONE     = 3,  /* back to initial state */
    CONFD_HA_ORDER_GETSTATUS  = 4,
    CONFD_HA_ORDER_SLAVE_DEAD = 5,
    CONFD_HA_ORDER_BERELAY    = 6
};

struct named_type {
    char *name;
    struct confd_type *type;
};

struct schema {
    u_int32_t nshash;
    const char *uri;
    const char *prefix;
    const char *revision;
    struct confd_cs_node *root;
    int loaded;
    struct named_type *types;
    int num_types;
};


#ifdef __GNUC__
#define PRINTF(F,A) __attribute__ ((format (printf, F, A)))
#else
#define PRINTF(F,A)
#endif

extern void confd_printf(int syslogprio, const char  *fmt, ...) PRINTF(2,3);
extern void confd_trace_printf(const char  *fmt, ...) PRINTF(1,2);
extern char *format_path(int isrel, const ETERM *path);
extern int confd_snprintf(char *dst, int n, char *format, ...) PRINTF(3,4) ;
extern void init_pkeys(void);
extern int ret_errno_err(const char *fmt, ...) PRINTF(1,2);
extern void *ret_null(const char *fmt, ...) PRINTF(1,2);
extern int ret_err(int ecode, const char *fmt, ...) PRINTF(2,3);
extern int ret_confd_errno_err(int ecode, const char *fmt, ...) PRINTF(2,3);
extern  int read_fill(int fd, unsigned char *buf, int len);
extern int confd_write(int socket, const unsigned char *buf, int len);
extern void term_to_ip4(struct in_addr *ip, const ETERM *term);
extern ETERM *ip4_to_term(const struct in_addr *ip);
extern void term_to_ip6(struct in6_addr *ip6, const ETERM *term);
extern ETERM *ip6_to_term(const struct in6_addr *ip6);
extern  confd_value_t *eterm_to_val(const ETERM *term, confd_value_t *v);
extern confd_tag_value_t *eterm_to_tag_val(const ETERM *term,
                                           confd_tag_value_t *tv);
extern int etermlist_to_vals(ETERM *list, confd_value_t *vp, int n);
extern int etermlist_to_tag_vals(ETERM *list, confd_tag_value_t *tvp, int n);
extern void confd_free_eterm_val(confd_value_t *v);
extern void confd_free_eterm_keypath(confd_hkeypath_t *kp);
extern  void confd_trace(enum confd_debug_level level,
                         const char  *fmt, ...) PRINTF(2,3);
extern void v_config_trace(enum confd_debug_level level,const char  *fmt,
                           va_list args);

extern int confd_do_connect(int sock, const struct sockaddr *srv, int srv_sz,
                            int id);
extern void *ret_errno_err_null(const char *fmt, ...) PRINTF(1,2);
extern int op_write(int socket,unsigned cdbop, int thandle);
extern int op_write_buf(int socket,unsigned int op,const char *xbuf,
                        int xlen,int thandle);
extern int term_write(int socket, const ETERM *term,
                      unsigned int cdbop, int thandle);
extern ETERM *term_read(int socket, int *ret, unsigned int cdbop);
extern ETERM *confd_call(int socket, const ETERM *term, int *status);

extern unsigned char *confd_memdup(const unsigned char* p, int n);
extern void *confd_malloc(size_t sz);
extern void confd_set_errno(int ecode);
extern void confd_set_lasterr(const char *fmt, ...) PRINTF(1,2);
extern void confd_vset_lasterr(const char *fmt, va_list args);
extern void clr_confd_err(void);
extern confd_value_t *confd_value_dup_to_mallf(const confd_value_t *v,
                                               confd_value_t *newv,
                                               void *(*mallf)(size_t size),
                                               void (*freef)(void *ptr));

extern int confd_fpp_kpath(FILE *stream, const confd_hkeypath_t *hkeypath);
extern void confd_register_schemas(struct schema *new, int num_new,
                                   int num_loaded, int mmapped);
extern int confd_check_init(void);

/* Note there is zero count on these */
#define TE(_r,_p) ERL_TUPLE_ELEMENT((_r), (_p))
#define TUINT(_res, _pos) ERL_INT_UVALUE(ERL_TUPLE_ELEMENT((_res), (_pos)))
#define TINT(_res, _pos) ERL_INT_VALUE(ERL_TUPLE_ELEMENT((_res), (_pos)))
#define TZONE(_res, _pos) ERL_IS_NIL(TE(_res,_pos)) ? \
                             CONFD_TIMEZONE_UNDEF : TINT(_res, _pos)

extern FILE *confd_debug_stream;
extern enum confd_debug_level confd_debug_level;
extern char confd_daemon_name[64];
extern int confd_version;

/* thread-safe maapi_load_schemas() - initialized by confd_init() */
extern PTHREAD_MUTEX_T maapi_load_schemas_lock;

/* populated by maapi_load_schemas(), accessed by confd_lib */
extern struct hashtable *hash2str_tab;
extern struct hashtable *str2hash_tab;
extern int confd_hashtables_mmapped;

/* for IPC access check - initialized by confd_init() */
extern unsigned char *confd_ipc_access_secret;

/* needed by load_schemas with shm */
enum confd_vtype_extra {
    CE_INET_ADDRESS = C_MAXTYPE + 1,
    CE_INET_ADDRESS_IP,
    CE_IPPREFIX,
    CE_IP_AND_PLEN,
    CE_SIZE,
    CE_HEX_LIST,
    CE_OCTET_LIST,
    CE_BASE64_BINARY,
    CE_NORMALIZED_STRING,
    CE_TOKEN,
    CE_LANGUAGE,
    CE_NMTOKEN,
    CE_NAME,
    CE_NCNAME,
    CE_NMTOKEN_LIST,
    CE_NMTOKENS,
    CE_IDREF_LIST,
    CE_IDREFS,
    CE_NON_POSITIVE_INTEGER,
    CE_NEGATIVE_INTEGER,
    CE_NON_NEGATIVE_INTEGER,
    CE_POSITIVE_INTEGER,
    CE_NO_TYPE,
    CE_MAXTYPE
};
extern struct confd_type confd_types[CE_MAXTYPE];

typedef enum confd_iter_ret (confd_diff_iter_function_t)(confd_hkeypath_t *kp,
                                                         enum confd_iter_op op,
                                                         confd_value_t *oldv,
                                                         confd_value_t *newv,
                                                         void *state);

typedef enum confd_iter_ret (confd_iter_function_t)(
    confd_hkeypath_t *kp,
    confd_value_t *v,
    confd_attr_value_t *attr_vals,
    int num_attr_vals,
    void *state);

/* functions used by both CDB and maapi */

extern ETERM  *op_request_term(int sock, int op, int thandle, int isrel,
                               const ETERM *arg, int *status);

extern int request_int(int sock, unsigned int op, int thandle,
                       const char *fmt, va_list args);


extern void request_v(int sock, unsigned int op, int thandle,
                      int *status, confd_value_t *v, const char *fmt,
                      va_list args);

extern int fmt_request(int sock, unsigned int op, int thandle,
                       const char *fmt, va_list args);

extern void arg_request(int sock, unsigned int op, int thandle, int *status,
                        int isrel, confd_value_t *v, const ETERM *arg);

extern int pp_keyval(char *buf, int n, const confd_value_t *v, int ns);
extern int substitute_percent(const char *src, char *dst, int dstsz,
                              va_list args, int skip_keys);
extern ETERM *parse_path(int *isrel, const char *fmt, va_list args);
extern ETERM *mk_tag_elem2(const char *tagstr);
extern ETERM *_confd_parse_choice_path(const char *path);
extern ETERM *val_to_term(const confd_value_t *v);
extern ETERM *vals_to_termlist(const confd_value_t *vp, int n, int ret_tup);
extern ETERM *tag_vals_to_termlist(const confd_tag_value_t *vp, int n,
                                   int ret_tup);
extern int bin_copy(char *buf, int n, const ETERM *b);
extern int bin_eq(const ETERM *b, char *s2);
extern char *bin_dup(const ETERM *b);
extern int erl_is_initialized;
extern int check_vsn_reply(int);
extern int populate_keypath(const ETERM *kp, confd_hkeypath_t *args);
extern int confd_dup_value(confd_value_t *v);
extern void confd_fprintf(int syslogprio, FILE *stream,
                          const char  *fmt, ...) PRINTF(3,4);
extern void confd_report_err(enum confd_debug_level level,
                             const char  *fmt, ...) PRINTF(2,3);
extern void confd_fatal_log(const char *fmt, ...) PRINTF(1,2);
extern int confd_internal_error(const char *fmt, ...) PRINTF(1,2);

extern int _confd_iterate_send_reply(int sock, int uret);
extern int _confd_iterate(int sock, int accept_iter_suspend,
                          void *iter_function, void *initstate);

extern ETERM *hkeypath_to_eterm(confd_hkeypath_t *hkp);
extern int confd_val_num_cmp(const confd_value_t *v1, const confd_value_t *v2);
extern void confd_clear_hkeypath(confd_hkeypath_t *hkp);

extern int _confd_vset_error(
    struct confd_error *error,
    enum confd_errcode code,
    u_int32_t apptag_ns, u_int32_t apptag_tag,
    const confd_tag_value_t *error_info, int n, int flags,
    const char *fmt, va_list args);
extern ETERM *_confd_make_error(struct confd_error *error);

extern char *_confd_op2str(int op);

extern void _confd_mk_uinfo(const ETERM *utup, struct confd_user_info *uinfo);

#undef PRINTF

#endif
