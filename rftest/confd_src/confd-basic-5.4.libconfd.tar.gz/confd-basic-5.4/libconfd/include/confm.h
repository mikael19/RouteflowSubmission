/*
 * Copyright 2007 Tail-F Systems AB
 */

#ifndef _CONFM_H
#define _CONFM_H 1

#ifdef __cplusplus
extern "C" {
#endif


int confm_backlog_set(int msock, struct confd_trans_ctx *tctx,
                      confd_hkeypath_t *keypath,
                      confd_value_t *vp,
                      int devno,
                      enum device_type type);

int confm_backlog_set2(int msock, struct confd_trans_ctx *tctx,
                       confd_hkeypath_t *keypath,
                       char *strval,
                       int devno,
                       enum device_type type);

int confm_backlog_create(int msock, struct confd_trans_ctx *tctx,
                         confd_hkeypath_t *keypath,
                         int devno,
                         enum device_type type);

int confm_backlog_delete(int msock, struct confd_trans_ctx *tctx,
                         confd_hkeypath_t *keypath,
                          int devno,
                         enum device_type type);

int confm_safe_set_elem(int msock, struct confd_trans_ctx *tctx,
                        confd_hkeypath_t *keypath,
                        confd_value_t *v,
                        int devno,
                        enum device_type type,
                        const char *fmt, ...);
int confm_safe_set_elem2(int msock, struct confd_trans_ctx *tctx,
                         confd_hkeypath_t *keypath,
                         char *strval,
                         int devno,
                         enum device_type type,
                         const char *fmt, ...);
int confm_safe_create(int msock, struct confd_trans_ctx *tctx,
                      confd_hkeypath_t *keypath,
                      int devno,
                      enum device_type type,
                      const char *fmt, ...);

int confm_safe_delete(int msock, struct confd_trans_ctx *tctx,
                      confd_hkeypath_t *keypath,
                      int devno,
                      enum device_type type,
                      const char *fmt, ...);

int confm_device_up(int msock, int deviceno, enum device_type type);


#ifdef __cplusplus
}
#endif
#endif
