/*
 * Copyright 2005-2011 Tail-F Systems AB
 */

#ifndef _CONFD_H
#define _CONFD_H 1

#include <confd_lib.h>
#include <confd_dp.h>
#include <confd_events.h>
#include <confd_ha.h>

#endif
