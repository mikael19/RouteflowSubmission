
/*
 * Copyright 2008 Tail-F Systems AB
 *
 * Support for user-defined types - callbacks for
 * string <-> value conversion in shared objects that
 * get loaded into confd (along with libconfd.so..)
 */

#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include <unistd.h>
#include <dlfcn.h>

#include "erl_nif.h"
#include "confd_lib.h"
#include "confd_internal.h"
#include "confd_proto.h"

#ifdef __NetBSD__
/* This becomes set to 1 when we load libconfd - if it was 0 originally, we
   need to poke it back to 0 or malloc() and other libc funcs will call
   abort() (we don't use threads here, and the runtime may or may not have
   been built with threads, but libconfd was likely built with -lpthread).  */
extern int __isthreaded;
#endif

#define LIBCONFD "libconfd.so"

/* atoms which are returned to erlang */
static ERL_NIF_TERM am_ok;
static ERL_NIF_TERM am_error;
static ERL_NIF_TERM am_internal;
static ERL_NIF_TERM am_external;
static ERL_NIF_TERM am_application;
static ERL_NIF_TERM am_undefined;

static void initialize_local_atoms(ErlNifEnv* env)
{
    am_ok          = enif_make_atom(env, "ok");
    am_error       = enif_make_atom(env, "error");
    am_internal    = enif_make_atom(env, "internal");
    am_external    = enif_make_atom(env, "external");
    am_application = enif_make_atom(env, "application");
    am_undefined   = enif_make_atom(env, "undefined");
}

#define atom(name) enif_make_copy(env, am_ ## name)

#define BUFLEN 256

struct sodata {
    char *soname;
    void *handle;
};
struct cbdata {
    int so;
    struct confd_type_cbs cbs;
    ERL_NIF_TERM atom_typepoint;
};
struct sysdata {
    int nsos;
    struct sodata *so;
    int ncbs;
    struct cbdata *cb;
};

static ErlNifEnv *myenv;
static int inited;
static struct sysdata sys;
static struct sysdata saved_sys;


#ifdef __GNUC__
typedef typeof(erl_init) erl_init_t;
typedef typeof(erl_decode) erl_decode_t;
typedef typeof(erl_encode) erl_encode_t;
typedef typeof(erl_term_len) erl_term_len_t;
typedef typeof(erl_free_compound) erl_free_compound_t;
typedef typeof(eterm_to_val) eterm_to_val_t;
typedef typeof(val_to_term) val_to_term_t;
typedef typeof(confd_free_value) confd_free_value_t;
typedef typeof(confd_free_eterm_val) confd_free_eterm_val_t;
typedef typeof(confd_type_cb_init) confd_type_cb_init_t;
#else
/* typeof() is gcc special - without it, you have to do something
   like this, and don't get prototype verification. But if it works
   to compile this file with gcc, the actual usage is right, and
   then you will get an error for non-gcc if these are wrong... */
typedef void erl_init_t(void *x, long y);
typedef ETERM *erl_decode_t(unsigned char*);
typedef int erl_encode_t(ETERM*,unsigned char*t);
typedef int erl_term_len_t(ETERM*);
typedef void erl_free_compound_t(ETERM*);
typedef confd_value_t *eterm_to_val_t(const ETERM *term, confd_value_t *v);
typedef ETERM *val_to_term_t(const confd_value_t *v);
typedef void confd_free_value_t(confd_value_t *v)
typedef void confd_free_eterm_val_t(confd_value_t *v)
typedef int confd_type_cb_init_t(struct confd_type_cbs **);
#endif

static erl_decode_t *erl_decode_p;
static erl_encode_t *erl_encode_p;
static erl_term_len_t *erl_term_len_p;
static erl_free_compound_t *erl_free_compound_p;
static eterm_to_val_t *eterm_to_val_p;
static val_to_term_t *val_to_term_p;
static confd_free_value_t *confd_free_value_p;
static confd_free_eterm_val_t *confd_free_eterm_val_p;


static ERL_NIF_TERM mkbin(ErlNifEnv *env, char *bin, int len)
{
    ERL_NIF_TERM eb;
    unsigned char *data = enif_make_new_binary(env, len, &eb);
    memcpy(data, bin, len);
    return eb;
}

/* return {error, Binary} */
static ERL_NIF_TERM mkerr2(ErlNifEnv *env, char *fmt, ...)
{
    va_list args;
    char buf[BUFLEN];
    ERL_NIF_TERM str;

    va_start(args, fmt);
    vsnprintf(buf, sizeof(buf), fmt, args);
    va_end(args);
    str = mkbin(env, buf, strlen(buf));
    return enif_make_tuple2(env, atom(error), str);
}

/* return {error, Code, Binary|undefined} */
static ERL_NIF_TERM mkerr3(ErlNifEnv *env, ERL_NIF_TERM code, char *fmt, ...)
{
    va_list args;
    char buf[BUFLEN];
    ERL_NIF_TERM str;

    if (fmt != NULL) {
        va_start(args, fmt);
        vsnprintf(buf, sizeof(buf), fmt, args);
        va_end(args);
        str = mkbin(env, buf, strlen(buf));
    } else {
        str = atom(undefined);
    }
    return enif_make_tuple3(env, atom(error), code, str);
}

#define DLSYM(sym) do {                                         \
        if ((sym ## _p = dlsym(handle, #sym)) == NULL) {        \
            return mkerr2(env, "dlsym: %s", dlerror());         \
        }                                                       \
    } while (0)

/* init() -> ok | {error, Msg::binary()} */
static ERL_NIF_TERM init(ErlNifEnv *env, int argc, const ERL_NIF_TERM argv[])
{
    void *handle;
    erl_init_t *erl_init_p;
    enum confd_debug_level *confd_debug_level_p;
    int *confd_lib_use_syslog_p;
#ifdef __NetBSD__
    int save_isthr = __isthreaded;
#endif

    if (inited)
        return atom(ok);
    if ((handle = dlopen(LIBCONFD, RTLD_LOCAL|RTLD_LAZY)) == NULL) {
        return mkerr2(env, "dlopen: %s", dlerror());
    }
#ifdef __NetBSD__
    __isthreaded = save_isthr;
#endif
    DLSYM(erl_init);
    DLSYM(erl_decode);
    DLSYM(erl_encode);
    DLSYM(erl_term_len);
    DLSYM(erl_free_compound);
    DLSYM(eterm_to_val);
    DLSYM(val_to_term);
    DLSYM(confd_free_value);
    DLSYM(confd_free_eterm_val);
    DLSYM(confd_debug_level);
    DLSYM(confd_lib_use_syslog);
    (*erl_init_p)(NULL, 0);
    *confd_debug_level_p = CONFD_SILENT;
    *confd_lib_use_syslog_p = 0;
    inited = 1;

    return atom(ok);
}

/* caller ensures non-concurrent */
/* load(Sofile::iolist()) -> ok | {error, Msg::binary()} */
static ERL_NIF_TERM load(ErlNifEnv *env, int argc, const ERL_NIF_TERM argv[])
{
    ErlNifBinary filebin;
    char *sofile;
    void *handle;
    confd_type_cb_init_t *confd_type_cb_init_p;
    int ncbs;
    struct confd_type_cbs *cbs;
    int i;

    if (!inited)
        return mkerr2(env, "not initialized");
    if (!enif_inspect_iolist_as_binary(env, argv[0], &filebin))
        return enif_make_badarg(env);
    sofile = enif_alloc(filebin.size + 1);
    memcpy(sofile, filebin.data, filebin.size);
    sofile[filebin.size] = '\0';
    if ((handle = dlopen(sofile, RTLD_LOCAL|RTLD_LAZY)) == NULL) {
        enif_free(sofile);
        return mkerr2(env, "dlopen: %s", dlerror());
    }
    DLSYM(confd_type_cb_init);
    cbs = NULL;
    if ((ncbs = (*confd_type_cb_init_p)(&cbs)) <= 0) {
        enif_free(sofile);
        return mkerr2(env, "confd_type_cb_init() returned %d", ncbs);
    }
    if (cbs == NULL) {
        enif_free(sofile);
        return mkerr2(env, "confd_type_cb_init() returned NULL cb ptr");
    }
    sys.so = enif_realloc(sys.so, (sys.nsos + 1) * sizeof(struct sodata));
    sys.so[sys.nsos].soname = sofile;
    sys.so[sys.nsos].handle = handle;
    sys.cb = enif_realloc(sys.cb, (sys.ncbs + ncbs) * sizeof(struct cbdata));
    for (i = 0; i < ncbs; i++) {
        if (cbs[i].typepoint == NULL) {
            return mkerr2(env, "missing typepoint");
        }
        if (cbs[i].type == NULL ||
            cbs[i].type->str_to_val == NULL ||
            cbs[i].type->val_to_str == NULL ||
            cbs[i].type->validate == NULL) {
            return mkerr2(env, "%s: missing callback(s)", cbs[i].typepoint);
        }
        sys.cb[sys.ncbs + i].so = sys.nsos;
        sys.cb[sys.ncbs + i].cbs = cbs[i];
        sys.cb[sys.ncbs + i].atom_typepoint =
            enif_make_atom(myenv, cbs[i].typepoint);
    }
    sys.ncbs += ncbs;
    sys.nsos++;

    return atom(ok);
}

static void free_sys(struct sysdata *sys)
{
    int i;

    if (sys->so != NULL) {
        for (i = 0; i < sys->nsos; i++) {
            enif_free(sys->so[i].soname);
            dlclose(sys->so[i].handle);
        }
        enif_free(sys->so);
    }
    if (sys->cb != NULL)
        enif_free(sys->cb);
    memset(sys, 0, sizeof(struct sysdata));
}

/* caller ensures non-concurrent */
/* save_state() -> ok */
static ERL_NIF_TERM save_state(ErlNifEnv *env, int argc,
                               const ERL_NIF_TERM argv[])
{
    saved_sys = sys;
    memset(&sys, 0, sizeof(struct sysdata));
    return atom(ok);
}

/* caller ensures non-concurrent */
/* clean_state() -> ok */
static ERL_NIF_TERM clean_state(ErlNifEnv *env, int argc,
                                const ERL_NIF_TERM argv[])
{
    free_sys(&sys);
    return atom(ok);
}

/* caller ensures non-concurrent */
/* clean_saved(SavedSystemState::term()) -> ok (Arg ignored) */
static ERL_NIF_TERM clean_saved(ErlNifEnv *env, int argc,
                                const ERL_NIF_TERM argv[])
{
    free_sys(&saved_sys);
    return atom(ok);
}

/* caller ensures non-concurrent */
/* clean_saved(SavedSystemState::term()) -> ok (Arg ignored) */
static ERL_NIF_TERM restore_saved(ErlNifEnv *env, int argc,
                                  const ERL_NIF_TERM argv[])
{
    clean_state(env, argc, argv);
    sys = saved_sys;
    memset(&saved_sys, 0, sizeof(struct sysdata));
    return atom(ok);
}

/* typepoints() -> [{Point::atom(), File::binary()}] */
static ERL_NIF_TERM typepoints(ErlNifEnv *env, int argc,
                               const ERL_NIF_TERM argv[])
{
    ERL_NIF_TERM tps[sys.ncbs];
    int i;

    for (i = 0; i < sys.ncbs; i++) {
        char *soname = sys.so[sys.cb[i].so].soname;
        ERL_NIF_TERM typepoint = sys.cb[i].atom_typepoint;
        tps[i] = enif_make_tuple2(env,
                                  enif_make_copy(env, typepoint),
                                  mkbin(env, soname, strlen(soname)));
    }
    return enif_make_list_from_array(env, tps, sys.ncbs);
}

static struct confd_type *find_type(ErlNifEnv *env, ERL_NIF_TERM typepoint,
                                    ERL_NIF_TERM *errp)
{
    int i;

    for (i = 0; i < sys.ncbs; i++) {
        if (enif_compare(sys.cb[i].atom_typepoint, typepoint) == 0)
            return sys.cb[i].cbs.type;
    }
    *errp = mkerr3(env, atom(internal), "no callbacks found for typepoint");
    return NULL;
}

/* FIXME rewrite this to build and consume ERL_NIF_TERMs directly
   instead of via ETERM and erl_{de|en}code(), i.e. replacements
   for libconfd's val_to_term() and eterm_to_val() - more efficient
   and getting rid of the libconfd dependency altogether (not so
   good if we add more types, though).                           */

/* string2value(Typepoint::atom(), String::iolist()) ->
      {ok, Value::binary()} | {error, Code::atom(), Msg::binary()|undefined} */
static ERL_NIF_TERM string2value(ErlNifEnv *env, int argc,
                                 const ERL_NIF_TERM argv[])
{
    ERL_NIF_TERM typepoint = argv[0];
    ErlNifBinary string;
    struct confd_type *type;
    ERL_NIF_TERM ret;
    struct confd_type_ctx ctx = {NULL, 0, NULL};
    confd_value_t v;
    ETERM *term;
    int len;
    unsigned char *value_data;
    ERL_NIF_TERM value;

    if (!inited)
        return mkerr3(env, atom(internal), "not initialized");
    if (!enif_inspect_iolist_as_binary(env, argv[1], &string))
        return enif_make_badarg(env);
    if ((type = find_type(env, typepoint, &ret)) == NULL)
        return ret;
    len = string.size - 1;      /* don't include the NUL */
    if (type->str_to_val(type, &ctx, (char *)string.data, len, &v)) {
        switch (v.type) {
        case C_NOEXISTS:
        case C_DEFAULT:
        case C_XMLTAG:
            /* value allowed by val_to_term() but not here */
            term = NULL;
            break;
        default:
            term = (*val_to_term_p)(&v);
        }
        (*confd_free_value_p)(&v);
        if (term == NULL) {
            ret = mkerr3(env, atom(external),
                        "bad value returned by str_to_val");
        } else {
            len = (*erl_term_len_p)(term);
            value_data = enif_make_new_binary(env, len, &value);
            if ((*erl_encode_p)(term, value_data) == 0) {
                ret = mkerr3(env, atom(internal), "failed to encode value");
            } else {
                ret = enif_make_tuple2(env, atom(ok), value);
            }
            (*erl_free_compound_p)(term);
        }
    } else {
        if (ctx.errstr != NULL) {
            ret = mkerr3(env, atom(application), "%s", ctx.errstr);
            free(ctx.errstr);
        } else {
            ret = mkerr3(env, atom(application), NULL);
        }
    }
    return ret;
}

static ETERM *decode_value(ErlNifEnv *env, unsigned char *buf,
                           confd_value_t *v, ERL_NIF_TERM *errp)
{
    ETERM *term;

    if ((term = (*erl_decode_p)(buf)) == NULL ||
        (*eterm_to_val_p)(term, v) == NULL) {
        *errp = mkerr3(env, atom(internal), "failed to decode value");
        if (term != NULL)
            (*erl_free_compound_p)(term);
        term = NULL;
    }
    return term;
}

static ERL_NIF_TERM do_val_to_str(ErlNifEnv *env, struct confd_type *type,
                                  struct confd_type_ctx *ctx, confd_value_t *v)
{
    int len;
    char buf[BUFLEN];
    unsigned char *bufp;
    ERL_NIF_TERM term;

    len = type->val_to_str(type, ctx, v, buf, sizeof(buf), NULL);
    if (len >= 0) {
        if (len < sizeof(buf)) {
            term = mkbin(env, buf, len);
        } else {
            bufp = enif_make_new_binary(env, len + 1, &term);
            type->val_to_str(type, ctx, v, (char *)bufp, len + 1, NULL);
            term = enif_make_sub_binary(env, term, 0, len);
        }
        return enif_make_tuple2(env, atom(ok), term);
    }
    if (ctx->errstr != NULL) {
        term = mkerr3(env, atom(application), "%s", ctx->errstr);
        free(ctx->errstr);
    } else {
        term = mkerr3(env, atom(application), NULL);
    }
    return term;
}

/* value2string(Typepoint::atom(), Value::binary())
     {ok, String::binary()} | {error, Code::atom(), Msg::binary()|undefined} */
static ERL_NIF_TERM value2string(ErlNifEnv *env, int argc,
                                 const ERL_NIF_TERM argv[])
{
    ERL_NIF_TERM typepoint = argv[0];
    ErlNifBinary value;
    struct confd_type *type;
    ETERM *term;
    confd_value_t v;
    struct confd_type_ctx ctx = {NULL, 0, NULL};
    ERL_NIF_TERM ret;

    if (!inited)
        return mkerr3(env, atom(internal), "not initialized");
    if (!enif_inspect_iolist_as_binary(env, argv[1], &value))
        return enif_make_badarg(env);
    if ((type = find_type(env, typepoint, &ret)) != NULL &&
        (term = decode_value(env, value.data, &v, &ret)) != NULL) {
        ret = do_val_to_str(env, type, &ctx, &v);
        (*confd_free_eterm_val_p)(&v);
        (*erl_free_compound_p)(term);
    }
    return ret;
}

/* value2string(Typepoint::atom(), Value::binary())
     {ok, String::binary()} | {error, Code::atom(), Msg::binary()|undefined} */
static ERL_NIF_TERM check_value(ErlNifEnv *env, int argc,
                                const ERL_NIF_TERM argv[])
{
    ERL_NIF_TERM typepoint = argv[0];
    ErlNifBinary value;
    struct confd_type *type;
    ETERM *term;
    confd_value_t v;
    struct confd_type_ctx ctx = {NULL, 0, NULL};
    ERL_NIF_TERM ret;

    if (!inited)
        return mkerr3(env, atom(internal), "not initialized");
    if (!enif_inspect_iolist_as_binary(env, argv[1], &value))
        return enif_make_badarg(env);
    if ((type = find_type(env, typepoint, &ret)) != NULL &&
        (term = decode_value(env, value.data, &v, &ret)) != NULL) {
        if (type->validate(type, &ctx, &v)) {
            /* confd wants the string in the return value */
            ret = do_val_to_str(env, type, &ctx, &v);
        } else {
            if (ctx.errstr != NULL) {
                ret = mkerr3(env, atom(application), "%s", ctx.errstr);
                free(ctx.errstr);
            } else {
                ret = mkerr3(env, atom(application), NULL);
            }
        }
        (*confd_free_eterm_val_p)(&v);
        (*erl_free_compound_p)(term);
    }
    return ret;
}


static ErlNifFunc nif_funcs[] = {
    {"utype_init", 0, init},
    {"load_usertype_object", 1, load},
    {"save_system_state", 0, save_state},
    {"clean_system_state", 0, clean_state},
    {"clean_saved_system_state", 1, clean_saved},
    {"utype_restore_saved", 0, restore_saved},
    {"utype_typepoints", 0, typepoints},
    {"utype_string2value", 2, string2value},
    {"utype_value2string", 2, value2string},
    {"utype_check_value", 2, check_value}
};

static int atload(ErlNifEnv* env, void** priv_data, ERL_NIF_TERM load_info)
{
    int i;

    if (!enif_get_int(env, load_info, &i) || i != 0)
        return -1;
    myenv = enif_alloc_env();
    initialize_local_atoms(myenv);
    return 0;
}

static int reload(ErlNifEnv* env, void** priv_data, ERL_NIF_TERM load_info)
{
    /* allow and ignore */
    return 0;
}

ERL_NIF_INIT(capi, nif_funcs, atload, reload, NULL, NULL);
