#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#if HAVE_REGEX_H
#include <regex.h>
#endif

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include "confd_lib.h"
#include "confd_internal.h"
#include "confd_type.h"

#define BIT_IS_SET(f,fs) ((fs) & (f)) != 0
#define CONFD_ISASCII(c) (((c) & ~0x7f) == 0)
#define HEX_TO_VAL(c) (((c) >= '0' && (c) <= '9') ? (c) - '0' :         \
                       ((c) >= 'A' && (c) <= 'F') ? (c) - 'A' + 10 :    \
                       ((c) >= 'a' && (c) <= 'f') ? (c) - 'a' + 10 : -1)
#define VAL_TO_HEX(n) ((n) < 10 ? (n) + '0' : (n) - 10 + 'a')
#define VAL_TO_HEX_UPPER(n) ((n) < 10 ? (n) + '0' : (n) - 10 + 'A')

/*
 * General pointer advancer when doing snprint style
 * of printing
 */
#define ADVANCE_PTR(bp, size, len)              \
    do {                                        \
        bp += len;                              \
        if (len < size) {                       \
            size -= len;                        \
        } else {                                \
            size = 0;                           \
        }                                       \
    } while (0)

/*
 * Value of types:
 *   C_BUF, C_BINARY, C_HEXSTR, or C_LIST
 * has to be dynamically allocated
 *
 * All val_to_str returns as snprintf: Upon successful return, these
 * functions return the number of characters output (not including the
 * trailing '\0' used to end out-put to strings).
 *
 * The val_to_str functions do not write more than size bytes
 * (including the trailing '\0').  If the output was truncated due to
 * this limit then the return value is the number of characters (not
 * including the trailing '\0') which would have been written to the
 * final string if enough space had been available.  Thus, a return
 * value of size or more means that the output was truncated.
 *
 * If an output error is encountered, a -1 value is returned.
 */


static int confd_derived_str_to_val(struct confd_type *self,
                                  struct confd_type_ctx *ctx,
                                  const char *str, unsigned int len,
                                  struct confd_value *v)
{
    if (self->parent == NULL) {
        return CONFD_FALSE;
    }

    // first parse (fill in *v) and validate parent
    if (!self->parent->str_to_val(self->parent, ctx, str, len, v)) {
        return CONFD_FALSE;
    }
    // then call our validate with the filled in v
    if (self->validate(self, ctx, v) == CONFD_FALSE) {
        confd_free_value(v);
        return CONFD_FALSE;
    }
    return CONFD_TRUE;
}

static int confd_derived_val_to_str(struct confd_type *self,
                                  struct confd_type_ctx *ctx,
                                  const struct confd_value *v,
                                  char *str, unsigned int size,
                                  const char **strp)
{
    if (self->parent == NULL) {
        return -1;
    }

    // call parent's val_to_str with ref to parent's type
    return self->parent->val_to_str(self->parent, ctx, v, str, size, strp);
}

static int confd_derived_validate(struct confd_type *self,
                                struct confd_type_ctx *ctx,
                                const struct confd_value *v)
{
    if (self->parent == NULL) {
        return CONFD_FALSE;
    }

    // call parent's validate with ref to parent's type
    return self->parent->validate(self->parent, ctx, v);
}

/* initializes a struct confd_type */
void confd_type_init_type(struct confd_type *type)
{
    struct confd_type *p = type->parent;

#if 0 /* this is OK and will save some processing when we *never*
         have "unsupported" types - see maapi.c/get_type() */
    if (!p) {
        return;
    }
    if (p->parent) {
        confd_type_init_type(p);
    }
#endif

    if (p != NULL) {
        confd_type_init_type(p);
    }
    if (!type->str_to_val) {
        type->str_to_val = confd_derived_str_to_val;
    }
    if (!type->val_to_str) {
        type->val_to_str = confd_derived_val_to_str;
    }
    if (!type->validate) {
        type->validate = confd_derived_validate;
    }
}

/* This does only the "outer" part of 'whiteSpace value="collapse"',
   and returns CONFD_FALSE if there is *any* "internal" whitespace
   (CONFD_TRUE otherwise). Use it for types that should have
   "collapse" but don't allow any "internal" whitespace. */
static int ws_collapse_validate(const char *str, unsigned int len,
                                const char **start, const char **end)
{
    const char *cp = str;
    const char *ep = str + len;
    const char *cpp;

    while (cp < ep && isspace(*cp)) {
        cp++;
    }
    while (ep > cp && isspace(*(ep-1))) {
        ep--;
    }
    for (cpp = cp; cpp < ep; cpp++) {
        if (isspace(*cpp)) {
            return CONFD_FALSE;
        }
    }
    *start = cp;
    *end = ep;
    return CONFD_TRUE;
}

static int tz_to_str(char *tz, unsigned int size, int8_t timezone,
                     int8_t timezone_minutes)
{
    if (timezone != CONFD_TIMEZONE_UNDEF) {
        if (timezone == 0 && timezone_minutes == 0) {
            return snprintf(tz, size, "Z");
        } else if (timezone > 0 || (timezone == 0 && timezone_minutes >= 0)) {
            return snprintf(tz, size, "+%02d:%02d", timezone, timezone_minutes);
        } else {
            timezone = -timezone;
            if (timezone_minutes < 0)
                timezone_minutes = -timezone_minutes;
            return snprintf(tz, size, "-%02d:%02d", timezone, timezone_minutes);
        }
    } else {
        if (size > 0) {
            tz[0] = '\0';
        }
        return 0;
    }
}

/* yang:date-and-time differs from xs:date/xs:time */
static int dt_tz_to_str(char *tz, unsigned int size, int8_t timezone,
                        int8_t timezone_minutes)
{
    if (timezone != CONFD_TIMEZONE_UNDEF) {
        if (timezone > 0 || (timezone == 0 && timezone_minutes >= 0)) {
            return snprintf(tz, size, "+%02d:%02d", timezone, timezone_minutes);
        } else {
            timezone = -timezone;
            if (timezone_minutes < 0)
                timezone_minutes = -timezone_minutes;
            return snprintf(tz, size, "-%02d:%02d", timezone, timezone_minutes);
        }
    } else {
        return snprintf(tz, size, "-00:00");
    }
}

static int us_to_str(char *us, unsigned int size, uint32_t micro)
{
    if (micro != 0) {
        return snprintf(us, size, ".%06d", micro);
    } else {
        if (size > 0) {
            us[0] = '\0';
        }
        return 0;
    }
}

/* Parse an unsigned long into 3 fields.
 * Returns the number of significant digits in the number or
 * -1 if overflow of the capacity or
 * -2 if not an integer
 */
static int confd_parse_uint(const char **str, const char *str_end,
                          unsigned long *llo,
                          unsigned long *lmi, unsigned long *lhi)
{
    unsigned long lo = 0, mi = 0, hi = 0;
    const char *sp, *ep;
    int i = 0;

    sp = *str;
    if (sp >= str_end) {
        return -2;
    }

    /* ignore leading zeroes */
    while (*sp == '0' && sp < str_end) {
        sp++;
    }

    ep = sp;
    if (sp < str_end) {
        while (ep < str_end && *ep != 0 && *ep >= '0' && *ep <= '9') {
            ep++;
        }

        if (ep < str_end) {
            return -2;
        }

        i = ep - sp;
        if (i > 24) {
            *str = ep;
            return -1;
        }

        while (i > 16) {
            hi = hi * 10 + (*sp++ - '0');
            i--;
        }
        while (i > 8) {
            mi = mi * 10 + (*sp++ - '0');
            i--;
        }
        while (i > 0) {
            lo = lo * 10 + (*sp++ - '0');
            i--;
        }
    }

    *str = ep;
    *llo = lo;
    *lmi = mi;
    *lhi = hi;
    return ep - sp;
}

enum confd_bool confd_parse_uint32(const char *str, const char *end,
                              uint32_t *val)
{
    const char *p = str;
    unsigned long lo, mi, hi;

    if (confd_parse_uint(&p, end, &lo, &mi, &hi) < 0) {
        return CONFD_FALSE;
    }
    if (hi != 0) {
        return CONFD_TRUE;
    }
    if (mi >= 42) {
        if (mi > 42) {
            return CONFD_FALSE;
        }

        if (lo > 94967295) {
            return CONFD_FALSE;
        }
    }

    *val = (uint32_t) (mi * 100000000 + lo);

    return CONFD_TRUE;
}


static enum confd_bool confd_parse_uint16(const char *str, const char *end,
                                      uint16_t *val)
{
    const char *p = str;
    unsigned long lo, mi, hi;

    if (confd_parse_uint(&p, end, &lo, &mi, &hi) < 0) {
        return CONFD_FALSE;
    }
    if (hi != 0 || mi != 0 || lo > 65535) {
        return CONFD_FALSE;
    }

    *val = (uint16_t) lo;

    return CONFD_TRUE;
}


static enum confd_bool confd_parse_uint8(const char *str, const char *end,
                                     uint8_t *val)
{
    const char *p = str;
    unsigned long lo, mi, hi;

    if (confd_parse_uint(&p, end, &lo, &mi, &hi) < 0) {
        return CONFD_FALSE;
    }

    if (hi != 0 || mi != 0 || lo > 255) {
        return CONFD_FALSE;
    }

    *val = (uint8_t) lo;

    return CONFD_TRUE;
}

static enum confd_bool confd_parse_int64(const char *str, const char *end,
                                     int64_t *val)
{
    const char *p = str;
    unsigned long lo, mi, hi;
    int sign = 0;

    if (*p == '-') {
        sign = 1;
        p++;
    } else if (*p == '+') {
        p++;
    }

    if (confd_parse_uint(&p, end, &lo, &mi, &hi) < 0)
        return CONFD_FALSE;
    if (hi >= 922) {
        if (hi > 922)
            return CONFD_FALSE;
        if (mi >= 33720368) {
            if (mi > 33720368)
                return CONFD_FALSE;
            if (sign == 1 && lo > 54775808)
                return CONFD_FALSE;
            if (sign == 0 && lo > 54775807)
                return CONFD_FALSE;
        }
    }

    if (sign == 1)
        *val = (int64_t) (( - (int64_t) hi * 100000000 - mi) * 100000000 - lo);
    else
        *val = (int64_t) (((int64_t) hi * 100000000 + mi) * 100000000 + lo);

    return CONFD_TRUE;
}


/*
 * C_BUF
 */
static int str_to_string(struct confd_type *self,
                         struct confd_type_ctx *ctx,
                         const char *str, unsigned int len,
                         struct confd_value *v)
{

    char *buf;

    buf = (char *)confd_malloc(len+1);
    if (buf == NULL) {
        return CONFD_FALSE;
    }
    memcpy(buf, str, len);
    buf[len] = '\0';

    CONFD_SET_BUF(v, (unsigned char *)buf, len);
    return CONFD_TRUE;
}

static int string_to_str(struct confd_type *self,
                         struct confd_type_ctx *ctx,
                         const struct confd_value *v,
                         char *str, unsigned int size,
                         const char **strp)
{
    char *b = NULL;
    unsigned int blen = 0;


    if (v->type != C_BUF && v->type != C_STR) {
        return -1;
    }

    if (v->type == C_BUF) {
        b = (char *)CONFD_GET_BUFPTR(v);
        blen = CONFD_GET_BUFSIZE(v);
    } else {
        b = v->val.s;
        blen = strlen(b);
    }

    if (blen < size) {
        memcpy(str, b, blen);
        str[blen] = '\0';
    } else if (size > 0) {
        memcpy(str, b, size-1);
        str[size-1] = '\0';
    }

    return blen;
}

static int validate_string(struct confd_type *self,
                           struct confd_type_ctx *ctx,
                           const struct confd_value *v)
{

    if (v->type == C_BUF || v->type == C_STR) {
        return CONFD_TRUE;
    }
    return CONFD_FALSE;
}

/*
 * CONFD_INT8
 */
static int str_to_int8(struct confd_type *self,
                       struct confd_type_ctx *ctx,
                       const char *str, unsigned int len,
                       struct confd_value *v)
{
    const char *p;
    const char *ep;
    unsigned long lo, mi, hi;
    int sign = 0;

    if (!ws_collapse_validate(str, len, &p, &ep)) {
        return CONFD_FALSE;
    }

    if (*p == '-') {
        sign = 1;
        p++;
    } else if (*p == '+') {
        p++;
    }

    if (confd_parse_uint(&p, ep, &lo, &mi, &hi) < 0) {
        return CONFD_FALSE;
    }

    if (hi != 0 || mi != 0 || lo > 255) {
        return CONFD_FALSE;
    }

    if (sign) {
        CONFD_SET_INT8(v,  -1 * ((int8_t) lo));
    } else {
        CONFD_SET_INT8(v, (int8_t) lo);
    }

    return CONFD_TRUE;
}

static int int8_to_str(struct confd_type *self,
                       struct confd_type_ctx *ctx,
                       const struct confd_value *v,
                       char *str, unsigned int size,
                       const char **strp)
{
    int8_t ival;

    if (v->type != C_INT8) {
        return -1;
    }

    ival = CONFD_GET_INT8(v);

    return snprintf(str, size, "%d", ival);
}

static int validate_int8(struct confd_type *self,
                         struct confd_type_ctx *ctx,
                         const struct confd_value *v)
{
    if (v->type == C_INT8) {
        return CONFD_TRUE;
    }
    return CONFD_FALSE;
}

/*
 * CONFD_INT16
 */
static int str_to_int16(struct confd_type *self,
                        struct confd_type_ctx *ctx,
                        const char *str, unsigned int len,
                        struct confd_value *v)
{
    const char *p;
    const char *ep;
    unsigned long lo, mi, hi;
    int sign = 0;

    if (!ws_collapse_validate(str, len, &p, &ep)) {
        return CONFD_FALSE;
    }

    if (*p == '-') {
        sign = 1;
        p++;
    } else if (*p == '+') {
        p++;
    }
    if (confd_parse_uint(&p, ep, &lo, &mi, &hi) < 0)
        return CONFD_FALSE;
    if (hi != 0 || mi != 0)
        return CONFD_FALSE;
    if (sign == 1 && lo > 32768)
        return CONFD_FALSE;
    if (sign == 0 && lo > 32767)
        return CONFD_FALSE;

    if (sign == 1)
        CONFD_SET_INT16(v, -lo);
    else
        CONFD_SET_INT16(v, lo);

    return CONFD_TRUE;
}

static int int16_to_str(struct confd_type *self,
                        struct confd_type_ctx *ctx,
                        const struct confd_value *v,
                        char *str, unsigned int size,
                        const char **strp)
{
    int16_t ival;

    if (v->type != C_INT16) {
        return -1;
    }

    ival = CONFD_GET_INT16(v);

    return snprintf(str, size, "%d", ival);
}

static int validate_int16(struct confd_type *self,
                          struct confd_type_ctx *ctx,
                          const struct confd_value *v)
{
    if (v->type == C_INT16) {
        return CONFD_TRUE;
    }
    return CONFD_FALSE;
}

/*
 * CONFD_INT32
 */
static int str_to_int32(struct confd_type *self,
                        struct confd_type_ctx *ctx,
                        const char *str, unsigned int len,
                        struct confd_value *v)
{
    const char *p;
    const char *ep;
    unsigned long lo, mi, hi;
    int sign = 0;

    if (!ws_collapse_validate(str, len, &p, &ep)) {
        return CONFD_FALSE;
    }

    if (*p == '-') {
        sign = 1;
        p++;
    } else if (*p == '+') {
        p++;
    }

    if (confd_parse_uint(&p, ep, &lo, &mi, &hi) < 0)
        return CONFD_FALSE;
    if (hi != 0)
        return CONFD_FALSE;
    if (mi >= 21) {
        if (mi > 21)
            return CONFD_FALSE;
        if (sign == 1 && lo > 47483648)
            return CONFD_FALSE;
        if (sign == 0 && lo > 47483647)
            return CONFD_FALSE;
    }

    if (sign == 1)
        CONFD_SET_INT32(v, (int32_t) ( - mi * 100000000 - lo));
    else
        CONFD_SET_INT32(v, (int32_t) (mi * 100000000 + lo));
    return CONFD_TRUE;
}

static int int32_to_str(struct confd_type *self,
                        struct confd_type_ctx *ctx,
                        const struct confd_value *v,
                        char *str, unsigned int size,
                        const char **strp)
{
    int32_t ival;

    if (v->type != C_INT32) {
        return -1;
    }

    ival = CONFD_GET_INT32(v);

    return snprintf(str, size, "%d", ival);
}

static int validate_int32(struct confd_type *self,
                          struct confd_type_ctx *ctx,
                          const struct confd_value *v)
{
    if (v->type == C_INT32) {
        return CONFD_TRUE;
    }
    return CONFD_FALSE;
}

/*
 * CONFD_INT64
 */
static int str_to_int64(struct confd_type *self,
                        struct confd_type_ctx *ctx,
                        const char *str, unsigned int len,
                        struct confd_value *v)
{
    const char *p;
    const char *ep;
    int64_t value;

    if (!ws_collapse_validate(str, len, &p, &ep)) {
        return CONFD_FALSE;
    }

    if (confd_parse_int64(p, ep, &value) == CONFD_FALSE) {
        return CONFD_FALSE;
    }

    CONFD_SET_INT64(v, value);

    return CONFD_TRUE;
}

static int int64_to_str(struct confd_type *self,
                        struct confd_type_ctx *ctx,
                        const struct confd_value *v,
                        char *str, unsigned int size,
                        const char **strp)
{
    int64_t ival;

    if (v->type != C_INT64) {
        return -1;
    }

    ival = CONFD_GET_INT64(v);

    return snprintf(str, size, "%" PRId64, ival);
}

static int validate_int64(struct confd_type *self,
                          struct confd_type_ctx *ctx,
                          const struct confd_value *v)
{
    if (v->type == C_INT64) {
        return CONFD_TRUE;
    }
    return CONFD_FALSE;
}

/*
 * CONFD_UINT8
 */
static int str_to_uint8(struct confd_type *self,
                        struct confd_type_ctx *ctx,
                        const char *str, unsigned int len,
                        struct confd_value *v)
{
    const char *p;
    const char *ep;
    unsigned long lo, mi, hi;

    if (!ws_collapse_validate(str, len, &p, &ep)) {
        return CONFD_FALSE;
    }

    if (confd_parse_uint(&p, ep, &lo, &mi, &hi) < 0)
        return CONFD_FALSE;
    if (hi != 0 || mi != 0 || lo > 255)
        return CONFD_FALSE;
    CONFD_SET_UINT8(v, (uint8_t) lo);
    return CONFD_TRUE;
}

static int uint8_to_str(struct confd_type *self,
                        struct confd_type_ctx *ctx,
                        const struct confd_value *v,
                        char *str, unsigned int size,
                        const char **strp)
{
    uint8_t ival;

    if (v->type != C_UINT8) {
        return -1;
    }

    ival = CONFD_GET_UINT8(v);

    return snprintf(str, size, "%u", ival);
}

static int validate_uint8(struct confd_type *self,
                          struct confd_type_ctx *ctx,
                          const struct confd_value *v)
{
    if (v->type == C_UINT8) {
        return CONFD_TRUE;
    }
    return CONFD_FALSE;
}

/*
 * CONFD_UINT16
 */
static int str_to_uint16(struct confd_type *self,
                         struct confd_type_ctx *ctx,
                         const char *str, unsigned int len,
                         struct confd_value *v)
{
    const char *p;
    const char *ep;
    unsigned long lo, mi, hi;

    if (!ws_collapse_validate(str, len, &p, &ep)) {
        return CONFD_FALSE;
    }

    if (confd_parse_uint(&p, ep, &lo, &mi, &hi) < 0)
        return CONFD_FALSE;
    if (hi != 0 || mi != 0 || lo > 65535)
        return CONFD_FALSE;

    CONFD_SET_UINT16(v, lo);

    return CONFD_TRUE;
}

static int uint16_to_str(struct confd_type *self,
                         struct confd_type_ctx *ctx,
                         const struct confd_value *v,
                         char *str, unsigned int size,
                         const char **strp)
{
    uint16_t ival;

    if (v->type != C_UINT16) {
        return -1;
    }

    ival = CONFD_GET_UINT16(v);

    return snprintf(str, size, "%u", ival);
}

static int validate_uint16(struct confd_type *self,
                           struct confd_type_ctx *ctx,
                           const struct confd_value *v)
{
    if (v->type == C_UINT16) {
        return CONFD_TRUE;
    }
    return CONFD_FALSE;
}

/*
 * CONFD_UINT32
 */
static int str_to_uint32(struct confd_type *self,
                         struct confd_type_ctx *ctx,
                         const char *str, unsigned int len,
                         struct confd_value *v)
{
    const char *p;
    const char *ep;
    unsigned long lo, mi, hi;

    if (!ws_collapse_validate(str, len, &p, &ep)) {
        return CONFD_FALSE;
    }

    if (confd_parse_uint(&p, ep, &lo, &mi, &hi) < 0)
        return CONFD_FALSE;
    if (hi != 0)
        return CONFD_FALSE;
    if (mi >= 42) {
        if (mi > 42)
            return CONFD_FALSE;
        if (lo > 94967295)
            return CONFD_FALSE;
    }
    CONFD_SET_UINT32(v, (uint32_t) (mi * 100000000 + lo));

    return CONFD_TRUE;
}

static int uint32_to_str(struct confd_type *self,
                         struct confd_type_ctx *ctx,
                         const struct confd_value *v,
                         char *str, unsigned int size,
                         const char **strp)
{
    uint32_t ival;

    if (v->type != C_UINT32) {
        return -1;
    }

    ival = CONFD_GET_UINT32(v);

    return snprintf(str, size, "%u", ival);
}

static int validate_uint32(struct confd_type *self,
                           struct confd_type_ctx *ctx,
                           const struct confd_value *v)
{
    if (v->type == C_UINT32) {
        return CONFD_TRUE;
    }
    return CONFD_FALSE;
}

/*
 * CONFD_UINT64
 */
static int str_to_uint64(struct confd_type *self,
                         struct confd_type_ctx *ctx,
                         const char *str, unsigned int len,
                         struct confd_value *v)
{
    const char *p;
    const char *ep;
    unsigned long lo, mi, hi;

    if (!ws_collapse_validate(str, len, &p, &ep)) {
        return CONFD_FALSE;
    }

    if (confd_parse_uint(&p, ep, &lo, &mi, &hi) < 0)
        return CONFD_FALSE;
    if (hi >= 1844) {
        if (hi > 1844)
            return CONFD_FALSE;
        if (mi >= 67440737) {
            if (mi > 67440737)
                return CONFD_FALSE;
            if (lo > 94967295)
                return CONFD_FALSE;
        }
    }

    CONFD_SET_UINT64(v, (uint64_t)
                   (((uint64_t) hi * 100000000 + mi) * 100000000 +
                    lo));

    return CONFD_TRUE;
}

static int uint64_to_str(struct confd_type *self,
                         struct confd_type_ctx *ctx,
                         const struct confd_value *v,
                         char *str, unsigned int size,
                         const char **strp)
{
    uint64_t ival;

    if (v->type != C_UINT64) {
        return -1;
    }

    ival = CONFD_GET_UINT64(v);

    return snprintf(str, size, "%" PRIu64, ival);
}

static int validate_uint64(struct confd_type *self,
                           struct confd_type_ctx *ctx,
                           const struct confd_value *v)
{
    if (v->type == C_UINT64) {
        return CONFD_TRUE;
    }
    return CONFD_FALSE;
}

/*
 * C_DOUBLE
 */
static int str_to_double(struct confd_type *self,
                         struct confd_type_ctx *ctx,
                         const char *str, unsigned int len,
                         struct confd_value *v)
{
    const char *p;
    const char *ep;
    char *ep2;
    double d;

    if (!ws_collapse_validate(str, len, &p, &ep)) {
        return CONFD_FALSE;
    }

    d = strtod(p, &ep2);
    if (ep2 != ep)
        return CONFD_FALSE;

    CONFD_SET_DOUBLE(v, d);

    return CONFD_TRUE;
}

static int double_to_str(struct confd_type *self,
                         struct confd_type_ctx *ctx,
                         const struct confd_value *v,
                         char *str, unsigned int size,
                         const char **strp)
{
    double d;

    if (v->type != C_DOUBLE) {
        return -1;
    }

    d = CONFD_GET_DOUBLE(v);

    return snprintf(str, size, "%G", d);
}

static int validate_double(struct confd_type *self,
                           struct confd_type_ctx *ctx,
                           const struct confd_value *v)
{
    if (v->type == C_DOUBLE) {
        return CONFD_TRUE;
    }
    return CONFD_FALSE;
}

/*
 * C_IPV4
 */
static int str_to_ipv4(struct confd_type *self,
                       struct confd_type_ctx *ctx,
                       const char *str, unsigned int len,
                       struct confd_value *v)
{
    const char *p;
    const char *ep;
    unsigned int vlen;
    char src[INET_ADDRSTRLEN];
    struct in_addr ip;

    if (!ws_collapse_validate(str, len, &p, &ep)) {
        return CONFD_FALSE;
    }
    vlen = ep - p;

    if (vlen > INET_ADDRSTRLEN-1) {
        return CONFD_FALSE;
    }
    /* make a NUL-terminated string for inet_pton */
    strncpy(src, p, vlen);
    src[vlen] = '\0';
    if (inet_pton(AF_INET, src, &ip) <= 0) {
        return CONFD_FALSE;
    }

    CONFD_SET_IPV4(v, ip);

    return CONFD_TRUE;
}

static int ipv4_to_str(struct confd_type *self,
                       struct confd_type_ctx *ctx,
                       const struct confd_value *v,
                       char *str, unsigned int size,
                       const char **strp)
{
    struct in_addr ip;
    char dst[INET_ADDRSTRLEN];
    const char *r;

    if (v->type != C_IPV4) {
        return -1;
    }

    ip = CONFD_GET_IPV4(v);
    r = inet_ntop(AF_INET, &ip, dst, INET_ADDRSTRLEN);
    if (r == NULL) {
        return -1;
    }
    return snprintf(str, size, "%s", dst);
}

static int validate_ipv4(struct confd_type *self,
                         struct confd_type_ctx *ctx,
                         const struct confd_value *v)
{
    if (v->type == C_IPV4) {
        return CONFD_TRUE;
    }
    return CONFD_FALSE;
}

/*
 * C_IPV6
 */
static int str_to_ipv6(struct confd_type *self,
                       struct confd_type_ctx *ctx,
                       const char *str, unsigned int len,
                       struct confd_value *v)
{
    const char *p;
    const char *ep;
    unsigned int vlen;
    char src[INET6_ADDRSTRLEN];
    struct in6_addr ip6;

    if (!ws_collapse_validate(str, len, &p, &ep)) {
        return CONFD_FALSE;
    }
    vlen = ep - p;

    if (vlen > sizeof(src)-1 ) {
        return CONFD_FALSE;
    }
    /* make a NUL-terminated string for inet_pton */
    strncpy(src, str, vlen);
    src[vlen] = '\0';
    if (inet_pton(AF_INET6, src, &ip6) <= 0) {
        return CONFD_FALSE;
    }

    CONFD_SET_IPV6(v, ip6);

    return CONFD_TRUE;
}

static int ipv6_to_str(struct confd_type *self,
                       struct confd_type_ctx *ctx,
                       const struct confd_value *v,
                       char *str, unsigned int size,
                       const char **strp)
{
    struct in6_addr ip6;
    char dst[INET6_ADDRSTRLEN];
    const char *r;

    if (v->type != C_IPV6) {
        return -1;
    }

    ip6 = CONFD_GET_IPV6(v);
    r = inet_ntop(AF_INET6, &ip6, dst, INET6_ADDRSTRLEN);
    if (r == NULL) {
        return -1;
    }
    return snprintf(str, size, "%s", dst);
}

static int validate_ipv6(struct confd_type *self,
                         struct confd_type_ctx *ctx,
                         const struct confd_value *v)
{
    if (v->type == C_IPV6) {
        return CONFD_TRUE;
    }
    return CONFD_FALSE;
}

/*
 * C_IPV4PREFIX
 */
static int mk_ipv4prefix(const char *str, unsigned int len,
                         struct confd_ipv4_prefix *ipprefix)
{
    const char *p;
    const char *ep;
    const char *s;
    unsigned int vlen;
    char src[INET_ADDRSTRLEN];
    unsigned long lo, mi, hi;

    if (!ws_collapse_validate(str, len, &p, &ep)) {
        return CONFD_FALSE;
    }
    vlen = ep - p;

    s = memchr(p, '/', vlen);
    if (s == NULL) {
        return CONFD_FALSE;
    }

    /* scan the ip */
    vlen = s - p;

    if (vlen > sizeof(src)-1 ) {
        return CONFD_FALSE;
    }
    /* make a NUL-terminated string for inet_pton */
    strncpy(src, p, vlen);
    src[vlen] = '\0';
    if (inet_pton(AF_INET, src, &ipprefix->ip) <= 0) {
        return CONFD_FALSE;
    }
    /* skip the '/' */
    s++;

    if (confd_parse_uint(&s, ep, &lo, &mi, &hi) < 0)
        return CONFD_FALSE;
    if (hi != 0 || mi != 0 || lo > 32)
        return CONFD_FALSE;

    ipprefix->len = (uint8_t) lo;

    return CONFD_TRUE;
}

static int str_to_ipv4prefix(struct confd_type *self,
                             struct confd_type_ctx *ctx,
                             const char *str, unsigned int len,
                             struct confd_value *v)
{
    struct confd_ipv4_prefix ipprefix;

    if (mk_ipv4prefix(str, len, &ipprefix) == CONFD_FALSE)
        return CONFD_FALSE;

    /* check for non-zero bits outside prefix */
    if ((ntohl(ipprefix.ip.s_addr) & ((1 << (32 - ipprefix.len)) - 1)) != 0)
        return CONFD_FALSE;

    CONFD_SET_IPV4PREFIX(v, ipprefix);

    return CONFD_TRUE;
}

static int ipv4prefix_to_str(struct confd_type *self,
                             struct confd_type_ctx *ctx,
                             const struct confd_value *v,
                             char *str, unsigned int size,
                             const char **strp)
{
    struct confd_ipv4_prefix ipprefix;
    char dst[INET_ADDRSTRLEN];
    const char *r;

    if (v->type != C_IPV4PREFIX) {
        return -1;
    }

    ipprefix = CONFD_GET_IPV4PREFIX(v);
    r = inet_ntop(AF_INET, &ipprefix.ip, dst, INET_ADDRSTRLEN);
    if (r == NULL) {
        return -1;
    }
    return snprintf(str, size, "%s/%d", dst, ipprefix.len);
}

static int validate_ipv4prefix(struct confd_type *self,
                               struct confd_type_ctx *ctx,
                               const struct confd_value *v)
{
    struct confd_ipv4_prefix ipprefix;

    if (v->type != C_IPV4PREFIX) {
        return CONFD_FALSE;
    }

    ipprefix = CONFD_GET_IPV4PREFIX(v);
    if (ipprefix.len > 32)
        return CONFD_FALSE;
    /* check for non-zero bits outside prefix */
    if ((ntohl(ipprefix.ip.s_addr) & ((1 << (32 - ipprefix.len)) - 1)) != 0)
        return CONFD_FALSE;

    return CONFD_TRUE;
}

/*
 * C_IPV6PREFIX
 */
static int mk_ipv6prefix(const char *str, unsigned int len,
                         struct confd_ipv6_prefix *ipprefix)
{
    const char *p;
    const char *ep;
    const char *s;
    unsigned int vlen;
    char src[INET6_ADDRSTRLEN];
    unsigned long lo, mi, hi;

    if (!ws_collapse_validate(str, len, &p, &ep)) {
        return CONFD_FALSE;
    }
    vlen = ep - p;

    s = memchr(p, '/', vlen);
    if (s == NULL) {
        return CONFD_FALSE;
    }

    /* scan the ip */
    vlen = s - p;

    if (vlen > sizeof(src)-1 ) {
        return CONFD_FALSE;
    }
    /* make a NUL-terminated string for inet_pton */
    strncpy(src, p, vlen);
    src[vlen] = '\0';
    if (inet_pton(AF_INET6, src, &ipprefix->ip6) <= 0) {
        return CONFD_FALSE;
    }
    /* skip the '/' */
    s++;

    if (confd_parse_uint(&s, ep, &lo, &mi, &hi) < 0)
        return CONFD_FALSE;
    if (hi != 0 || mi != 0 || lo > 128)
        return CONFD_FALSE;

    ipprefix->len = (uint8_t) lo;

    return CONFD_TRUE;
}

static int str_to_ipv6prefix(struct confd_type *self,
                             struct confd_type_ctx *ctx,
                             const char *str, unsigned int len,
                             struct confd_value *v)
{
    struct confd_ipv6_prefix ipprefix;
    int i, rem;

    if (mk_ipv6prefix(str, len, &ipprefix) == CONFD_FALSE)
        return CONFD_FALSE;

    /* check for non-zero bits outside prefix */
    for (i = 15, rem = 128 - ipprefix.len; rem > 0; i--, rem -= 8) {
        if (rem >= 8) {
            if (ipprefix.ip6.s6_addr[i] != 0)
                return CONFD_FALSE;
        } else {
            if ((ipprefix.ip6.s6_addr[i] & ((1 << (8 - rem)) - 1)) != 0)
                return CONFD_FALSE;
        }
    }

    CONFD_SET_IPV6PREFIX(v, ipprefix);

    return CONFD_TRUE;
}

static int ipv6prefix_to_str(struct confd_type *self,
                             struct confd_type_ctx *ctx,
                             const struct confd_value *v,
                             char *str, unsigned int size,
                             const char **strp)
{
    struct confd_ipv6_prefix ipprefix;
    char dst[INET6_ADDRSTRLEN];
    const char *r;

    if (v->type != C_IPV6PREFIX) {
        return -1;
    }

    ipprefix = CONFD_GET_IPV6PREFIX(v);
    r = inet_ntop(AF_INET6, &ipprefix.ip6, dst, INET6_ADDRSTRLEN);
    if (r == NULL) {
        return -1;
    }
    return snprintf(str, size, "%s/%d", dst, ipprefix.len);
}

static int validate_ipv6prefix(struct confd_type *self,
                               struct confd_type_ctx *ctx,
                               const struct confd_value *v)
{
    struct confd_ipv6_prefix ipprefix;
    int i, rem;

    if (v->type != C_IPV6PREFIX) {
        return CONFD_FALSE;
    }

    ipprefix = CONFD_GET_IPV6PREFIX(v);
    if (ipprefix.len > 128)
        return CONFD_FALSE;
    /* check for non-zero bits outside prefix */
    for (i = 15, rem = 128 - ipprefix.len; rem > 0; i--, rem -= 8) {
        if (rem >= 8) {
            if (ipprefix.ip6.s6_addr[i] != 0)
                return CONFD_FALSE;
        } else {
            if ((ipprefix.ip6.s6_addr[i] & ((1 << (8 - rem)) - 1)) != 0)
                return CONFD_FALSE;
        }
    }

    return CONFD_TRUE;
}

/*
 * C_IPV4_AND_PLEN
 */
static int str_to_ipv4_and_plen(struct confd_type *self,
                                struct confd_type_ctx *ctx,
                                const char *str, unsigned int len,
                                struct confd_value *v)
{
    struct confd_ipv4_prefix ipprefix;

    if (mk_ipv4prefix(str, len, &ipprefix) == CONFD_FALSE)
        return CONFD_FALSE;

    CONFD_SET_IPV4_AND_PLEN(v, ipprefix);

    return CONFD_TRUE;
}

static int ipv4_and_plen_to_str(struct confd_type *self,
                                struct confd_type_ctx *ctx,
                                const struct confd_value *v,
                                char *str, unsigned int size,
                                const char **strp)
{
    struct confd_ipv4_prefix ipprefix;
    char dst[INET_ADDRSTRLEN];
    const char *r;

    if (v->type != C_IPV4_AND_PLEN) {
        return -1;
    }

    ipprefix = CONFD_GET_IPV4_AND_PLEN(v);
    r = inet_ntop(AF_INET, &ipprefix.ip, dst, INET_ADDRSTRLEN);
    if (r == NULL) {
        return -1;
    }
    return snprintf(str, size, "%s/%d", dst, ipprefix.len);
}

static int validate_ipv4_and_plen(struct confd_type *self,
                                  struct confd_type_ctx *ctx,
                                  const struct confd_value *v)
{
    struct confd_ipv4_prefix ipprefix;

    if (v->type != C_IPV4_AND_PLEN) {
        return CONFD_FALSE;
    }

    ipprefix = CONFD_GET_IPV4_AND_PLEN(v);
    if (ipprefix.len > 32)
        return CONFD_FALSE;

    return CONFD_TRUE;
}

/*
 * C_IPV6_AND_PLEN
 */
static int str_to_ipv6_and_plen(struct confd_type *self,
                                struct confd_type_ctx *ctx,
                                const char *str, unsigned int len,
                                struct confd_value *v)
{
    struct confd_ipv6_prefix ipprefix;

    if (mk_ipv6prefix(str, len, &ipprefix) == CONFD_FALSE)
        return CONFD_FALSE;

    CONFD_SET_IPV6_AND_PLEN(v, ipprefix);

    return CONFD_TRUE;
}

static int ipv6_and_plen_to_str(struct confd_type *self,
                                struct confd_type_ctx *ctx,
                                const struct confd_value *v,
                                char *str, unsigned int size,
                                const char **strp)
{
    struct confd_ipv6_prefix ipprefix;
    char dst[INET6_ADDRSTRLEN];
    const char *r;

    if (v->type != C_IPV6_AND_PLEN) {
        return -1;
    }

    ipprefix = CONFD_GET_IPV6_AND_PLEN(v);
    r = inet_ntop(AF_INET6, &ipprefix.ip6, dst, INET6_ADDRSTRLEN);
    if (r == NULL) {
        return -1;
    }
    return snprintf(str, size, "%s/%d", dst, ipprefix.len);
}

static int validate_ipv6_and_plen(struct confd_type *self,
                                  struct confd_type_ctx *ctx,
                                  const struct confd_value *v)
{
    struct confd_ipv6_prefix ipprefix;

    if (v->type != C_IPV6_AND_PLEN) {
        return CONFD_FALSE;
    }

    ipprefix = CONFD_GET_IPV6_AND_PLEN(v);
    if (ipprefix.len > 128)
        return CONFD_FALSE;

    return CONFD_TRUE;
}

/*
 * C_BOOL
 */
static int str_to_bool(struct confd_type *self,
                       struct confd_type_ctx *ctx,
                       const char *str, unsigned int len,
                       struct confd_value *v)
{
    const char *sp;
    const char *ep;
    unsigned int vlen;

    if (!ws_collapse_validate(str, len, &sp, &ep)) {
        return CONFD_FALSE;
    }
    vlen = ep - sp;

    if (vlen == 0)
        return CONFD_FALSE;

    if (*sp == '0' && vlen == 1) {
        CONFD_SET_BOOL(v, 0);
        return CONFD_TRUE;
    }
    if (*sp == '1' && vlen == 1) {
        CONFD_SET_BOOL(v, 1);
        return CONFD_TRUE;
    }

    if (*sp == 't' && vlen == 4) {
        ++sp;
        if (*sp++ == 'r' && *sp++ == 'u' && *sp++ == 'e') {
            CONFD_SET_BOOL(v, 1);
            return CONFD_TRUE;
        }

    } else if (*sp == 'f' && vlen == 5) {
        sp++;
        if (*sp++ == 'a' && *sp++ == 'l' && *sp++ == 's' && *sp++ == 'e') {
            CONFD_SET_BOOL(v, 0);
            return CONFD_TRUE;
        }
    }
    return CONFD_FALSE;
}

static int bool_to_str(struct confd_type *self,
                       struct confd_type_ctx *ctx,
                       const struct confd_value *v,
                       char *str, unsigned int size,
                       const char **strp)
{
    int b;
    const char *s;

    if (v->type != C_BOOL) {
        return -1;
    }

    b = CONFD_GET_BOOL(v);
    s = (b ? "true" : "false");
    if (strp != NULL)
        *strp = s;
    return snprintf(str, size, "%s", s);
}

static int validate_bool(struct confd_type *self,
                         struct confd_type_ctx *ctx,
                         const struct confd_value *v)
{
    if (v->type == C_BOOL) {
        return CONFD_TRUE;
    }
    return CONFD_FALSE;
}

static const char *str_to_uval8(const char *cp, const char *ep,
                                char delimiter, int digits, uint8_t *value)
{
    const char *start_str;
    uint8_t uvalue;

    *value = 0;

    start_str = cp;
    while (cp < ep) {
        if (!isdigit(*cp)) {
            break;
        }
        ++cp;
    }
    // Check for the right type of delimiter, if '\0' ignore this
    if (delimiter != '\0' && (cp >= ep ||  *cp != delimiter)) {
        return NULL;
    }

    // If too many digits, not valid
    if (digits > 0 && cp - start_str > digits) {
        return NULL;
    }
    if (confd_parse_uint8(start_str, cp, &uvalue) == CONFD_FALSE) {
        return NULL;
    }
    *value = uvalue;
    // cp points at delimiter see above
    if (delimiter != '\0') {
        ++cp;
    }
    return cp;
}

static const char *str_to_uval32(const char *cp, const char *ep,
                                 uint32_t *value)
{
    const char *start_str;

    *value = 0;

    start_str = cp;
    while (cp < ep) {
        if (!isdigit(*cp)) {
            break;
        }
        ++cp;
    }

    if (confd_parse_uint32(start_str, cp, value) == CONFD_FALSE) {
        return NULL;
    }
    return cp;
}

/*
 * Date and Time
 */

static const char *str_to_year(const char *cp, const char *ep,
                               char delimiter, int16_t *year)
{
    const char *start_str;
    uint16_t uvalue;
    int sign = 0;

    *year = 0;

    if (cp < ep && *cp == '-') {
        ++cp;
        sign = 1;
    }
    start_str = cp;
    while (cp < ep) {
        if (!isdigit(*cp)) {
            break;
        }
        ++cp;
    }
    // Check for the right type of delimiter, if '\0' ignore this
    if (delimiter != '\0' && (cp >= ep ||  *cp != delimiter)) {
        return NULL;
    }

    // If more than four digits leading zeroes are prohibited
    if (cp - start_str > 4 && *start_str == '0') {
        return NULL;
    }
    if (confd_parse_uint16(start_str, cp, &uvalue) == CONFD_FALSE) {
        return NULL;
    }
    if (sign) {
        *year = -1 * uvalue;
    } else {
        *year = uvalue;
    }
    // cp points at - see above
    ++cp;

    return cp;
}


/* Fractions can be any number of digits but we only handle microseconds */
static const char *str_to_fractions(const char *cp, const char *ep,
                                    char delimiter, uint32_t *value)
{
    char buf[6];   // We handle fractions in microseconds
    unsigned int i;
    uint32_t uvalue;

    *value = 0;
    i = 0;

    // Fractions can be any length, scan the ones after the first 6
    while (cp < ep) {
        if (!isdigit(*cp)) {
            break;
        }
        if (i < sizeof(buf)) {
            buf[i] = *cp;
            ++i;
        }
        ++cp;
    }


    // Check for the right type of delimiter, if '\0' ignore this
    if (delimiter != '\0' && (cp >= ep ||  *cp != delimiter)) {
        return NULL;
    }

    // Fill the buffer with zeroes to get microseconds
    while (i < sizeof(buf)) {
        buf[i] = '0';
        ++i;
    }

    if (confd_parse_uint32(buf, buf+sizeof(buf), &uvalue) == CONFD_FALSE) {
        return NULL;
    }
    *value = uvalue;
    // cp points at delimiter see above
    if (delimiter != '\0') {
        ++cp;
    }
    return cp;
}

static const char *str_to_timezone(const char*cp, const char *ep,
                                   int8_t *timezone,
                                   int8_t *timezone_minutes)
{
    int sign;
    uint8_t utz;
    uint8_t utz_m;

    if (cp < ep) {
        if (*cp == 'Z') {
            *timezone = 0;
            *timezone_minutes = 0;
            ++cp;
        } else if (ep - cp == 6 && strncmp(cp, "-00:00", 6) == 0) {
            *timezone = CONFD_TIMEZONE_UNDEF;
            *timezone_minutes = 0;
            cp += 6;
        } else {
            if (*cp == '+') {
                sign = 1;
            } else if (*cp == '-') {
                sign = -1;
            } else {
                return NULL;
            }
            cp++;
            if ((cp = str_to_uval8(cp, ep, ':', 2, &utz)) == NULL) {
                return NULL;
            }
            if ((cp = str_to_uval8(cp, ep, '\0', 2, &utz_m)) == NULL) {
                return NULL;
            }
            *timezone = sign * utz;
            if (*timezone == 0)
                *timezone_minutes = sign * utz_m;
            else
                *timezone_minutes = utz_m;
        }
    } else {
        *timezone = CONFD_TIMEZONE_UNDEF;
        *timezone_minutes = 0;
    }

    return cp;
}

static int number_of_days[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

static enum confd_bool check_date(int year, int month, int day)
{
    int leap_year = 0;
    int days;

    if (year == 0) {
        return CONFD_FALSE;
    }
    if (year < 0) {
        year *= -1;
    }

    if (year % 4 == 0 && (!(year % 100 == 0) || (year % 400 == 0))) {
        leap_year = 1;
    }

    if (month < 1 || month > 12) {
        return CONFD_FALSE;
    }
    --month;
    if (month == 1 && leap_year) {
        days = 29;
    } else {
        days = number_of_days[month];
    }
    if (day < 1 || day > days) {
        return CONFD_FALSE;
    }

    return CONFD_TRUE;
}

static enum confd_bool check_time(int hour, int minute, int second,
                                   int fractions)
{
    if (hour == 24 && minute == 0 && second == 0 && fractions == 0) {
        return CONFD_TRUE;
    }

    if (hour < 0 || hour > 23) {
        return CONFD_FALSE;
    }
    if (minute < 0 || minute > 59) {
        return CONFD_FALSE;
    }
    if (second < 0 || second > 60) {
        return CONFD_FALSE;
    }
    if (fractions < 0 || fractions > 999999) {
        return CONFD_FALSE;
    }

    return CONFD_TRUE;
}

/*
 * C_DATETIME
 */
static int str_to_datetime(struct confd_type *self,
                           struct confd_type_ctx *ctx,
                           const char *str, unsigned int len,
                           struct confd_value *v)
{
    const char *cp;
    const char *ep;
    struct confd_datetime *dt;

    if (!ws_collapse_validate(str, len, &cp, &ep)) {
        return CONFD_FALSE;
    }

    v->type = C_NOEXISTS;
    dt = &v->val.datetime;

    if ((cp = str_to_year(cp, ep, '-', &dt->year)) == NULL) {
        return CONFD_FALSE;
    }
    if ((cp = str_to_uval8(cp, ep, '-', 2, &dt->month)) == NULL) {
        return CONFD_FALSE;
    }
    if ((cp = str_to_uval8(cp, ep, 'T', 2, &dt->day)) == NULL) {
        return CONFD_FALSE;
    }
    if ((cp = str_to_uval8(cp, ep, ':', 2, &dt->hour)) == NULL) {
        return CONFD_FALSE;
    }
    if ((cp = str_to_uval8(cp, ep, ':', 2, &dt->min)) == NULL) {
        return CONFD_FALSE;
    }
    if ((cp = str_to_uval8(cp, ep, '\0', 2, &dt->sec)) == NULL) {
        return CONFD_FALSE;
    }
    if (cp < ep && *cp == '.') {
        // Fractions
        ++cp;
        if ((cp = str_to_fractions(cp, ep, '\0', &dt->micro)) == NULL) {
            return CONFD_FALSE;
        }

    } else {
        dt->micro = 0;
    }

    if (cp < ep) {
        if ((cp = str_to_timezone(cp, ep,
                                  &dt->timezone,
                                  &dt->timezone_minutes)) == NULL) {
            return CONFD_FALSE;
        }
    } else {
        dt->timezone = CONFD_TIMEZONE_UNDEF;
        dt->timezone_minutes = 0;
    }

    if (cp < ep) {
        // We have trailing garbage
        return CONFD_FALSE;
    }

    if (check_date(dt->year, dt->month, dt->day) == CONFD_FALSE) {
        return CONFD_FALSE;
    }
    if (check_time(dt->hour, dt->month, dt->day, dt->micro) ==
        CONFD_FALSE) {

        return CONFD_FALSE;
    }

    v->type = C_DATETIME;

    return CONFD_TRUE;
}

static int datetime_to_str(struct confd_type *self,
                           struct confd_type_ctx *ctx,
                           const struct confd_value *v,
                           char *str, unsigned int size,
                           const char **strp)
{
    struct confd_datetime dt;
    char tz[10];
    char us[10];

    if (v->type != C_DATETIME) {
        return -1;
    }
    dt = CONFD_GET_DATETIME(v);

    dt_tz_to_str(tz, sizeof(tz), dt.timezone, dt.timezone_minutes);
    us_to_str(us, sizeof(us), dt.micro);

    return snprintf(str, size, "%04d-%02d-%02dT%02d:%02d:%02d%s%s",
                    dt.year, dt.month, dt.day, dt.hour, dt.min, dt.sec, us, tz);
}

static int validate_datetime(struct confd_type *self,
                             struct confd_type_ctx *ctx,
                             const struct confd_value *v)
{
    const struct confd_datetime *dt = &v->val.datetime;

    if (v->type != C_DATETIME) {
        return CONFD_FALSE;
    }

    if (check_date(dt->year, dt->month, dt->day) == CONFD_FALSE) {
        return CONFD_FALSE;
    }
    if (check_time(dt->hour, dt->min, dt->sec, dt->micro) == CONFD_FALSE) {
        return CONFD_FALSE;
    }

    return CONFD_TRUE;
}

/*
 * C_DATE
 */
static int str_to_date(struct confd_type *self,
                       struct confd_type_ctx *ctx,
                       const char *str, unsigned int len,
                       struct confd_value *v)
{
    const char *cp;
    const char *ep;
    struct confd_date *d;

    if (!ws_collapse_validate(str, len, &cp, &ep)) {
        return CONFD_FALSE;
    }

    v->type = C_NOEXISTS;
    d = &v->val.date;

    if ((cp = str_to_year(cp, ep, '-', &d->year)) == NULL) {
        return CONFD_FALSE;
    }
    if ((cp = str_to_uval8(cp, ep, '-', 2, &d->month)) == NULL) {
        return CONFD_FALSE;
    }
    if ((cp = str_to_uval8(cp, ep, '\0', 2, &d->day)) == NULL) {
        return CONFD_FALSE;
    }
    if (cp < ep) {
        if ((cp = str_to_timezone(cp, ep,
                                  &d->timezone,
                                  &d->timezone_minutes)) == NULL) {
            return CONFD_FALSE;
        }
    } else {
        d->timezone = CONFD_TIMEZONE_UNDEF;
        d->timezone_minutes = 0;
    }
    if (cp < ep) {
        // We have trailing garbage
        return CONFD_FALSE;
    }

    if (check_date(d->year, d->month, d->day) == CONFD_FALSE) {
        return CONFD_FALSE;
    }

    v->type = C_DATE;

    return CONFD_TRUE;
}

static int date_to_str(struct confd_type *self,
                       struct confd_type_ctx *ctx,
                       const struct confd_value *v,
                       char *str, unsigned int size,
                       const char **strp)
{
    const struct confd_date *d;
    char tz[10];

    if (v->type != C_DATE) {
        return -1;
    }

    d = &v->val.date;
    tz_to_str(tz, sizeof(tz), d->timezone, d->timezone_minutes);

    return snprintf(str, size, "%04d-%02d-%02d%s",
                    d->year, d->month, d->day, tz);
}

static int validate_date(struct confd_type *self,
                         struct confd_type_ctx *ctx,
                         const struct confd_value *v)
{
    const struct confd_date *d = &v->val.date;

    if (v->type != C_DATE) {
        return CONFD_FALSE;
    }
    if (check_date(d->year, d->month, d->day) == CONFD_FALSE) {
        return CONFD_FALSE;
    }

    return CONFD_TRUE;
}

/*
 * C_TIME
 */
static int str_to_time(struct confd_type *self,
                       struct confd_type_ctx *ctx,
                       const char *str, unsigned int len,
                       struct confd_value *v)
{
    const char *cp;
    const char *ep;
    struct confd_time *t;

    if (!ws_collapse_validate(str, len, &cp, &ep)) {
        return CONFD_FALSE;
    }

    v->type = C_NOEXISTS;
    t = &v->val.time;

    if ((cp = str_to_uval8(cp, ep, ':', 2, &t->hour)) == NULL) {
        return CONFD_FALSE;
    }
    if ((cp = str_to_uval8(cp, ep, ':', 2, &t->min)) == NULL) {
        return CONFD_FALSE;
    }
    if ((cp = str_to_uval8(cp, ep, '\0', 2, &t->sec)) == NULL) {
        return CONFD_FALSE;
    }
    if (cp < ep && *cp == '.') {
        // Fractions
        ++cp;
        if ((cp = str_to_fractions(cp, ep, '\0', &t->micro)) == NULL) {
            return CONFD_FALSE;
        }

    } else {
        t->micro = 0;
    }

    if (cp < ep) {
        if ((cp = str_to_timezone(cp, ep,
                                  &t->timezone,
                                  &t->timezone_minutes)) == NULL) {
            return CONFD_FALSE;
        }
    } else {
        t->timezone = CONFD_TIMEZONE_UNDEF;
        t->timezone_minutes = 0;
    }

    if (cp < ep) {
        // We have trailing garbage
        return CONFD_FALSE;
    }

    v->type = C_TIME;
    return self->validate(self, ctx, v);
}

static int time_to_str(struct confd_type *self,
                       struct confd_type_ctx *ctx,
                       const struct confd_value *v,
                       char *str, unsigned int size,
                       const char **strp)
{
    struct confd_time dt;
    char tz[10];
    char us[10];

    if (v->type != C_TIME) {
        return -1;
    }

    dt = CONFD_GET_TIME(v);

    tz_to_str(tz, sizeof(tz), dt.timezone, dt.timezone_minutes);
    us_to_str(us, sizeof(us), dt.micro);

    return snprintf(str, size, "%02d:%02d:%02d%s%s",
                    dt.hour, dt.min, dt.sec, us, tz);
}

static int validate_time(struct confd_type *self,
                         struct confd_type_ctx *ctx,
                         const struct confd_value *v)
{
    const struct confd_time *t = &v->val.time;

    if (v->type != C_TIME) {
        return CONFD_FALSE;
    }

    return check_time(t->hour, t->min, t->sec, t->micro);
}

/*
 * C_DURATION
 */
static int str_to_duration(struct confd_type *self,
                           struct confd_type_ctx *ctx,
                           const char *str, unsigned int len,
                           struct confd_value *v)
{
    const char *cp;
    const char *ep;
    struct confd_duration *dur;
    uint32_t val;

    if (!ws_collapse_validate(str, len, &cp, &ep)) {
        return CONFD_FALSE;
    }

    v->type = C_DURATION;
    dur = &v->val.duration;

    dur->years = 0;
    dur->months = 0;
    dur->days = 0;
    dur->hours = 0;
    dur->mins = 0;
    dur->secs = 0;
    dur->micros = 0;

    if (cp >= ep || *cp != 'P') {
        return CONFD_FALSE;
    }
    ++cp;
    if (cp >= ep) {
        return CONFD_FALSE;
    }

    if (*cp != 'T') {

        if ((cp = str_to_uval32(cp, ep, &val)) == NULL) {
            return CONFD_FALSE;
        }
        if (cp >= ep) {
            return CONFD_FALSE;
        }

        if (*cp == 'Y') {
            ++cp;
            dur->years = val;
            if (cp >= ep) {
                return self->validate(self, ctx, v);
            }
            if (*cp != 'T') {
                if ((cp = str_to_uval32(cp, ep, &val)) == NULL) {
                    return CONFD_FALSE;
                }
                if (cp >= ep) {
                    return CONFD_FALSE;
                }
            }
        }

        if (*cp == 'M') {
            ++cp;
            dur->months = val;
            if (cp >= ep) {
                return self->validate(self, ctx, v);
            }
            if (*cp != 'T') {
                if ((cp = str_to_uval32(cp, ep, &val)) == NULL) {
                    return CONFD_FALSE;
                }
                if (cp >= ep) {
                    return CONFD_FALSE;
                }
            }
        }

        if (*cp == 'D') {
            ++cp;
            dur->days = val;
            if (cp >= ep) {
                return self->validate(self, ctx, v);
            }
        }
    }

    // Time part
    //
    if (*cp != 'T') {
        return CONFD_FALSE;
    }
    ++cp;
    if (cp >= ep) {
        return CONFD_FALSE;
    }

    if ((cp = str_to_uval32(cp, ep, &val)) == NULL) {
        return CONFD_FALSE;
    }
    if (cp >= ep) {
        return CONFD_FALSE;
    }

    if (*cp == 'H') {
        ++cp;
        dur->hours = val;
        if (cp >= ep) {
            return self->validate(self, ctx, v);
        }
        if ((cp = str_to_uval32(cp, ep, &val)) == NULL) {
            return CONFD_FALSE;
        }
        if (cp >= ep) {
            return CONFD_FALSE;
        }
    }

    if (*cp == 'M') {
        ++cp;
        dur->mins = val;
        if (cp >= ep) {
            return self->validate(self, ctx, v);
        }
        if ((cp = str_to_uval32(cp, ep, &val)) == NULL) {
            return CONFD_FALSE;
        }
        if (cp >= ep) {
            return CONFD_FALSE;
        }
    }

    if (*cp == 'S') {
        ++cp;
        dur->secs = val;
    }

    if (cp < ep) {
        // We have trailing garbage
        return CONFD_FALSE;
    }

    return self->validate(self, ctx, v);
}

static int duration_to_str(struct confd_type *self,
                           struct confd_type_ctx *ctx,
                           const struct confd_value *v,
                           char *str, unsigned int size,
                           const char **strp)
{
    struct confd_duration dt;
    unsigned int n;
    unsigned int wlen = 0;

    if (v->type != C_DURATION) {
        return -1;
    }

    dt = CONFD_GET_DURATION(v);

    n = (unsigned int)snprintf(str, size, "P");
    wlen += n;
    str += n;
    if (n >= size) {
        size = 0;
    } else {
        size -= n;
    }

    if (dt.years) {
        n = (unsigned int)snprintf(str, size, "%dY", dt.years);
        wlen += n;
        str += n;
        if (n >= size) {
            size = 0;
        } else {
            size -= n;
        }
    }

    if (dt.months) {
        n = (unsigned int)snprintf(str, size, "%dM", dt.months);
        wlen += n;
        str += n;
        if (n >= size) {
            size = 0;
        } else {
            size -= n;
        }
    }

    if (dt.days) {
        n = (unsigned int)snprintf(str, size, "%dD", dt.days);
        wlen += n;
        str += n;
        if (n >= size) {
            size = 0;
        } else {
            size -= n;
        }
    }

    if (dt.days == 0 && dt.months == 0 && dt.years == 0) {
        n = (unsigned int)snprintf(str, size, "0D");
        wlen += n;
        str += n;
        if (n >= size) {
            size = 0;
        } else {
            size -= n;
        }
    }

    if (dt.secs != 0 || dt.micros != 0 || dt.mins != 0 || dt.hours != 0) {
        n = (unsigned int)snprintf(str, size, "T");
        wlen += n;
        str += n;
        if (n >= size) {
            size = 0;
        } else {
            size -= n;
        }

        if (dt.hours) {
            n = (unsigned int)snprintf(str, size, "%dH", dt.hours);
            wlen += n;
            str += n;
            if (n >= size) {
                size = 0;
            } else {
                size -= n;
            }
        }

        if (dt.mins) {
            n = (unsigned int)snprintf(str, size, "%dM", dt.mins);
            wlen += n;
            str += n;
            if (n >= size) {
                size = 0;
            } else {
                size -= n;
            }
        }

        if (dt.secs || dt.micros) {
            if (dt.secs != 0 && dt.micros == 0) {
                n = (unsigned int)snprintf(str, size, "%dS", dt.secs);
                wlen += n;
                str += n;
                if (n >= size) {
                    size = 0;
                } else {
                    size -= n;
                }
            } else {
                n = (unsigned int)snprintf(str, size, "%d.%06dS",
                                           dt.secs, dt.micros);
                wlen += n;
                str += n;
                if (n >= size) {
                    size = 0;
                } else {
                    size -= n;
                }
            }
        }
    }
    return wlen;
}

static int validate_duration(struct confd_type *self,
                             struct confd_type_ctx *ctx,
                             const struct confd_value *v)
{
    if (v->type != C_DURATION) {
        return CONFD_FALSE;
    }
    return CONFD_TRUE;
}

/*
 * xs:hexBinary
 */
static int hex_binary_to_binary(struct confd_type *self,
                                struct confd_type_ctx *ctx,
                                const char *str, unsigned int len,
                                struct confd_value *v)
{
    const char *cp;
    const char *ep;
    unsigned int blen;
    unsigned char *buf;
    unsigned char *bp;
    int n1, n2;

    if (!ws_collapse_validate(str, len, &cp, &ep)) {
        return CONFD_FALSE;
    }

    blen = (ep - cp) / 2;
    buf = (unsigned char *)confd_malloc(blen + 1);
    if (buf == NULL) {
        return CONFD_FALSE;
    }

    for (bp = buf; cp < ep - 1; bp++, cp += 2) {
        if ((n1 = HEX_TO_VAL(*cp)) == -1 ||
            (n2 = HEX_TO_VAL(*(cp+1))) == -1) {
            free(buf);
            return CONFD_FALSE;
        }
        *bp = (unsigned char)((n1 << 4) | n2);
    }

    *bp = '\0';

    CONFD_SET_BINARY(v, buf, blen);
    return CONFD_TRUE;
}

static int binary_to_hex_binary(struct confd_type *self,
                                struct confd_type_ctx *ctx,
                                const struct confd_value *v,
                                char *str, unsigned int size,
                                const char **strp)
{
    unsigned char *bp;
    unsigned char *ep;
    unsigned int blen;
    char *cp;
    int c;

    if (v->type != C_BINARY) {
        return -1;
    }

    bp = CONFD_GET_BINARY_PTR(v);
    blen = CONFD_GET_BINARY_SIZE(v);
    ep = bp + blen;

    cp = str;
    while (bp < ep && size > 1) {
        c = (*bp >> 4);
        *cp++ = VAL_TO_HEX_UPPER(c);
        size--;
        if (size > 1) {
            c = (*bp & 0xf);
            *cp++ = VAL_TO_HEX_UPPER(c);
            size--;
        }
        bp++;
    }
    if (size > 0) {
        *cp = '\0';
    }

    return blen * 2;
}

static int validate_binary(struct confd_type *self,
                           struct confd_type_ctx *ctx,
                           const struct confd_value *v)
{
    if (v->type == C_BINARY) {
        return CONFD_TRUE;
    }
    return CONFD_FALSE;
}

/*
 * xs:base64Binary
 */
static int8_t b64_to_val[] = {
    -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,
    -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,
    -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,62,-1,-1,-1,63,
    52,53,54,55,56,57,58,59,60,61,-1,-1,-1,127,-1,-1,
    -1,0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,
    15,16,17,18,19,20,21,22,23,24,25,-1,-1,-1,-1,-1,
    -1,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,
    41,42,43,44,45,46,47,48,49,50,51,-1,-1,-1,-1,-1
};
static char val_to_b64[] = {
    'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P',
    'Q','R','S','T','U','V','W','X','Y','Z','a','b','c','d','e','f',
    'g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v',
    'w','x','y','z','0','1','2','3','4','5','6','7','8','9','+','/'
};

static int base64_binary_str_to_val(struct confd_type *self,
                                    struct confd_type_ctx *ctx,
                                    const char *str, unsigned int len,
                                    struct confd_value *v)
{
    const char *cp = str;
    const char *ep = str + len;
    unsigned int blen;
    unsigned char *buf;
    unsigned char *bp;
    int c, d;
    int n = 0;
    unsigned int acc = 0;

    // internal whitespace is OK
    while (cp < ep && isspace(*cp)) {
        cp++;
    }
    while (ep > cp && isspace(*(ep-1))) {
        ep--;
    }

    blen = (ep - cp) * 3 / 4;   // might over-allocate
    buf = (unsigned char *)confd_malloc(blen + 1);
    if (buf == NULL) {
        return CONFD_FALSE;
    }
    bp = buf;

    for (; cp < ep; cp++) {
        c = *cp;
        if (!CONFD_ISASCII(c))    // non-base64 - ignore
            continue;
        d = b64_to_val[c];
        if (d < 0)              // non-base64 - ignore
            continue;
        if (d == 127)           // pad - end of input
            break;
        acc = (acc << 6) | d;
        switch (n) {
        case 1:                 // 1 byte + 4 bits
            *bp++ = (acc >> 4);
            break;
        case 2:                 // 2 bytes + 2 bits
            *bp++ = (acc >> 2);
            break;
        case 3:                 // 3 bytes
            *bp++ = acc;
            break;
        }
        n++; n %= 4;
    }

    // check for correct padding
    switch (n) {
    case 0:                     // multiple of 3 bytes - OK
        break;
    case 1:                     // malformed/truncated
        free(buf);
        return CONFD_FALSE;
    case 2:                     // 2 chars seen, 2 pad required
        c = *++cp;
        if (cp == ep || b64_to_val[c] != 127) {
            free(buf);
            return CONFD_FALSE;
        }
        cp++;
        break;
    case 3:                     // 3 chars seen, 1 pad required
        if (cp == ep) {
            free(buf);
            return CONFD_FALSE;
        }
        cp++;
        break;
    }

    // check for remaining base64 chars
    while (cp < ep) {
        c = *cp++;
        if (CONFD_ISASCII(c) && b64_to_val[c] != -1) {
            free(buf);
            return CONFD_FALSE;
        }
    }

    *bp = '\0';

    CONFD_SET_BINARY(v, buf, bp-buf);
    return CONFD_TRUE;
}

static int base64_binary_val_to_str(struct confd_type *self,
                                    struct confd_type_ctx *ctx,
                                    const struct confd_value *v,
                                    char *str, unsigned int size,
                                    const char **strp)
{
    unsigned char *bp;
    unsigned char *ep;
    unsigned int blen;
    char *cp;
    int len = 0;
    int d;
    int n = 0;
    unsigned int acc = 0;

    if (v->type != C_BINARY) {
        return -1;
    }

    bp = CONFD_GET_BINARY_PTR(v);
    blen = CONFD_GET_BINARY_SIZE(v);
    ep = bp + blen;

    cp = str;
    for (; bp < ep; bp++) {
        acc = (acc << 8) | *bp;
        switch (n) {
        case 0:
            d = acc >> 2;
            acc &= 0x3;
            if (size > 1) {
                *cp++ = val_to_b64[d];
                size--;
            }
            len++;
            break;
        case 1:
            d = acc >> 4;
            acc &= 0xf;
            if (size > 1) {
                *cp++ = val_to_b64[d];
                size--;
            }
            len++;
            break;
        case 2:
            d = acc >> 6;
            acc &= 0x3f;
            if (size > 1) {
                *cp++ = val_to_b64[d];
                size--;
            }
            len++;
            d = acc;
            acc = 0;
            if (size > 1) {
                *cp++ = val_to_b64[d];
                size--;
            }
            len++;
            break;
        }
        n++; n %= 3;
    }
    switch (n) {
    case 0:
        break;
    case 1:
        d = acc << 4;
        if (size > 1) {
            *cp++ = val_to_b64[d];
            size--;
        }
        len++;
        if (size > 1) {
            *cp++ = '=';
            size--;
        }
        len++;
        if (size > 1) {
            *cp++ = '=';
            size--;
        }
        len++;
        break;
    case 2:
        d = acc << 2;
        if (size > 1) {
            *cp++ = val_to_b64[d];
            size--;
        }
        len++;
        if (size > 1) {
            *cp++ = '=';
            size--;
        }
        len++;
        break;
    }

    if (size > 0) {
        *cp = '\0';
    }

    return len;
}


/*
 * xs:normalizedString
 */
static int normalized_string_to_string(struct confd_type *self,
                                       struct confd_type_ctx *ctx,
                                       const char *str, unsigned int len,
                                       struct confd_value *v)
{
    char *buf;
    const char *cp = str;
    const char *ep = str + len;
    char *bp;

    buf = (char *)confd_malloc(len+1);
    if (buf == NULL) {
        return CONFD_FALSE;
    }

    /* whiteSpace value="replace" */
    for (bp = buf; cp < ep; bp++, cp++) {
        if (isspace(*cp)) {
            *bp = ' ';
        } else {
            *bp = *cp;
        }
    }

    *bp = '\0';

    CONFD_SET_BUF(v, (unsigned char *)buf, len);
    return CONFD_TRUE;
}

/*
 * xs:token
 */
static int token_to_string(struct confd_type *self,
                           struct confd_type_ctx *ctx,
                           const char *str, unsigned int len,
                           struct confd_value *v)
{
    char *buf;
    unsigned int blen = 0;
    const char *cp = str;
    const char *ep = str + len;
    const char *cpp;
    char *bp;

    /* whiteSpace value="collapse" */
    while (cp < ep && isspace(*cp)) {
        cp++;
    }
    while (ep > cp && isspace(*(ep-1))) {
        ep--;
    }
    for (cpp = cp; cpp < ep; cpp++) {
        if (!isspace(*cpp) || !isspace(*(cpp+1))) {
            blen++;
        }
    }

    buf = (char *)confd_malloc(blen+1);
    if (buf == NULL) {
        return CONFD_FALSE;
    }

    /* whiteSpace value="collapse", cont. */
    bp = buf;
    while (cp < ep) {
        if (isspace(*cp)) {
            if (!isspace(*(cp+1))) {
                *bp++ = ' ';
            }
        } else {
            *bp++ = *cp;
        }
        cp++;
    }

    *bp = '\0';

    CONFD_SET_BUF(v, (unsigned char *)buf, blen);
    return CONFD_TRUE;
}

/*
 * xs:language
 */
static int validate_language(struct confd_type *self,
                             struct confd_type_ctx *ctx,
                             const struct confd_value *v)
{
    char *buf = (char *)CONFD_GET_BUFPTR(v);
    unsigned int len = CONFD_GET_BUFSIZE(v);
    char *cp = buf;
    char *ep = buf + len;

    /* pattern value="[a-zA-Z]{1,8}(-[a-zA-Z0-9]{1,8})*" */
    while (cp < ep && CONFD_ISASCII(*cp) &&
           isalpha(*cp) && cp - buf <= 8) {
        cp++;
    }
    if (cp - buf < 1 || cp - buf > 8) {
        return CONFD_FALSE;
    }
    while (cp < ep) {
        if (*cp++ != '-') {
            return CONFD_FALSE;
        }
        buf = cp;
        while (cp < ep && CONFD_ISASCII(*cp) &&
               (isalpha(*cp) || isdigit(*cp)) && cp - buf <= 8) {
            cp++;
        }
        if (cp - buf < 1 || cp - buf > 8) {
            return CONFD_FALSE;
        }
    }

    return CONFD_TRUE;
}

/*
 * xs:NMTOKEN
 */
static int validate_nmtoken(struct confd_type *self,
                            struct confd_type_ctx *ctx,
                            const struct confd_value *v)
{
    char *buf = (char *)CONFD_GET_BUFPTR(v);
    unsigned int len = CONFD_GET_BUFSIZE(v);
    char *cp = buf;
    char *ep = buf + len;

    /* pattern value="[A-Za-z0-9._:-]+" */
    if (cp == ep) {
        return CONFD_FALSE;
    }
    while (cp < ep && CONFD_ISASCII(*cp) &&
           (isalpha(*cp) || isdigit(*cp) || strchr("._:-", *cp) != NULL)) {
        cp++;
    }
    if (cp < ep) {
        return CONFD_FALSE;
    }

    return CONFD_TRUE;
}

/*
 * xs:Name
 */
static int validate_name(struct confd_type *self,
                         struct confd_type_ctx *ctx,
                         const struct confd_value *v)
{
    char *buf = (char *)CONFD_GET_BUFPTR(v);
    unsigned int len = CONFD_GET_BUFSIZE(v);
    char *cp = buf;
    char *ep = buf + len;

    /* pattern value="[A-Za-z_:][A-Za-z0-9._:-]*" */
    if (cp == ep) {
        return CONFD_FALSE;
    }
    if (!(CONFD_ISASCII(*cp) && (isalpha(*cp) || *cp == '_' || *cp == ':'))) {
        return CONFD_FALSE;
    }
    cp++;
    while (cp < ep && CONFD_ISASCII(*cp) &&
           (isalpha(*cp) || isdigit(*cp) || strchr("._:-", *cp) != NULL)) {
        cp++;
    }
    if (cp < ep) {
        return CONFD_FALSE;
    }

    return CONFD_TRUE;
}

/*
 * xs:NCName, xs:ID, xs:IDREF, xs:ENTITY
 */
static int validate_ncname(struct confd_type *self,
                           struct confd_type_ctx *ctx,
                           const struct confd_value *v)
{
    char *buf = (char *)CONFD_GET_BUFPTR(v);
    unsigned int len = CONFD_GET_BUFSIZE(v);

    /* pattern value="[^:]*" */
    if (memchr(buf, ':', len) != NULL) {
        return CONFD_FALSE;
    }

    return CONFD_TRUE;
}



/*
 * enumeration
 */
int confd_enum_str_to_val(struct confd_type *self,
                        struct confd_type_ctx *ctx,
                        const char *str, unsigned int len,
                        struct confd_value *v)
{
    struct confd_type_enums *e = (struct confd_type_enums*)self->opaque;
    unsigned int i;

    /* FIXME: whitespace */
    for (i = 0; i < e->enm_len; i++) {
        if (e->enm[i].len == len &&
            memcmp(e->enm[i].name, str, len) == 0) {
            // got a match
            v->type = C_ENUM_HASH;
            v->val.enumvalue = e->enm[i].val;
            return CONFD_TRUE;
        }
    }
    return CONFD_FALSE;
}

int confd_enum_val_to_str(struct confd_type *self,
                        struct confd_type_ctx *ctx,
                        const struct confd_value *v,
                        char *str, unsigned int size,
                        const char **strp)
{
    struct confd_type_enums *e = (struct confd_type_enums*)self->opaque;
    unsigned int i;

    if (v->type != C_ENUM_HASH) {
        return -1;
    }

    for (i = 0; i < e->enm_len; i++) {
        if (e->enm[i].val == v->val.enumvalue) {
            if (strp != NULL)
                *strp = e->enm[i].name;
            if (e->enm[i].len < size) {
                memcpy(str, e->enm[i].name, e->enm[i].len);
                str[e->enm[i].len] = '\0';
            } else if (size > 0) {
                memcpy(str, e->enm[i].name, size-1);
                str[size-1] = '\0';
            }
            return e->enm[i].len;
        }
    }
    return -1;
}

int confd_enum_validate(struct confd_type *self,
                      struct confd_type_ctx *ctx,
                      const confd_value_t *v)
{
    struct confd_type_enums *e = (struct confd_type_enums*)self->opaque;
    unsigned int i;

    if (v->type != C_ENUM_HASH) {
        return CONFD_FALSE;
    }

    for (i = 0; i < e->enm_len; i++) {
        if (e->enm[i].val == v->val.enumvalue) {
            return CONFD_TRUE;
        }
    }
    return CONFD_FALSE;
}

/*
 * identityref ("qualified enum")
 */
int confd_idref_str_to_val(struct confd_type *self,
                        struct confd_type_ctx *ctx,
                        const char *str, unsigned int len,
                        struct confd_value *v)
{
    struct confd_type_idrefs *e = (struct confd_type_idrefs*)self->opaque;
    unsigned int i;

    /* FIXME: whitespace */
    for (i = 0; i < e->idr_len; i++) {
        if ((e->idr[i].name != e->idr[i].qname &&
             memcmp(e->idr[i].name, str, len) == 0 &&
             e->idr[i].name[len] == '\0') ||
            (memcmp(e->idr[i].qname, str, len) == 0 &&
             e->idr[i].qname[len] == '\0')) {
            // got a match
            v->type = C_IDENTITYREF;
            v->val.idref = e->idr[i].idref;
            return CONFD_TRUE;
        }
    }
    return CONFD_FALSE;
}

int confd_idref_val_to_str(struct confd_type *self,
                        struct confd_type_ctx *ctx,
                        const struct confd_value *v,
                        char *str, unsigned int size,
                        const char **strp)
{
    struct confd_type_idrefs *e = (struct confd_type_idrefs*)self->opaque;
    unsigned int i;

    if (v->type != C_IDENTITYREF) {
        return -1;
    }

    for (i = 0; i < e->idr_len; i++) {
        if (e->idr[i].idref.id == v->val.idref.id &&
            e->idr[i].idref.ns == v->val.idref.ns) {
            /* we return 'qname', i.e. "prefix:id" even for unique ids
               ('name' is "id" when unique, otherwise "prefix:id") */
            if (strp != NULL)
                *strp = e->idr[i].qname;
            return snprintf(str, size, "%s", e->idr[i].qname);
        }
    }
    return -1;
}

int confd_idref_validate(struct confd_type *self,
                      struct confd_type_ctx *ctx,
                      const confd_value_t *v)
{
    struct confd_type_idrefs *e = (struct confd_type_idrefs*)self->opaque;
    unsigned int i;

    if (v->type != C_IDENTITYREF) {
        return CONFD_FALSE;
    }

    for (i = 0; i < e->idr_len; i++) {
        if (e->idr[i].idref.id == v->val.idref.id &&
            e->idr[i].idref.ns == v->val.idref.ns) {
            return CONFD_TRUE;
        }
    }
    return CONFD_FALSE;
}

/*
 * bits
 */
int confd_bits_str_to_val(struct confd_type *self,
                        struct confd_type_ctx *ctx,
                        const char *str, unsigned int len,
                        struct confd_value *v)
{
    struct confd_type_bits *b = (struct confd_type_bits*)self->opaque;
    unsigned int i;
    const char *cp = str;
    const char *ep = str + len;
    const char *cur;
    unsigned int curlen;
    uint32_t u32 = 0;
    uint64_t u64 = 0;

    // loop through the whitespace separated list of tokens
    while (1) {
        // skip initial whitespace
        while (cp < ep && isspace(*cp)) {
            ++cp;
        }
        if (cp == ep) {
            break;
        }
        // save pointer to token
        cur = cp;
        // scan past the token
        while (cp < ep && !isspace(*cp)) {
            ++cp;
        }
        curlen = cp - cur;
        // check each bit for a match on the token
        for (i = 0; i < b->bit_len; i++) {
            if (b->bit[i].len == curlen &&
                memcmp(b->bit[i].name, cur, curlen) == 0) {
                // got a match
                if (b->width == confd_width_32) {
                    u32 |= b->bit[i].mask;
                } else {
                    u64 |= b->bit[i].mask;
                }
                break;
            }
        }
        if (i == b->bit_len) {
            // no match on the token, this is an error
            return CONFD_FALSE;
        }
    }
    if (b->width == confd_width_32) {
        CONFD_SET_BIT32(v, u32);
    } else {
        CONFD_SET_BIT64(v, u64);
    }
    return CONFD_TRUE;
}

int confd_bits_val_to_str(struct confd_type *self,
                        struct confd_type_ctx *ctx,
                        const struct confd_value *v,
                        char *str, unsigned int size,
                        const char **strp)
{
    struct confd_type_bits *b = (struct confd_type_bits*)self->opaque;
    unsigned int i;
    uint64_t u;
    unsigned int len;
    char *start_str = str;

    if (b->width == confd_width_32) {
        if (v->type != C_BIT32) {
            return -1;
        }
        u = (uint64_t)v->val.b32;
    } else {
        if (v->type != C_BIT64) {
            return -1;
        }
        u = v->val.b64;
    }

    if (u == 0) {
        if (size > 0)
            *str = '\0';
        return 0;
    }

    for (i = 0; i < b->bit_len; i++) {
        if (BIT_IS_SET(b->bit[i].mask, u)) {
            if (str != start_str) {
                // we have printed at least one token; add one space
                // as a separator
                if (size > 0) {
                    if (size > 1) {
                        *str = ' ';
                        *(str+1) = '\0';
                    } else {
                        *str = '\0';
                    }
                    --size;
                }
                ++str;
            }
            len = snprintf(str, size, "%.*s",
                           (int)b->bit[i].len, b->bit[i].name);
            size = (len < size ? size - len : 0);
            str += b->bit[i].len;
        }
    }

    return str - start_str;
}

int confd_bits_validate(struct confd_type *self,
                      struct confd_type_ctx *ctx,
                      const confd_value_t *v)
{
    struct confd_type_bits *b = (struct confd_type_bits*)self->opaque;
    unsigned int i;
    uint64_t u = 0;

    if (v->type != C_BIT32 && v->type != C_BIT64) {
        return CONFD_FALSE;
    }
    // check that all bits set in are is actually defined in self
    for (i = 0; i < b->bit_len; i++) {
        u |= b->bit[i].mask;
    }
    if (v->type == C_BIT32) {
        if (~(uint32_t)u & v->val.b32) {
            return CONFD_FALSE;
        }
    } else {
        if (~u & v->val.b64) {
            return CONFD_FALSE;
        }
    }
    return CONFD_TRUE;
}

/*
 * decimal64
 */
static int validate_number_restriction(
    const struct confd_type_number_restriction *r,
    const confd_value_t *v);

int confd_get_decimal64_fraction_digits(struct confd_type *type)
{
    struct confd_type *t;

    for (t = type; t != NULL; t = t->parent) {
        if (t->validate == confd_decimal64_validate) {
            struct confd_type_decimal64 *d = t->opaque;
            return d->fraction_digits;
        }
    }
    return 0;
}

/* must be called with 1 <= d64->fraction_digits <= 18 */
int confd_pp_decimal64_value(struct confd_decimal64 *d64,
                           char *str, unsigned int size)
{
    char buf[64];
    char *bp, *dp, *ep;
    const char *sign;

    // print the value with leading zeros if needed
    ep = buf + snprintf(buf, sizeof(buf), "%0*" PRId64,
                        d64->fraction_digits + 1, d64->value);
    if (buf[0] == '-') {
        sign = "-";
        bp = &buf[1];
    } else {
        sign = "";
        bp = &buf[0];
    }
    dp = ep - d64->fraction_digits;  // decimal point

    // drop trailing zeros in fraction part (keep one)
    while (ep > dp + 1 && ep[-1] == '0') {
        ep--;
    }
    *ep = '\0';

    // drop leading zeros in integer part (keep one)
    while (bp < dp && *bp == '0') {
        bp++;
    }

    return snprintf(str, size, "%s%.*s.%s", sign, (int)(dp - bp), bp, dp);
}

int confd_decimal64_str_to_val(struct confd_type *self,
                               struct confd_type_ctx *ctx,
                               const char *str, unsigned int len,
                               struct confd_value *v)
{
    struct confd_type_decimal64 *d = self->opaque;
    int i;
    const char *cp;
    const char *ep;
    char buf[64];
    char *bp = buf;
    int got_value = 0;
    struct confd_decimal64 d64;

    if (!ws_collapse_validate(str, len, &cp, &ep)) {
        return CONFD_FALSE;
    }

    // copy integer part
    while (cp < ep && *cp != '.') {
        if (*cp != '+' && *cp != '-')
            got_value = 1;
        *bp++ = *cp++;
    }

    // skip decimal point
    if (*cp == '.') {
        got_value = 1;
        cp++;
    }

    // mustn't generate 0 out of nothing
    if (!got_value) {
        return CONFD_FALSE;
    }

    // copy/generate fraction part
    for (i = 0; i < d->fraction_digits; i++) {
        if (cp < ep) {
            *bp++ = *cp++;
        } else {
            *bp++ = '0';
        }
    }

    // mustn't be anything more
    if (cp != ep) {
        return CONFD_FALSE;
    }

    if (confd_parse_int64(buf, bp, &d64.value) == CONFD_FALSE) {
        return CONFD_FALSE;
    }
    d64.fraction_digits = d->fraction_digits;

    CONFD_SET_DECIMAL64(v, d64);

    /* since we have a "builtin" derivation, we need to validate */
    if (self->validate(self, ctx, v) == CONFD_FALSE) {
        return CONFD_FALSE;
    }

    return CONFD_TRUE;
}

int confd_decimal64_val_to_str(struct confd_type *self,
                               struct confd_type_ctx *ctx,
                               const struct confd_value *v,
                               char *str, unsigned int size,
                               const char **strp)
{
    struct confd_type_decimal64 *d = self->opaque;
    struct confd_decimal64 d64;

    if (v->type != C_DECIMAL64) {
        return -1;
    }
    d64 = CONFD_GET_DECIMAL64(v);
    if (d64.fraction_digits != d->fraction_digits) {
        return -1;
    }

    return confd_pp_decimal64_value(&d64, str, size);
}

int confd_decimal64_validate(struct confd_type *self,
                             struct confd_type_ctx *ctx,
                             const confd_value_t *v)
{
    struct confd_type_decimal64 *d = self->opaque;
    struct confd_type_number_restriction *r = &d->nr;
    struct confd_decimal64 d64;

    if (v->type != C_DECIMAL64) {
        return CONFD_FALSE;
    }
    d64 = CONFD_GET_DECIMAL64(v);
    if (d64.fraction_digits != d->fraction_digits) {
        return CONFD_FALSE;
    }
    if (r->range_len > 0)
        return validate_number_restriction(r, v);
    else
        return CONFD_TRUE;
}

/*
 * union
 */
int confd_union_str_to_val(struct confd_type *self,
                           struct confd_type_ctx *ctx,
                           const char *str, unsigned int len,
                           struct confd_value *v)
{
    struct confd_type_union *u = (struct confd_type_union*)self->opaque;
    unsigned int i;
    struct confd_type *t;

    // try to parse according to each member type
    for (i = 0; i < u->member_type_len; i++) {
        t = u->member_type[i].type;
        if (t == NULL) {
            return CONFD_FALSE;
        }
        if (t->str_to_val(t, ctx, str, len, v)) {
            // parsed and ready
            return CONFD_TRUE;
        }
    }
    // failed
    return CONFD_FALSE;
}

int confd_union_val_to_str(struct confd_type *self,
                           struct confd_type_ctx *ctx,
                           const struct confd_value *v,
                           char *str, unsigned int size,
                           const char **strp)
{
    struct confd_type_union *u = (struct confd_type_union*)self->opaque;
    unsigned int i;
    int res;
    struct confd_type *t;

    // try to format according to each member type
    for (i = 0; i < u->member_type_len; i++) {
        t = u->member_type[i].type;
        if (t == NULL) {
            return -1;
        }
        res = t->val_to_str(t, ctx, v, str, size, strp);
        if (res >= 0) {
            return res;
        }
    }
    // no member type could format the value
    return -1;
}

int confd_union_validate(struct confd_type *self,
                         struct confd_type_ctx *ctx,
                         const confd_value_t *v)
{
    struct confd_type_union *u = (struct confd_type_union*)self->opaque;
    unsigned int i;
    struct confd_type *t;

    // try to validate according to each member type
    for (i = 0; i < u->member_type_len; i++) {
        t = u->member_type[i].type;
        if (t == NULL) {
            return CONFD_FALSE;
        }
        if (t->validate(t, ctx, v) == CONFD_TRUE) {
            return CONFD_TRUE;
        }
    }
    return CONFD_FALSE;
}

/*
 * yang:dotted-quad (confd:dottedQuad)
 */
static int dquad_str_to_val(struct confd_type *self,
                            struct confd_type_ctx *ctx,
                            const char *str, unsigned int len,
                            struct confd_value *v)
{
    const char *cp;
    const char *cp1;
    const char *ep;
    int i;
    struct confd_dotted_quad dquad;

    if (!ws_collapse_validate(str, len, &cp, &ep)) {
        return CONFD_FALSE;
    }

    for (i = 0; cp < ep && i < 4; i++) {
        if ((cp1 = str_to_uval8(cp, ep, '.', 0, &dquad.quad[i])) == NULL) {
            // no dot after last number
            if (!confd_parse_uint8(cp, ep, &dquad.quad[i])) {
                return CONFD_FALSE;
            }
            cp = ep;
        } else {
            cp = cp1;
        }
    }
    if (cp != ep || i != 4) {
        return CONFD_FALSE;
    }

    CONFD_SET_DQUAD(v, dquad);
    return CONFD_TRUE;
}

static int dquad_val_to_str(struct confd_type *self,
                                 struct confd_type_ctx *ctx,
                                 const struct confd_value *v,
                                 char *str, unsigned int size,
                                 const char **strp)
{
    struct confd_dotted_quad dquad;

    if (v->type != C_DQUAD) {
        return -1;
    }

    dquad = CONFD_GET_DQUAD(v);
    return snprintf(str, size, "%d.%d.%d.%d", dquad.quad[0],
                    dquad.quad[1], dquad.quad[2], dquad.quad[3]);
}

static int validate_dquad(struct confd_type *self,
                          struct confd_type_ctx *ctx,
                          const struct confd_value *v)
{
    if (v->type != C_DQUAD) {
        return CONFD_FALSE;
    }

    return CONFD_TRUE;
}

/*
 * yang:hex-string (confd:hexString)
 */
static int hexstr_to_binary(const char *str, unsigned int len,
                            unsigned char **bufp, unsigned int *blenp)
{
    const char *cp;
    const char *ep;
    unsigned int blen;
    unsigned char *buf;
    unsigned char *bp;
    int n1, n2;

    if (!ws_collapse_validate(str, len, &cp, &ep)) {
        return CONFD_FALSE;
    }

    blen = (ep - cp + 1) / 3;
    buf = (unsigned char *)confd_malloc(blen + 1);
    if (buf == NULL) {
        return CONFD_FALSE;
    }

    for (bp = buf; cp < ep - 1; bp++, cp += 3) {
        if ((n1 = HEX_TO_VAL(*cp)) == -1 ||
            (n2 = HEX_TO_VAL(*(cp+1))) == -1) {
            free(buf);
            return CONFD_FALSE;
        }
        *bp = (unsigned char)((n1 << 4) | n2);
        if (cp < ep - 2 && *(cp+2) != ':') {
            free(buf);
            return CONFD_FALSE;
        }
    }

    *bp = '\0';
    *bufp = buf;
    *blenp = blen;

    return CONFD_TRUE;
}

static int hexstr_str_to_val(struct confd_type *self,
                             struct confd_type_ctx *ctx,
                             const char *str, unsigned int len,
                             struct confd_value *v)
{
    unsigned char *buf;
    unsigned int blen;

    if (hexstr_to_binary(str, len, &buf, &blen) == CONFD_FALSE) {
        return CONFD_FALSE;
    }
    CONFD_SET_HEXSTR(v, buf, blen);
    return CONFD_TRUE;
}

static int binary_to_hexstr(char *str, unsigned int size,
                            unsigned char *bp, unsigned int blen)
{
    unsigned char *ep;
    char *cp;
    int c;

    ep = bp + blen;

    cp = str;
    while (bp < ep && size > 1) {
        c = (*bp >> 4);
        *cp++ = VAL_TO_HEX(c);
        size--;
        if (size > 1) {
            c = (*bp & 0xf);
            *cp++ = VAL_TO_HEX(c);
            size--;
        }
        if (bp < ep - 1 && size > 1) {
            *cp++ = ':';
            size--;
        }
        bp++;
    }
    if (size > 0) {
        *cp = '\0';
    }

    return blen * 3 - 1;
}

static int hexstr_val_to_str(struct confd_type *self,
                             struct confd_type_ctx *ctx,
                             const struct confd_value *v,
                             char *str, unsigned int size,
                             const char **strp)
{
    if (v->type != C_HEXSTR) {
        return -1;
    }

    return binary_to_hexstr(str, size, CONFD_GET_HEXSTR_PTR(v),
                             CONFD_GET_HEXSTR_SIZE(v));
}

static int validate_hexstr(struct confd_type *self,
                           struct confd_type_ctx *ctx,
                           const struct confd_value *v)
{
    if (v->type != C_HEXSTR) {
        return CONFD_FALSE;
    }

    return CONFD_TRUE;
}

/*
 * confd:size
 */
static int confd_size_str_to_val(struct confd_type *self,
                                 struct confd_type_ctx *ctx,
                                 const char *str, unsigned int len,
                                 struct confd_value *v)
{
    const char *cp;
    const char *ep;
    uint32_t value;
    uint64_t size = 0;

    if (!ws_collapse_validate(str, len, &cp, &ep)) {
        return CONFD_FALSE;
    }

    v->type = C_NOEXISTS;

    if (cp >= ep || *cp != 'S') {
        return CONFD_FALSE;
    }
    ++cp;
    cp = str_to_uval32(cp, ep, &value);
    if (cp == NULL || cp >= ep) {
        return CONFD_FALSE;
    }
    // G M K B
    if (*cp == 'G') {
        size = value;
        size *= 1024*1024*1024;
        ++cp;
        if (cp >= ep) {
            CONFD_SET_UINT64(v, size);
            return CONFD_TRUE;
        }
        cp = str_to_uval32(cp, ep, &value);
        if (cp == NULL || cp >= ep) {
            return CONFD_FALSE;
        }
    }
    if (*cp == 'M') {
        size += value*1024*1024;
        ++cp;
        if (cp >= ep) {
            CONFD_SET_UINT64(v, size);
            return CONFD_TRUE;
        }
        cp = str_to_uval32(cp, ep, &value);
        if (cp == NULL || cp >= ep) {
            return CONFD_FALSE;
        }
    }
    if (*cp == 'K') {
        size += value*1024;
        ++cp;
        if (cp >= ep) {
            CONFD_SET_UINT64(v, size);
            return CONFD_TRUE;
        }
        cp = str_to_uval32(cp, ep, &value);
        if (cp == NULL || cp >= ep) {
            return CONFD_FALSE;
        }
    }
    if (*cp == 'B') {
        size += value;
        ++cp;
        if (cp >= ep) {
            CONFD_SET_UINT64(v, size);
            return CONFD_TRUE;
        }
        cp = str_to_uval32(cp, ep, &value);
        if (cp == NULL || cp >= ep) {
            return CONFD_FALSE;
        }
    }

    // Garbage at end
    return CONFD_FALSE;
}

int confd_size_val_to_str(struct confd_type *self,
                          struct confd_type_ctx *ctx,
                          const struct confd_value *v,
                          char *str, unsigned int size,
                          const char **strp)
{
    const char *start_str = str;
    unsigned int len;
    uint32_t gigs = 0;
    uint32_t megs = 0;
    uint32_t ks = 0;
    uint32_t bytes = 0;
    uint64_t value = 0;

    if (v->type != C_UINT64) {
        return -1;
    }

    value = CONFD_GET_UINT64(v);
    if (value != 0) {
        bytes = value % 1024;
        value /= 1024;
    }
    if (value != 0) {
        ks = value % 1024;
        value /= 1024;
    }
    if (value != 0) {
        megs = value % 1024;
        value /= 1024;
    }
    if (value != 0) {
        gigs = value % 1024;
        value /= 1024;
    }
    if (gigs == 0 && megs == 0 && ks == 0 && bytes == 0) {
        len = snprintf(str, size, "S0B");
        ADVANCE_PTR(str, size, len);
        return str - start_str;
    }

    len = snprintf(str, size, "S");
    ADVANCE_PTR(str, size, len);

    if (gigs != 0) {
        len = snprintf(str, size, "%dG", gigs);
        ADVANCE_PTR(str, size, len);
    }
    if (megs != 0) {
        len = snprintf(str, size, "%dM", megs);
        ADVANCE_PTR(str, size, len);
    }
    if (ks != 0) {
        len = snprintf(str, size, "%dK", ks);
        ADVANCE_PTR(str, size, len);
    }
    if (bytes != 0) {
        len = snprintf(str, size, "%dB", bytes);
        ADVANCE_PTR(str, size, len);
    }

    return str-start_str;
}

/*
 * confd:hexList
 */
static int hex_list_str_to_val(struct confd_type *self,
                               struct confd_type_ctx *ctx,
                               const char *str, unsigned int len,
                               struct confd_value *v)
{
    unsigned char *buf;
    unsigned int blen;

    if (hexstr_to_binary(str, len, &buf, &blen) == CONFD_FALSE) {
        return CONFD_FALSE;
    }
    CONFD_SET_BINARY(v, buf, blen);
    return CONFD_TRUE;
}

static int hex_list_val_to_str(struct confd_type *self,
                               struct confd_type_ctx *ctx,
                               const struct confd_value *v,
                               char *str, unsigned int size,
                               const char **strp)
{
    if (v->type != C_BINARY) {
        return -1;
    }

    return binary_to_hexstr(str, size, CONFD_GET_BINARY_PTR(v),
                            CONFD_GET_BINARY_SIZE(v));
}

/*
 * confd:octetList
 */
static int octet_list_str_to_val(struct confd_type *self,
                                 struct confd_type_ctx *ctx,
                                 const char *str, unsigned int len,
                                 struct confd_value *v)
{
    const char *cp;
    const char *cp1;
    const char *ep;
    unsigned int blen = 1;
    unsigned char *buf;
    unsigned char *bp;

    if (!ws_collapse_validate(str, len, &cp, &ep)) {
        return CONFD_FALSE;
    }

    for (cp1 = cp; cp1 < ep; cp1++) {
        if (*cp1 == '.')
            blen++;
    }
    buf = (unsigned char *)confd_malloc(blen + 1);
    if (buf == NULL) {
        return CONFD_FALSE;
    }

    for (bp = buf; cp < ep; bp++) {
        if ((cp1 = str_to_uval8(cp, ep, '.', 0, bp)) == NULL) {
            // no dot after last number
            if (!confd_parse_uint8(cp, ep, bp)) {
                free(buf);
                return CONFD_FALSE;
            }
            cp = ep;
        } else {
            cp = cp1;
        }
    }

    *bp = '\0';

    CONFD_SET_BINARY(v, buf, blen);
    return CONFD_TRUE;
}

static int octet_list_val_to_str(struct confd_type *self,
                                 struct confd_type_ctx *ctx,
                                 const struct confd_value *v,
                                 char *str, unsigned int size,
                                 const char **strp)
{
    unsigned char *bp;
    unsigned char *ep;
    unsigned int blen;
    char *cp;
    unsigned int len;

    if (v->type != C_BINARY) {
        return -1;
    }

    bp = CONFD_GET_BINARY_PTR(v);
    blen = CONFD_GET_BINARY_SIZE(v);
    ep = bp + blen;

    if (blen == 0) {
        if (size > 0)
            *str = '\0';
        return 0;
    }
    cp = str;
    len = snprintf(cp, size, "%d", *bp++);
    ADVANCE_PTR(cp, size, len);
    while (bp < ep) {
        len = snprintf(cp, size, ".%d", *bp);
        ADVANCE_PTR(cp, size, len);
        bp++;
    }

    return cp - str;
}

/*
 * confd:oid
 */
static int oid_str_to_val(struct confd_type *self,
                          struct confd_type_ctx *ctx,
                          const char *str, unsigned int len,
                          struct confd_value *v)
{
    const char *cp;
    const char *ep;
    struct confd_snmp_oid *oid;
    int i;

    if (!ws_collapse_validate(str, len, &cp, &ep)) {
        return CONFD_FALSE;
    }

    oid = (struct confd_snmp_oid *)confd_malloc(sizeof(struct confd_snmp_oid));
    if (oid == NULL) {
        return CONFD_FALSE;
    }

    for (i = 0; cp < ep; i++) {
        if (i >= 128) {
            free(oid);
            return CONFD_FALSE;
        }
        if ((cp = str_to_uval32(cp, ep, (uint32_t *)&oid->oid[i])) == NULL) {
            free(oid);
            return CONFD_FALSE;
        }
        if (cp < ep) {
            if (*cp++ != '.') {
                free(oid);
                return CONFD_FALSE;
            }
        }
    }
    oid->len = i;

    CONFD_SET_OID(v, oid);
    if (self->validate(self, ctx, v) == CONFD_FALSE) {
        free(oid);
        return CONFD_FALSE;
    }
    return CONFD_TRUE;
}

static int oid_val_to_str(struct confd_type *self,
                          struct confd_type_ctx *ctx,
                          const struct confd_value *v,
                          char *str, unsigned int size,
                          const char **strp)
{
    struct confd_snmp_oid *oid;
    int i;
    char *cp;
    unsigned int len;

    if (v->type != C_OID) {
        return -1;
    }

    oid = CONFD_GET_OID(v);
    if (oid->len < 2) {
        return -1;
    }

    cp = str;
    len = snprintf(cp, size, "%d", oid->oid[0]);
    ADVANCE_PTR(cp, size, len);
    for (i = 1; i < oid->len; i++) {
        len = snprintf(cp, size, ".%d", oid->oid[i]);
        ADVANCE_PTR(cp, size, len);
    }

    return cp - str;
}

static int validate_oid(struct confd_type *self,
                        struct confd_type_ctx *ctx,
                        const struct confd_value *v)
{
    struct confd_snmp_oid *oid;

    if (v->type != C_OID) {
        return CONFD_FALSE;
    }
    oid = CONFD_GET_OID(v);
    // need at least two identifiers
    if (oid->len < 2) {
        return CONFD_FALSE;
    }
    // first identifier must be one of 0,1,2
    if (oid->oid[0] >= 3) {
        return CONFD_FALSE;
    }
    // ASN.1 requirement
    if (oid->oid[0] * 40 + oid->oid[1] > 255) {
        return CONFD_FALSE;
    }
    return CONFD_TRUE;
}


/*
 * list
 */
int confd_list_str_to_val(struct confd_type *self,
                          struct confd_type_ctx *ctx,
                          const char *str, unsigned int len,
                          struct confd_value *v)
{
    struct confd_type_list *l = (struct confd_type_list*)self->opaque;
    struct confd_type *t;
    const char *cp = str;
    const char *ep = str + len;
    const char *cur;
    unsigned int curlen;
    int cnt;
    struct confd_list res;

    t = l->type;
    if (t == NULL) {
        return CONFD_FALSE;
    }

    /* first we have to scan the string to see how many tokens there are */
    cnt = 0;
    while (1) {
        // skip initial whitespace
        while (cp < ep && isspace(*cp)) {
            ++cp;
        }
        if (cp == ep) {
            break;
        }
        // scan past the token
        while (cp < ep && !isspace(*cp)) {
            ++cp;
        }
        ++cnt;
    }

    if (cnt > 0) {
        res.ptr = (confd_value_t*)confd_malloc(cnt * sizeof(confd_value_t));
        if (res.ptr == NULL) {
            return CONFD_FALSE;
        }
        res.size = cnt;

    } else {
        // Empty list
        res.ptr = NULL;
        res.size = 0;

        v->type = C_LIST;
        v->val.list = res;
        return CONFD_TRUE;

    }

    /* now scan again, and parse each token */
    cp = str;
    cnt = 0;
    while (1) {
        // skip initial whitespace
        while (cp < ep && isspace(*cp)) {
            ++cp;
        }
        if (cp == ep) {
            break;
        }
        // save pointer to token
        cur = cp;
        // scan past the token
        while (cp < ep && !isspace(*cp)) {
            ++cp;
        }
        curlen = cp - cur;
        // parse accoring to the list type
        if (!t->str_to_val(t, ctx, cur, curlen, &res.ptr[cnt])) {
            while (--cnt >= 0) {
                confd_free_value(&res.ptr[cnt]);
            }
            free(res.ptr);
            return CONFD_FALSE;
        }
        cnt++;
    }
    v->type = C_LIST;
    v->val.list = res;
    return CONFD_TRUE;
}

int confd_list_val_to_str(struct confd_type *self,
                          struct confd_type_ctx *ctx,
                          const struct confd_value *v,
                          char *str, unsigned int size,
                          const char **strp)
{
    struct confd_type_list *l = (struct confd_type_list*)self->opaque;
    struct confd_type *t;
    unsigned int i;
    int len;
    char *start_str = str;

    if (v->type != C_LIST) {
        return -1;
    }

    t = l->type;
    if (t == NULL) {
        return -1;
    }

    if (v->val.list.size == 0) {
        if (size > 0)
            *str = '\0';
        return 0;
    }

    // try to format according to the list type
    for (i = 0; i < v->val.list.size; i++) {
        if (str != start_str) {
            // we have printed at least one token; add one space
            // as a separator
            if (size > 0) {
                if (size > 1) {
                    *str = ' ';
                    *(str+1) = '\0';
                } else {
                    *str = '\0';
                }
                --size;
            }
            ++str;
        }

        len = t->val_to_str(t, ctx, &v->val.list.ptr[i], str, size, NULL);
        if (len < 0) {
            // the list value could not be formatted
            return -1;
        }
        size = (len < size ? size - len : 0);
        str += len;
    }

    return str - start_str;
}

int confd_list_validate(struct confd_type *self,
                        struct confd_type_ctx *ctx,
                        const confd_value_t *v)
{
    struct confd_type_list *l = (struct confd_type_list*)self->opaque;
    struct confd_type *t;
    unsigned int i;

    if (v->type != C_LIST || l->type == NULL) {
        return CONFD_FALSE;
    }

    if (v->val.list.size == 0) {
        // Empty list is OK
        return CONFD_TRUE;
    }

    t = l->type;
    // validate each list item
    for (i = 0; i < v->val.list.size; i++) {
        if (t->validate(t, ctx, &v->val.list.ptr[i]) == CONFD_FALSE) {
            return CONFD_FALSE;
        }
    }
    return CONFD_TRUE;
}

/*
 * number restrictions
 */
static int validate_number_restriction(
    const struct confd_type_number_restriction *r,
    const confd_value_t *v)
{
    unsigned int i;
    int res, is_within_range;

    /* check each range lo,hi for one match */
    for (i = 0; i < r->range_len; i++) {
        is_within_range = 1;
        if (r->range[i].lo.type != C_NOEXISTS) {
            res = confd_val_num_cmp(&r->range[i].lo, v);
            if (BIT_IS_SET(CONFD_RANGE_MIN_INCLUSIVE, r->range[i].flags)) {
                if (res > 0) { // v < lo
                    is_within_range = 0;
                }
            } else {
                if (res >= 0) {  // v =< lo
                    is_within_range = 0;
                }
            }
        }
        if (!is_within_range) {
            continue;
        }
        if (r->range[i].hi.type != C_NOEXISTS) {
            res = confd_val_num_cmp(v, &r->range[i].hi);
            if (BIT_IS_SET(CONFD_RANGE_MAX_INCLUSIVE, r->range[i].flags)) {
                if (res <= 0) { // v <= hi
                    return CONFD_TRUE;
                }
            } else if (res < 0) { // v < hi
                return CONFD_TRUE;
            }
        } else {
            return CONFD_TRUE;
        }
    }
    // no range matched
    return CONFD_FALSE;
}

int confd_type_validate_number_restriction(struct confd_type *self,
                                           struct confd_type_ctx *ctx,
                                           const confd_value_t *v)
{
    struct confd_type_number_restriction *r =
        (struct confd_type_number_restriction*)self->opaque;

    /* first validate according to parent */
    if (self->parent == NULL) {
        return CONFD_FALSE;
    }
    if (self->parent->validate(self->parent, ctx, v) == CONFD_FALSE) {
        return CONFD_FALSE;
    }

    return validate_number_restriction(r, v);
}

/*
 * string restrictions
 */
int confd_type_validate_string_restriction(struct confd_type *self,
                                           struct confd_type_ctx *ctx,
                                           const confd_value_t *v)
{
    struct confd_type_string_restriction *r =
        (struct confd_type_string_restriction*)self->opaque;
    unsigned int i;
    int is_within_range = 1;
    int len = 0;

    /* first validate according to parent */
    if (self->parent == NULL) {
        return CONFD_FALSE;
    }
    if (self->parent->validate(self->parent, ctx, v) == CONFD_FALSE) {
        return CONFD_FALSE;
    }

    /* check each length */
    if (r->length_len > 0) {
        if (v->type == C_BUF) {
            len = v->val.buf.size;
        } else if (v->type == C_STR) {
            len = strlen(v->val.s);
        } else {
            return CONFD_FALSE;
        }
    }
    for (i = 0; i < r->length_len; i++) {
        is_within_range = 1;
        if (r->length[i].lo.type != C_NOEXISTS) {
            if (len < r->length[i].lo.val.i32) {
                is_within_range = 0;
            }
        }
        if (!is_within_range) {
            continue;
        }
        if (r->length[i].hi.type != C_NOEXISTS) {
            if (len > r->length[i].hi.val.i32) {
                is_within_range = 0;
            } else {
                break; // found one matching length range
            }
        } else {
            break; // found one matching length range
        }
    }

    if (!is_within_range) {
        return CONFD_FALSE;
    }

#if HAVE_REGEX_H
    if (r->has_pattern) {
        char src[256];
        char *p;
        int res;

        len = CONFD_GET_BUFSIZE(v);
        if ((size_t)len >= sizeof(src)-1) {
            p = (char*)confd_malloc(sizeof(char) * len + 1);
            if (p == NULL) {
                return CONFD_FALSE;
            }
        } else { // normal case, don't malloc
            p = src;
        }
        memcpy(p, CONFD_GET_BUFPTR(v), len);
        *(p + len) = '\0';

        if (r->has_pattern == 2) { // text pattern, need to compile & free
            regex_t cpattern;
            regcomp(&cpattern, r->pattern.text, REG_EXTENDED | REG_NOSUB);
            res = regexec(&cpattern, p, 0, NULL, 0);
            regfree(&cpattern);
        } else {
            res = 0;
        }
        if ((size_t)len >= sizeof(src)-1) {
            free(p);
        }
        if (res != 0) {
            return CONFD_FALSE;
        }
    }
#endif

    return CONFD_TRUE;
}

/*
 * list restrictions
 */
int confd_type_validate_list_restriction(struct confd_type *self,
                                         struct confd_type_ctx *ctx,
                                         const confd_value_t *v)
{
    struct confd_type_list_restriction *r =
        (struct confd_type_list_restriction*)self->opaque;
    unsigned int i;
    int is_within_range = 1;
    int len = 0;

    /* first validate according to parent */
    if (self->parent == NULL) {
        return CONFD_FALSE;
    }
    if (self->parent->validate(self->parent, ctx, v) == CONFD_FALSE) {
        return CONFD_FALSE;
    }

    /* check each length */
    if (r->length_len > 0) {
        if (v->type == C_LIST) {
            len = v->val.list.size;
        } else {
            return CONFD_FALSE;
        }
    }
    for (i = 0; i < r->length_len; i++) {
        is_within_range = 1;
        if (r->length[i].lo.type != C_NOEXISTS) {
            if (len < r->length[i].lo.val.i32) {
                is_within_range = 0;
            }
        }
        if (!is_within_range) {
            continue;
        }
        if (r->length[i].hi.type != C_NOEXISTS) {
            if (len > r->length[i].hi.val.i32) {
                is_within_range = 0;
            } else {
                break; // found one matching length range
            }
        } else {
            break; // found one matching length range
        }
    }

    if (!is_within_range) {
        return CONFD_FALSE;
    }

    return CONFD_TRUE;
}


/* placeholders for user-defined types - always fail */

static int no_str_to_val(struct confd_type *self,
                         struct confd_type_ctx *ctx,
                         const char *str, unsigned int len,
                         confd_value_t *v)
{
    return CONFD_FALSE;
}

static int no_val_to_str(struct confd_type *self,
                         struct confd_type_ctx *ctx,
                         const confd_value_t *v,
                         char *str, unsigned int len,
                         const char **strp)
{
    return -1;
}

static int no_validate(struct confd_type *self,
                       struct confd_type_ctx *ctx,
                       const confd_value_t *v)
{
    return CONFD_FALSE;
}

static struct confd_type_member_type confd_inetAddress_union_member[] = {
    {.type = NULL},
    {.type = NULL},
};
static struct confd_type_union confd_inetAddress_union = {
    .member_type = confd_inetAddress_union_member,
    .member_type_len = 2
};

static struct confd_type_member_type confd_inetAddressIP_union_member[] = {
    {.type = NULL},
    {.type = NULL},
};
static struct confd_type_union confd_inetAddressIP_union = {
    .member_type = confd_inetAddressIP_union_member,
    .member_type_len = 2
};

static struct confd_type_member_type confd_ipPrefix_union_member[] = {
    {.type = NULL},
    {.type = NULL},
};
static struct confd_type_union confd_ipPrefix_union = {
    .member_type = confd_ipPrefix_union_member,
    .member_type_len = 2
};

static struct confd_type_member_type confd_ip_and_plen_union_member[] = {
    {.type = NULL},
    {.type = NULL},
};
static struct confd_type_union confd_ip_and_plen_union = {
    .member_type = confd_ip_and_plen_union_member,
    .member_type_len = 2
};

// .type will be set at runtime
static struct confd_type_list xs_nmtoken_list_list;

// .lo will be set correctly at runtime
static struct confd_length xs_nmtokens_length[] = {
    {.lo = {.type = C_NOEXISTS},
     .hi = {.type = C_NOEXISTS},
    }
};
static struct confd_type_list_restriction xs_nmtokens_restriction = {
    .length = xs_nmtokens_length,
    .length_len = 1
};

// .type will be set at runtime
static struct confd_type_list xs_idref_list_list;

// .lo will be set correctly at runtime
static struct confd_length xs_idrefs_length[] = {
    {.lo = {.type = C_NOEXISTS},
     .hi = {.type = C_NOEXISTS},
    }
};
static struct confd_type_list_restriction xs_idrefs_restriction = {
    .length = xs_idrefs_length,
    .length_len = 1
};

// .hi will be set correctly at runtime
static struct confd_range xs_non_positive_integer_range[] = {
    {.lo = {.type = C_NOEXISTS},
     .hi = {.type = C_NOEXISTS},
     .flags = CONFD_RANGE_MIN_INCLUSIVE | CONFD_RANGE_MAX_INCLUSIVE
    },
};
static struct confd_type_number_restriction
xs_non_positive_integer_restriction = {
    .range =  xs_non_positive_integer_range,
    .range_len = 1
};

// .hi will be set correctly at runtime
static struct confd_range xs_negative_integer_range[] = {
    {.lo = {.type = C_NOEXISTS},
     .hi = {.type = C_NOEXISTS},
     .flags = CONFD_RANGE_MIN_INCLUSIVE | CONFD_RANGE_MAX_INCLUSIVE
    },
};
static struct confd_type_number_restriction xs_negative_restriction = {
    .range = xs_negative_integer_range,
    .range_len = 1
};

// .lo will be set correctly at runtime
static struct confd_range xs_non_negative_integer_range[] = {
    {.lo = {.type = C_NOEXISTS},
     .hi = {.type = C_NOEXISTS},
     .flags = CONFD_RANGE_MIN_INCLUSIVE | CONFD_RANGE_MAX_INCLUSIVE
    },
};
static struct confd_type_number_restriction xs_non_negative_restriction = {
    .range = xs_non_negative_integer_range,
    .range_len = 1
};

// .lo will be set correctly at runtime
static struct confd_range xs_positive_integer_range[] = {
    {.lo = {.type = C_NOEXISTS},
     .hi = {.type = C_NOEXISTS},
     .flags = CONFD_RANGE_MIN_INCLUSIVE | CONFD_RANGE_MAX_INCLUSIVE
    },
};
static struct confd_type_number_restriction xs_positive_integer_restriction = {
    .range =  xs_positive_integer_range,
    .range_len = 1
};

struct confd_type confd_types[CE_MAXTYPE] = {

    [C_BUF] = {
        .defval = NULL,
        .parent = NULL,
        .validate = validate_string,
        .str_to_val = str_to_string,
        .val_to_str = string_to_str,
        .opaque = NULL
    },

    // xs:hexBinary as the "default" C_BINARY type
    [C_BINARY] = {
        .defval = NULL,
        .parent = NULL,
        .validate = validate_binary,
        .str_to_val = hex_binary_to_binary,
        .val_to_str = binary_to_hex_binary,
        .opaque = NULL
    },

    [C_INT8] = {
        .defval = NULL,
        .parent = NULL,
        .validate = validate_int8,
        .str_to_val = str_to_int8,
        .val_to_str = int8_to_str,
        .opaque = NULL
    },

    [C_INT16] = {
        .defval = NULL,
        .parent = NULL,
        .validate = validate_int16,
        .str_to_val = str_to_int16,
        .val_to_str = int16_to_str,
        .opaque = NULL
    },

    [C_INT32] = {
        .defval = NULL,
        .parent = NULL,
        .validate = validate_int32,
        .str_to_val = str_to_int32,
        .val_to_str = int32_to_str,
        .opaque = NULL
    },

    [C_INT64] = {
        .defval = NULL,
        .parent = NULL,
        .validate = validate_int64,
        .str_to_val = str_to_int64,
        .val_to_str = int64_to_str,
        .opaque = NULL
    },

    [C_UINT8] = {
        .defval = NULL,
        .parent = NULL,
        .validate = validate_uint8,
        .str_to_val = str_to_uint8,
        .val_to_str = uint8_to_str,
        .opaque = NULL
    },

    [C_UINT16] = {
        .defval = NULL,
        .parent = NULL,
        .validate = validate_uint16,
        .str_to_val = str_to_uint16,
        .val_to_str = uint16_to_str,
        .opaque = NULL
    },

    [C_UINT32] = {
        .defval = NULL,
        .parent = NULL,
        .validate = validate_uint32,
        .str_to_val = str_to_uint32,
        .val_to_str = uint32_to_str
    },

    [C_UINT64] = {
        .defval = NULL,
        .parent = NULL,
        .validate = validate_uint64,
        .str_to_val = str_to_uint64,
        .val_to_str = uint64_to_str,
        .opaque = NULL
    },

    [C_DOUBLE] = {
        .defval = NULL,
        .parent = NULL,
        .validate = validate_double,
        .str_to_val = str_to_double,
        .val_to_str = double_to_str,
        .opaque = NULL
    },

    [C_IPV4] = {
        .defval = NULL,
        .parent = NULL,
        .validate = validate_ipv4,
        .str_to_val = str_to_ipv4,
        .val_to_str = ipv4_to_str,
        .opaque = NULL
    },

    [C_IPV6] = {
        .defval = NULL,
        .parent = NULL,
        .validate = validate_ipv6,
        .str_to_val = str_to_ipv6,
        .val_to_str = ipv6_to_str,
        .opaque = NULL
    },

    [C_BOOL] = {
        .defval = NULL,
        .parent = NULL,
        .validate = validate_bool,
        .str_to_val = str_to_bool,
        .val_to_str = bool_to_str,
        .opaque = NULL
    },

    [C_DATETIME] = {
        .defval = NULL,
        .parent = NULL,
        .validate = validate_datetime,
        .str_to_val = str_to_datetime,
        .val_to_str = datetime_to_str,
        .opaque = NULL
    },

    [C_DATE] = {
        .defval = NULL,
        .parent = NULL,
        .validate = validate_date,
        .str_to_val = str_to_date,
        .val_to_str = date_to_str,
        .opaque = NULL
    },

    [C_TIME] = {
        .defval = NULL,
        .parent = NULL,
        .validate = validate_time,
        .str_to_val = str_to_time,
        .val_to_str = time_to_str,
        .opaque = NULL
    },

    [C_DURATION] = {
        .defval = NULL,
        .parent = NULL,
        .validate = validate_duration,
        .str_to_val = str_to_duration,
        .val_to_str = duration_to_str,
        .opaque = NULL
    },

    [C_OID] = {
        .defval = NULL,
        .parent = NULL,
        .validate = validate_oid,
        .str_to_val = oid_str_to_val,
        .val_to_str = oid_val_to_str,
        .opaque = NULL
    },

    [C_IPV4PREFIX] = {
        .defval = NULL,
        .parent = NULL,
        .validate = validate_ipv4prefix,
        .str_to_val = str_to_ipv4prefix,
        .val_to_str = ipv4prefix_to_str,
        .opaque = NULL
    },

    [C_IPV6PREFIX] = {
        .defval = NULL,
        .parent = NULL,
        .validate = validate_ipv6prefix,
        .str_to_val = str_to_ipv6prefix,
        .val_to_str = ipv6prefix_to_str,
        .opaque = NULL
    },

    [C_DQUAD] = {
        .defval = NULL,
        .parent = NULL,
        .str_to_val = dquad_str_to_val,
        .val_to_str = dquad_val_to_str,
        .validate = validate_dquad,
        .opaque = NULL
    },

    [C_HEXSTR] = {
        .defval = NULL,
        .parent = NULL,
        .str_to_val = hexstr_str_to_val,
        .val_to_str = hexstr_val_to_str,
        .validate = validate_hexstr,
        .opaque = NULL
    },

    [C_IPV4_AND_PLEN] = {
        .defval = NULL,
        .parent = NULL,
        .validate = validate_ipv4_and_plen,
        .str_to_val = str_to_ipv4_and_plen,
        .val_to_str = ipv4_and_plen_to_str,
        .opaque = NULL
    },

    [C_IPV6_AND_PLEN] = {
        .defval = NULL,
        .parent = NULL,
        .validate = validate_ipv6_and_plen,
        .str_to_val = str_to_ipv6_and_plen,
        .val_to_str = ipv6_and_plen_to_str,
        .opaque = NULL
    },

    [CE_INET_ADDRESS] = {
        .parent = NULL,
        .defval = NULL,
        .str_to_val = confd_union_str_to_val,
        .val_to_str = confd_union_val_to_str,
        .validate = confd_union_validate,
        .opaque = (void *)&confd_inetAddress_union
    },

    [CE_INET_ADDRESS_IP] = {
        .parent = NULL,
        .defval = NULL,
        .str_to_val = confd_union_str_to_val,
        .val_to_str = confd_union_val_to_str,
        .validate = confd_union_validate,
        .opaque = (void *)&confd_inetAddressIP_union
    },

    [CE_IPPREFIX] = {
        .parent = NULL,
        .defval = NULL,
        .str_to_val = confd_union_str_to_val,
        .val_to_str = confd_union_val_to_str,
        .validate = confd_union_validate,
        .opaque = (void *)&confd_ipPrefix_union
    },

    [CE_IP_AND_PLEN] = {
        .parent = NULL,
        .defval = NULL,
        .str_to_val = confd_union_str_to_val,
        .val_to_str = confd_union_val_to_str,
        .validate = confd_union_validate,
        .opaque = (void *)&confd_ip_and_plen_union
    },

    [CE_SIZE] = {
        .parent = NULL,
        .defval = NULL,
        .str_to_val = confd_size_str_to_val,
        .val_to_str = confd_size_val_to_str,
        .validate = validate_uint64,
        .opaque = NULL
    },

    [CE_HEX_LIST] = {
        .parent = &confd_types[C_BINARY],
        .defval = NULL,
        .str_to_val = hex_list_str_to_val,
        .val_to_str = hex_list_val_to_str,
        .validate = NULL,
        .opaque = NULL
    },

    [CE_OCTET_LIST] = {
        .parent = &confd_types[C_BINARY],
        .defval = NULL,
        .str_to_val = octet_list_str_to_val,
        .val_to_str = octet_list_val_to_str,
        .validate = NULL,
        .opaque = NULL
    },

    [CE_BASE64_BINARY] = {
        .parent = &confd_types[C_BINARY],
        .defval = NULL,
        .str_to_val = base64_binary_str_to_val,
        .val_to_str = base64_binary_val_to_str,
        .validate = NULL,
        .opaque = NULL
    },

    [CE_NORMALIZED_STRING] = {
        .parent = &confd_types[C_BUF],
        .defval = NULL,
        .str_to_val = normalized_string_to_string,
        .val_to_str = NULL,
        .validate = NULL,
        .opaque = NULL
    },

    [CE_TOKEN] = {
        .parent = &confd_types[C_BUF],
        .defval = NULL,
        .str_to_val = token_to_string,
        .val_to_str = NULL,
        .validate = NULL,
        .opaque = NULL
    },

    [CE_LANGUAGE] = {
        .parent = &confd_types[CE_TOKEN],
        .defval = NULL,
        .str_to_val = NULL,
        .val_to_str = NULL,
        .validate = validate_language,
        .opaque = NULL
    },

    [CE_NMTOKEN] = {
        .parent = &confd_types[CE_TOKEN],
        .defval = NULL,
        .str_to_val = NULL,
        .val_to_str = NULL,
        .validate = validate_nmtoken,
        .opaque = NULL
    },

    [CE_NAME] = {
        .parent = &confd_types[CE_TOKEN],
        .defval = NULL,
        .str_to_val = NULL,
        .val_to_str = NULL,
        .validate = validate_name,
        .opaque = NULL
    },

    [CE_NCNAME] = {
        .parent = &confd_types[CE_NAME],
        .defval = NULL,
        .str_to_val = NULL,
        .val_to_str = NULL,
        .validate = validate_ncname,
        .opaque = NULL
    },

    [CE_NMTOKEN_LIST] = {
        .parent = NULL,
        .defval = NULL,
        .str_to_val = confd_list_str_to_val,
        .val_to_str = confd_list_val_to_str,
        .validate = confd_list_validate,
        .opaque = (void *)&xs_nmtoken_list_list
    },

    [CE_NMTOKENS] = {
        .parent = &confd_types[CE_NMTOKEN_LIST],
        .defval = NULL,
        .str_to_val = NULL,
        .val_to_str = NULL,
        .validate = confd_type_validate_list_restriction,
        .opaque = (void *)&xs_nmtokens_restriction
    },

    [CE_IDREF_LIST] = {
        .parent = NULL,
        .defval = NULL,
        .str_to_val = confd_list_str_to_val,
        .val_to_str = confd_list_val_to_str,
        .validate = confd_list_validate,
        .opaque = (void *)&xs_idref_list_list
    },

    [CE_IDREFS] = {
        .parent = &confd_types[CE_IDREF_LIST],
        .defval = NULL,
        .str_to_val = NULL,
        .val_to_str = NULL,
        .validate = confd_type_validate_list_restriction,
        .opaque = (void *)&xs_idrefs_restriction
    },

    [CE_NON_POSITIVE_INTEGER] = {
        .parent = &confd_types[C_INT64],
        .defval = NULL,
        .str_to_val = NULL,
        .val_to_str = NULL,
        .validate = confd_type_validate_number_restriction,
        .opaque = (void *)&xs_non_positive_integer_restriction
    },

    [CE_NEGATIVE_INTEGER] = {
        .parent = &confd_types[C_INT64],
        .defval = NULL,
        .str_to_val = NULL,
        .val_to_str = NULL,
        .validate = confd_type_validate_number_restriction,
        .opaque = (void *)&xs_negative_restriction
    },

    [CE_NON_NEGATIVE_INTEGER] = {
        .parent = &confd_types[C_UINT64],
        .defval = NULL,
        .str_to_val = NULL,
        .val_to_str = NULL,
        .validate = confd_type_validate_number_restriction,
        .opaque = (void *)&xs_non_negative_restriction
    },

    [CE_POSITIVE_INTEGER] = {
        .parent = &confd_types[C_UINT64],
        .defval = NULL,
        .str_to_val = NULL,
        .val_to_str = NULL,
        .validate = confd_type_validate_number_restriction,
        .opaque = (void *)&xs_positive_integer_restriction
    },

    /* placeholder for user-defined types */
    [CE_NO_TYPE] = {
        .parent = NULL,
        .defval = NULL,
        .str_to_val = no_str_to_val,
        .val_to_str = no_val_to_str,
        .validate = no_validate,
        .opaque = NULL
    }
};


void confd_type_init(void)
{
    confd_inetAddress_union_member[1].type = &confd_types[C_BUF];
    confd_inetAddress_union_member[0].type = &confd_types[CE_INET_ADDRESS_IP];
    confd_type_init_type(&confd_types[CE_INET_ADDRESS]);

    confd_inetAddressIP_union_member[1].type = &confd_types[C_IPV6];
    confd_inetAddressIP_union_member[0].type = &confd_types[C_IPV4];
    confd_type_init_type(&confd_types[CE_INET_ADDRESS_IP]);

    confd_ipPrefix_union_member[1].type = &confd_types[C_IPV6PREFIX];
    confd_ipPrefix_union_member[0].type = &confd_types[C_IPV4PREFIX];
    confd_type_init_type(&confd_types[CE_IPPREFIX]);

    confd_ip_and_plen_union_member[1].type = &confd_types[C_IPV6_AND_PLEN];
    confd_ip_and_plen_union_member[0].type = &confd_types[C_IPV4_AND_PLEN];
    confd_type_init_type(&confd_types[CE_IP_AND_PLEN]);

    confd_type_init_type(&confd_types[CE_HEX_LIST]);
    confd_type_init_type(&confd_types[CE_OCTET_LIST]);

    // initialization of union member fails in vxworks due to compiler crash
    // do the init at runtime
    xs_non_positive_integer_range[0].hi.type = C_INT64;
    xs_non_positive_integer_range[0].hi.val.i64 = 0;
    confd_type_init_type(&confd_types[CE_NON_POSITIVE_INTEGER]);

    xs_negative_integer_range[0].hi.type = C_INT64;
    xs_negative_integer_range[0].hi.val.i64 = -1;
    confd_type_init_type(&confd_types[CE_NEGATIVE_INTEGER]);

    xs_non_negative_integer_range[0].lo.type = C_UINT64;
    xs_non_negative_integer_range[0].lo.val.u64 = 0;
    confd_type_init_type(&confd_types[CE_NON_NEGATIVE_INTEGER]);

    xs_positive_integer_range[0].lo.type = C_UINT64;
    xs_positive_integer_range[0].lo.val.u64 = 1;
    confd_type_init_type(&confd_types[CE_POSITIVE_INTEGER]);

    confd_type_init_type(&confd_types[CE_BASE64_BINARY]);
    confd_type_init_type(&confd_types[CE_NORMALIZED_STRING]);
    confd_type_init_type(&confd_types[CE_TOKEN]);
    confd_type_init_type(&confd_types[CE_LANGUAGE]);
    confd_type_init_type(&confd_types[CE_NMTOKEN]);
    confd_type_init_type(&confd_types[CE_NAME]);
    confd_type_init_type(&confd_types[CE_NCNAME]);

    xs_nmtoken_list_list.type = &confd_types[CE_NMTOKEN];

    xs_nmtokens_length[0].lo.type = C_INT32;
    xs_nmtokens_length[0].lo.val.i32 = 1;
    confd_type_init_type(&confd_types[CE_NMTOKENS]);

    xs_idref_list_list.type = &confd_types[CE_NCNAME];

    xs_idrefs_length[0].lo.type = C_INT32;
    xs_idrefs_length[0].lo.val.i32 = 1;
    confd_type_init_type(&confd_types[CE_IDREFS]);

}

struct confd_type *confd_find_type(const char *str)
{
    /* YANG built-in types */
    if (strcmp(str, "int8") == 0)
        return &confd_types[C_INT8];
    if (strcmp(str, "int16") == 0)
        return &confd_types[C_INT16];
    if (strcmp(str, "int32") == 0)
        return &confd_types[C_INT32];
    if (strcmp(str, "int64") == 0)
        return &confd_types[C_INT64];
    if (strcmp(str, "uint8") == 0)
        return &confd_types[C_UINT8];
    if (strcmp(str, "uint16") == 0)
        return &confd_types[C_UINT16];
    if (strcmp(str, "uint32") == 0)
        return &confd_types[C_UINT32];
    if (strcmp(str, "uint64") == 0)
        return &confd_types[C_UINT64];
    if (strcmp(str, "string") == 0)
        return &confd_types[C_BUF];
    if (strcmp(str, "boolean") == 0)
        return &confd_types[C_BOOL];
    if (strcmp(str, "binary") == 0)
        return &confd_types[CE_BASE64_BINARY];
    /* Missing: instance-identifier (objectRef) */

    /* types from tailf-common YANG module
       "http://tail-f.com/yang/common" */
    if (strcmp(str, "hex-list") == 0)
        return &confd_types[CE_HEX_LIST];
    if (strcmp(str, "octet-list") == 0)
        return &confd_types[CE_OCTET_LIST];
    if (strcmp(str, "md5-digest-string") == 0)
        return &confd_types[C_BUF];
    if (strcmp(str, "sha-256-digest-string") == 0)
        return &confd_types[C_BUF];
    if (strcmp(str, "sha-512-digest-string") == 0)
        return &confd_types[C_BUF];
    if (strcmp(str, "des3-cbc-encrypted-string") == 0)
        return &confd_types[C_BUF];
    if (strcmp(str, "aes-cfb-128-encrypted-string") == 0)
        return &confd_types[C_BUF];
    if (strcmp(str, "ipv4-address-and-prefix-length") == 0)
        return &confd_types[C_IPV4_AND_PLEN];
    if (strcmp(str, "ipv6-address-and-prefix-length") == 0)
        return &confd_types[C_IPV6_AND_PLEN];
    if (strcmp(str, "ip-address-and-prefix-length") == 0)
        return &confd_types[CE_IP_AND_PLEN];

    /* Types from "http://tail-f.com/ns/confd/1.0" */
    if (strcmp(str, "inetAddressIPv4") == 0)
        return &confd_types[C_IPV4];
    if (strcmp(str, "inetAddressIPv6") == 0)
        return &confd_types[C_IPV6];
    if (strcmp(str, "Counter32") == 0)
        return &confd_types[C_UINT32];
    if (strcmp(str, "Counter64") == 0)
        return &confd_types[C_UINT64];
    if (strcmp(str, "Gauge32") == 0)
        return &confd_types[C_UINT32];
    if (strcmp(str, "inetPortNumber") == 0)
        return &confd_types[C_UINT16];
    if (strcmp(str, "inetAddressDNS") == 0)
        return &confd_types[C_BUF];
    if (strcmp(str, "oid") == 0)
        return &confd_types[C_OID];
    if (strcmp(str, "inetAddressIP") == 0)
        return &confd_types[CE_INET_ADDRESS_IP];
    if (strcmp(str, "inetAddress") == 0)
        return &confd_types[CE_INET_ADDRESS];
    if (strcmp(str, "ipPrefix") == 0)
        return &confd_types[CE_IPPREFIX];
    if (strcmp(str, "ipv4Prefix") == 0)
        return &confd_types[C_IPV4PREFIX];
    if (strcmp(str, "ipv6Prefix") == 0)
        return &confd_types[C_IPV6PREFIX];
    if (strcmp(str, "size") == 0)
        return &confd_types[CE_SIZE];
    if (strcmp(str, "hexList") == 0)
        return &confd_types[CE_HEX_LIST];
    if (strcmp(str, "octetList") == 0)
        return &confd_types[CE_OCTET_LIST];
    if (strcmp(str, "dottedQuad") == 0)
        return &confd_types[C_DQUAD];
    if (strcmp(str, "hexString") == 0)
        return &confd_types[C_HEXSTR];
    /* The ones below should have facets too */
    if (strcmp(str, "MD5DigestString") == 0)
        return &confd_types[C_BUF];
    if (strcmp(str, "SHA256DigestString") == 0)
        return &confd_types[C_BUF];
    if (strcmp(str, "SHA512DigestString") == 0)
        return &confd_types[C_BUF];
    if (strcmp(str, "cryptHash") == 0)
        return &confd_types[C_BUF];
    if (strcmp(str, "DES3CBCEncryptedString") == 0)
        return &confd_types[C_BUF];
    if (strcmp(str, "AESCFB128EncryptedString") == 0)
        return &confd_types[C_BUF];
    if (strcmp(str, "ipv4AddressAndPrefixLength") == 0)
        return &confd_types[C_IPV4_AND_PLEN];
    if (strcmp(str, "ipv6AddressAndPrefixLength") == 0)
        return &confd_types[C_IPV6_AND_PLEN];
    if (strcmp(str, "ipAddressAndPrefixLength") == 0)
        return &confd_types[CE_IP_AND_PLEN];
    /* Missing: objectRef (hexValue is undocumented) */

    /* types from "http://www.w3.org/2001/XMLSchema" */
    if (strcmp(str, "byte") == 0)
        return &confd_types[C_INT8];
    if (strcmp(str, "short") == 0)
        return &confd_types[C_INT16];
    if (strcmp(str, "int") == 0)
        return &confd_types[C_INT32];
    if (strcmp(str, "long") == 0)
        return &confd_types[C_INT64];
    if (strcmp(str, "unsignedByte") == 0)
        return &confd_types[C_UINT8];
    if (strcmp(str, "unsignedShort") == 0)
        return &confd_types[C_UINT16];
    if (strcmp(str, "unsignedInt") == 0)
        return &confd_types[C_UINT32];
    if (strcmp(str, "unsignedLong") == 0)
        return &confd_types[C_UINT64];
    if (strcmp(str, "string") == 0)
        return &confd_types[C_BUF];
    if (strcmp(str, "double") == 0)
        return &confd_types[C_DOUBLE];
    if (strcmp(str, "boolean") == 0)
        return &confd_types[C_BOOL];
    if (strcmp(str, "dateTime") == 0)
        return &confd_types[C_DATETIME];
    if (strcmp(str, "date") == 0)
        return &confd_types[C_DATE];
    if (strcmp(str, "time") == 0)
        return &confd_types[C_TIME];
    if (strcmp(str, "duration") == 0)
        return &confd_types[C_DURATION];
    if (strcmp(str, "decimal") == 0)
        return &confd_types[C_DOUBLE];
    if (strcmp(str, "integer") == 0)
        return &confd_types[C_INT64];
    if (strcmp(str, "float") == 0)
        return &confd_types[C_DOUBLE];
    if (strcmp(str, "hexBinary") == 0)
        return &confd_types[C_BINARY];
    if (strcmp(str, "base64Binary") == 0)
        return &confd_types[CE_BASE64_BINARY];
    if (strcmp(str, "nonNegativeInteger") == 0)
        return &confd_types[CE_NON_NEGATIVE_INTEGER];
    if (strcmp(str, "nonPositiveInteger") == 0)
        return &confd_types[CE_NON_POSITIVE_INTEGER];
    if (strcmp(str, "negativeInteger") == 0)
        return &confd_types[CE_NEGATIVE_INTEGER];
    if (strcmp(str, "positiveInteger") == 0)
        return &confd_types[CE_POSITIVE_INTEGER];
    if (strcmp(str, "normalizedString") == 0)
        return &confd_types[CE_NORMALIZED_STRING];
    if (strcmp(str, "token") == 0)
        return &confd_types[CE_TOKEN];
    if (strcmp(str, "NOTATION") == 0)
        return &confd_types[CE_TOKEN];
    if (strcmp(str, "language") == 0)
        return &confd_types[CE_LANGUAGE];
    if (strcmp(str, "NMTOKEN") == 0)
        return &confd_types[CE_NMTOKEN];
    if (strcmp(str, "Name") == 0)
        return &confd_types[CE_NAME];
    if (strcmp(str, "NCName") == 0)
        return &confd_types[CE_NCNAME];
    if (strcmp(str, "ID") == 0)
        return &confd_types[CE_NCNAME];
    if (strcmp(str, "IDREF") == 0)
        return &confd_types[CE_NCNAME];
    if (strcmp(str, "ENTITY") == 0)
        return &confd_types[CE_NCNAME];
    if (strcmp(str, "NMTOKENS") == 0)
        return &confd_types[CE_NMTOKENS];
    if (strcmp(str, "IDREFS") == 0)
        return &confd_types[CE_IDREFS];
    if (strcmp(str, "ENTITIES") == 0)
        return &confd_types[CE_IDREFS];
    /* Missing: anyURI, QName */

    if (strcmp(str, "NO_TYPE") == 0)
        return &confd_types[CE_NO_TYPE];

    return NULL;
}

struct confd_type *confd_find_vtype_type(enum confd_vtype vtype)
{
    if (vtype < C_MAXTYPE && confd_types[vtype].str_to_val != NULL)
        return &confd_types[vtype];
    return NULL;
}
