/*
 * Copyright 2005-2007 Tail-F Systems AB
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <unistd.h>
#include <errno.h>
#include <assert.h>
#include <arpa/inet.h>
#include <ctype.h>
#include <signal.h>

#include "erl_interface.h"
#include "ei.h"
#include "confd_lib.h"
#include "confd_internal.h"
#include "confd_cdb.h"
#include "confd_proto.h"
#include "cdb_proto.h"

#include "hash/hashtable.h"

int cdb_active_subscriptions = 0;


int cdb_set_namespace(int sock, int hashed_ns)
{
    int status;
    ETERM *term = erl_mk_int(hashed_ns);
    op_request_term(sock, CDB_OP_SET_NAMESPACE, -1, 0, term, &status);
    erl_free_compound(term);
    return status;
}

int cdb_end_session(int sock)
{
    int status;
    op_request_term(sock, CDB_OP_END_SESSION, -1, 0, NULL, &status);
    return status;
}

int cdb_start_session(int sock, enum cdb_db_type db)
{
    int flags = 0;

    switch (db) {
    case CDB_RUNNING:
    case CDB_STARTUP:
        flags = CDB_LOCK_SESSION;
        break;
    case CDB_OPERATIONAL:
    case CDB_PRE_COMMIT_RUNNING:
        break;
    }
    return cdb_start_session2(sock, db, flags);
}

int cdb_start_session2(int sock, enum cdb_db_type db, int flags)
{
    ETERM *tup[2];
    ETERM *opt[10];
    ETERM *term;
    int i = 0, status;

    switch (db) {
    case CDB_RUNNING:
    case CDB_STARTUP:
    case CDB_OPERATIONAL:
    case CDB_PRE_COMMIT_RUNNING:
        break;
    default:
        return ret_err(CONFD_ERR_PROTOUSAGE,"Invalid DB (%d)\n", db);
    }
    tup[0] = erl_mk_int((int)db);
    opt[i++] = erl_mk_atom("usehtags");
    if (flags & CDB_LOCK_SESSION)
        opt[i++] = erl_mk_atom("lock_session");
    if (flags & CDB_LOCK_REQUEST)
        opt[i++] = erl_mk_atom("lock_request");
    if (flags & CDB_LOCK_PARTIAL)
        opt[i++] = erl_mk_atom("lock_partial");
    if (flags & CDB_LOCK_WAIT)
        opt[i++] = erl_mk_atom("lock_wait");
    tup[1] = erl_mk_list(opt, i);
    term = erl_mk_tuple(tup, 2);
    op_request_term(sock, CDB_OP_NEW_SESSION, -1, 0, term, &status);
    erl_free_compound(term);
    if (status == CONFD_OK)
        confd_trace(CONFD_TRACE,  "Established new CDB session to ConfD\n");
    else
        confd_trace(CONFD_DEBUG, "Failed to create new session to ConfD\n");
    return status;
}


/* Note: if cdb_connect() or cdb_connect_name() returns CONFD_ERR
 * the socket is to be considered unusable
 */
int cdb_connect(int sock,
                enum cdb_sock_type type,
                const struct sockaddr* srv, int srv_sz)
{
    char *name;

    /* Give Erlang side a name to use when reporting status... */
    if (confd_daemon_name[0] != 0)
        name = confd_daemon_name;
    else
        name = "<unknown>";
    return cdb_connect_name(sock, type, srv, srv_sz, name);
}

int cdb_connect_name(int sock,
                     enum cdb_sock_type type,
                     const struct sockaddr* srv, int srv_sz,
                     const char *name)
{
    int ret;

    switch (type) {
    case CDB_READ_SOCKET:
    case CDB_SUBSCRIPTION_SOCKET:
    case CDB_DATA_SOCKET:
        if ((ret = confd_do_connect(sock, srv, srv_sz, CLIENT_CDB)) != CONFD_OK)
            return ret;
        confd_trace(CONFD_TRACE, "Connected (cdb) to ConfD\n");

        if ((ret =
             op_write_buf(sock, CDB_OP_CLIENT_NAME, name, strlen(name), -1))
            == CONFD_OK) {
            char infostr[32];
            snprintf(infostr, sizeof(infostr), "%lu/%d",
                     (unsigned long)getpid(), sock);
            return op_write_buf(sock, CDB_OP_CLIENT_INFO,
                                infostr, strlen(infostr), -1);
        }
        return ret;
        ;;
    default:
        return ret_err(CONFD_ERR_PROTOUSAGE, "Invalid cdb_sock_type\n");
    }
}


int cdb_mandatory_subscriber(int sock, const char *name)
{
   int err;
   if ((name == NULL) || (strlen(name) == 0)) {
      err = ret_err(CONFD_ERR_PROTOUSAGE, "subscriber name is required");
   }
   else {
      err = op_write_buf(sock, CDB_OP_MANDATORY_SUBSCRIBER,
                         name, strlen(name), -1);
   }
   return err;
}

int cdb_close(int sock)
{
    if (close(sock) != 0) return CONFD_ERR;
    return CONFD_OK;
}


int cdb_load_file(int sock, const char *filename, int flags)
{
    ETERM *arg, *tup[2], *efname, *eflags;
    int status = CONFD_OK;

    if ((efname = erl_mk_binary(filename, strlen(filename))) == NULL)
        return ret_err(CONFD_ERR_MALLOC, "Cannot allocate");
    eflags = erl_mk_int(flags);
    tup[0] = efname;
    tup[1] = eflags;
    arg = erl_mk_tuple(tup, 2);
    op_request_term(sock, CDB_OP_LOAD_FILE, -1, 0, arg, &status);
    erl_free_compound(arg);
    return status;
}

int cdb_load_str(int sock, const char *xml_str, int flags)
{
    ETERM *arg, *tup[2], *estring, *eflags;
    int status = CONFD_OK;

    if ((estring = erl_mk_binary(xml_str, strlen(xml_str))) == NULL)
        return ret_err(CONFD_ERR_MALLOC, "Cannot allocate");
    eflags = erl_mk_int(flags);
    tup[0] = estring;
    tup[1] = eflags;
    arg = erl_mk_tuple(tup, 2);
    op_request_term(sock, CDB_OP_LOAD_STRING, -1, 0, arg, &status);
    erl_free_compound(arg);
    return status;
}

int cdb_wait_start(int sock)
{
    int status = CONFD_OK;
    op_request_term(sock, CDB_OP_WAIT_START, -1, 0, NULL, &status);
    return status;
}

int cdb_get_txid(int sock, struct cdb_txid *txid) {
    ETERM *result;
    int status;
    ETERM *timestamp = NULL;
    result = op_request_term(sock, CDB_OP_GET_TXID, -1, 0, NULL, &status);
    if (confd_debug_level > CONFD_TRACE && confd_debug_stream) {
        fprintf(confd_debug_stream, "cdb_get_txid() got ");
        erl_print_term(confd_debug_stream, result);
        fprintf(confd_debug_stream, "\n");
    }
    if (!result)
        return status;

    if (ERL_IS_TUPLE(result) && (ERL_TUPLE_SIZE(result) == 2)) {
        ETERM *node = ERL_TUPLE_ELEMENT(result, 0);
        confd_value_t val;
        if (eterm_to_val(node, &val) == NULL)
            return CONFD_ERR;
        confd_pp_value(txid->master, MAXHOSTLEN, &val);
        timestamp = ERL_TUPLE_ELEMENT(result, 1);
    } else if (ERL_IS_TUPLE(result) && (ERL_TUPLE_SIZE(result) == 3)) {
        txid->master[0] = 0;
        timestamp = result;
    } else {
        erl_free_compound(result);
        return confd_internal_error("Internal error, bad transaction id\n");
    }
    txid->s1 = ERL_INT_VALUE(ERL_TUPLE_ELEMENT(timestamp, 0));
    txid->s2 = ERL_INT_VALUE(ERL_TUPLE_ELEMENT(timestamp, 1));
    txid->s3 = ERL_INT_VALUE(ERL_TUPLE_ELEMENT(timestamp, 2));
    erl_free_compound(result);

    return CONFD_OK;
}


int cdb_get_phase(int sock, struct cdb_phase *phase)
{
    ETERM *result;
    int status;

    result = op_request_term(sock, CDB_OP_GET_PHASE, -1, 0, NULL, &status);
    if (confd_debug_level > CONFD_TRACE && confd_debug_stream) {
        fprintf(confd_debug_stream, "cdb_get_phase() got ");
        erl_print_term(confd_debug_stream, result);
        fprintf(confd_debug_stream, "\n");
    }
    if (phase) {
        if (result && ERL_IS_TUPLE(result) && (ERL_TUPLE_SIZE(result) == 2)) {
            ETERM *term = ERL_TUPLE_ELEMENT(result, 1);
            phase->phase = ERL_INT_VALUE(ERL_TUPLE_ELEMENT(result, 0));
            phase->flags = 0;
            if (bin_eq(term, "init"))    { phase->flags |= CDB_FLAG_INIT; }
            if (bin_eq(term, "upgrade")) { phase->flags |= CDB_FLAG_UPGRADE; }
        } else {
            status = CONFD_ERR;
        }
    }
    if (result) {
        erl_free_compound(result);
    }
    return status;
}

int cdb_get_user_session(int sock)
{
    ETERM *result;
    int status;
    int usid;

    result = op_request_term(sock, CDB_OP_GET_USER_SESSION, -1, 0,NULL,&status);
    if (!result)
        return status;
    usid = ERL_INT_VALUE(result);
    erl_free_compound(result);
    return usid;
}

int cdb_get_transaction_handle(int sock)
{
    ETERM *result;
    int status;
    int th;

    result = op_request_term(sock, CDB_OP_GET_TRANS_TID, -1, 0,NULL,&status);
    if (!result)
        return status;
    th = ERL_INT_VALUE(result);
    erl_free_compound(result);
    return th;
}

int cdb_set_timeout(int sock, int timeout_secs)
{
    int status;
    ETERM *term = erl_mk_int(timeout_secs);
    op_request_term(sock, CDB_OP_SET_TIMEOUT, -1, 0, term, &status);
    erl_free_compound(term);
    return status;
}

int cdb_getcwd(int sock, size_t strsz, char *curdir)
{
    ETERM *result;
    int status;

    result = op_request_term(sock, CDB_OP_GETCWD, -1, 0, NULL, &status);
    if (result && confd_debug_level > CONFD_TRACE && confd_debug_stream) {
        fprintf(confd_debug_stream, "cdb_getcwd() got ");
        erl_print_term(confd_debug_stream, result);
        fprintf(confd_debug_stream, "\n");
    }
    if (result && ERL_IS_BINARY(result)) {
        int reslen = ERL_BIN_SIZE(result);
        memset(curdir, 0, strsz);
        memcpy(curdir, ERL_BIN_PTR(result),
               (size_t)((reslen > strsz) ? (strsz-1) : reslen));
    } else {
        status = CONFD_ERR;
    }
    if (result) {
        erl_free_compound(result);
    }
    return status;
}

int cdb_getcwd_kpath(int sock, confd_hkeypath_t **kp)
{
    ETERM *arg = erl_mk_atom("kp");
    ETERM *result;
    int status;
    confd_hkeypath_t kp0, *kp1;

    result = op_request_term(sock, CDB_OP_GETCWD, -1, 0, arg, &status);
    erl_free_compound(arg);
    if (result && confd_debug_level > CONFD_TRACE && confd_debug_stream) {
        fprintf(confd_debug_stream, "cdb_getcwd_kpath() got ");
        erl_print_term(confd_debug_stream, result);
        fprintf(confd_debug_stream, "\n");
    }
    if (result && ERL_IS_LIST(result) && populate_keypath(result, &kp0) &&
        (kp1 = confd_hkeypath_dup(&kp0)) != NULL) {
        *kp = kp1;
    } else {
        status = CONFD_ERR;
    }
    if (result) {
        confd_free_eterm_keypath(&kp0);
        erl_free_compound(result);
    }
    return status;
}


static int do_get(int sock, confd_value_t *v, ETERM *epath, int isrel)
{
    ETERM *result;
    int status;
    result = op_request_term(sock, CDB_OP_GET, -1, isrel, epath, &status);

    if (result == NULL) {
        erl_free_compound(epath);
        return status;
    }
    if (confd_debug_level > CONFD_TRACE && confd_debug_stream) {
        fprintf(confd_debug_stream, "cdb_get() got ");
        erl_print_term(confd_debug_stream, result);
        fprintf(confd_debug_stream, "\n");
    }
    erl_free_compound(epath);
    if (eterm_to_val(result, v) == NULL) {
        erl_free_compound(result);
        return CONFD_ERR;
    }
    /* We need to special case results that return confd_buf_t and
     * copy the data they are pointing to (since it will be freed when
     * we call erl_free_compound() below)
     */
    status = confd_dup_value(v);
    erl_free_compound(result);
    return status;
}




int cdb_get(int sock, confd_value_t *v, const char *fmt, ...)
{
    int retval;
    va_list args;
    va_start(args,fmt);
    retval = cdb_vget(sock, v, fmt, args);
    va_end(args);
    return retval;
}

int cdb_vget(int sock, confd_value_t *v, const char *fmt, va_list args)
{
    int isrel;
    ETERM *epath = parse_path(&isrel, fmt, args);
    if (epath == NULL)
        return ret_err(CONFD_ERR_BADPATH, "Bad path <%s>", fmt);
    return do_get(sock, v, epath, isrel);
}

static int vcdb_req(int sock, confd_value_t *res, int op, ETERM *arg,
                    const char *fmt, va_list args)
{
    int status, isrel;
    ETERM *eresult;
    ETERM *req;
    ETERM *tup[2];
    ETERM *epath = parse_path(&isrel, fmt, args);

    if (epath == NULL) {
        erl_free_compound(arg);
        return ret_err(CONFD_ERR_BADPATH, "Bad path <%s>", fmt);
    }
    tup[0] = arg;
    tup[1] = epath;
    req = erl_mk_tuple(tup, 2);

    eresult = op_request_term(sock, op, -1, isrel, req, &status);
    erl_free_compound(req);

    if (eresult == NULL) {
        return status;
    }
    if (confd_debug_level > CONFD_TRACE && confd_debug_stream) {
        fprintf(confd_debug_stream, "req(%d) got ", op);
        erl_print_term(confd_debug_stream, eresult);
        fprintf(confd_debug_stream, "\n");
    }
    if (eterm_to_val(eresult, res) == NULL) {
        erl_free_compound(eresult);
        return CONFD_ERR;
    }
    /* We need to special case results that return confd_buf_t and
     * copy the data they are pointing to (since it will be freed when
     * we call erl_free_compound() below)
     */
    status = confd_dup_value(res);
    erl_free_compound(eresult);
    return status;
}

int cdb_get_case(int sock, const char *choice, confd_value_t *rcase,
                 const char *fmt, ...)
{
    int ret;
    va_list args;

    va_start(args, fmt);
    ret = cdb_vget_case(sock, choice, rcase, fmt, args);
    va_end(args);
    return ret;
}

int cdb_vget_case(int sock, const char *choice, confd_value_t *rcase,
                 const char *fmt, va_list args)
{
    ETERM *echoice;

    if ((echoice = _confd_parse_choice_path(choice)) == NULL)
        return CONFD_ERR;
    return vcdb_req(sock, rcase, CDB_OP_GET_CASE, echoice, fmt, args);
}

int cdb_cd(int sock, const char *fmt, ...)
{
    int ret;
    va_list args;
    va_start(args,fmt);

    ret = fmt_request(sock, CDB_OP_CD, -1, fmt, args);
    va_end(args);
    return ret;
}

int cdb_vcd(int sock, const char *fmt, va_list args)
{
    return fmt_request(sock, CDB_OP_CD, -1, fmt, args);
}

int cdb_pushd(int sock, const char *fmt, ...)
{
    int ret;
    va_list args;
    va_start(args,fmt);

    ret = fmt_request(sock, CDB_OP_PUSHD, -1, fmt, args);
    va_end(args);
    return ret;
}

int cdb_vpushd(int sock, const char *fmt, va_list args)
{
    return fmt_request(sock, CDB_OP_PUSHD, -1, fmt, args);
}

int cdb_popd(int sock)
{
    int ret;
    op_request_term(sock, CDB_OP_POPD, -1, 0, NULL, &ret);
    return ret;
}


int cdb_exists(int sock, const char *fmt, ...)
{
    int ret;
    va_list args;
    va_start(args,fmt);

    ret = request_int(sock, CDB_OP_EXISTS, -1, fmt, args);
    va_end(args);
    return ret;
}

int cdb_vexists(int sock, const char *fmt, va_list args)
{
    return request_int(sock, CDB_OP_EXISTS, -1, fmt, args);
}

int cdb_num_instances(int sock, const char *fmt, ...)
{
    int ret;
    va_list args;
    va_start(args,fmt);

    ret = request_int(sock, CDB_OP_NUM_INSTANCES, -1, fmt, args);
    va_end(args);
    return ret;
}

int cdb_vnum_instances(int sock, const char *fmt, va_list args)
{
    return request_int(sock, CDB_OP_NUM_INSTANCES, -1, fmt, args);
}

int cdb_next_index(int sock, const char *fmt, ...)
{
    int ret;
    va_list args;
    va_start(args, fmt);
    ret = request_int(sock, CDB_OP_NXT_INDEX, -1, fmt, args);
    va_end(args);
    return ret;
}

int cdb_vnext_index(int sock, const char *fmt, va_list args)
{
    return request_int(sock, CDB_OP_NXT_INDEX, -1, fmt, args);
}

int cdb_index(int sock, const char *fmt, ...)
{
    int ret;
    va_list args;
    va_start(args, fmt);
    ret = request_int(sock, CDB_OP_KEY_INDEX, -1, fmt, args);
    va_end(args);
    return ret;
}

int cdb_vindex(int sock, const char *fmt, va_list args)
{
    return request_int(sock, CDB_OP_KEY_INDEX, -1, fmt, args);
}

int cdb_is_default(int sock, const char *fmt, ...)
{
    int ret;
    va_list args;
    va_start(args,fmt);

    ret = request_int(sock, CDB_OP_IS_DEFAULT, -1, fmt, args);
    va_end(args);
    return ret;
}

int cdb_vis_default(int sock, const char *fmt, va_list args)
{
    return request_int(sock, CDB_OP_IS_DEFAULT, -1, fmt, args);
}


int cdb_subscribe2(int sock, enum cdb_sub_type type, int flags, int priority,
                   int *spoint, int namespace, const char *fmt, ...)
{
    int ret;
    va_list args;

    va_start(args,fmt);
    ret = cdb_vsubscribe2(sock, type, flags, priority,
                          spoint, namespace, fmt, args);
    va_end(args);
    return ret;
}

int cdb_vsubscribe2(int sock, enum cdb_sub_type type, int flags, int priority,
                   int *spoint, int namespace, const char *fmt, va_list args)
{
    int isrel, status;
    ETERM *arg, *ret;
    ETERM *epath;
    ETERM *tup[6];

    clr_confd_err();
    epath = parse_path(&isrel, fmt, args);
    if (!epath) return ret_err(CONFD_ERR_BADPATH, "Bad path <%s>", fmt);
    tup[0] = erl_mk_int(type);
    tup[1] = erl_mk_int(flags);
    /* can't do this - would require a flag to have spoint as input */
    /* tup[2] = erl_mk_int(spoint ? *spoint : 0); */
    tup[2] = erl_mk_int(0);
    tup[3] = erl_mk_int(priority);
    tup[4] = erl_mk_int(namespace);
    tup[5] = epath;
    arg = erl_mk_tuple(tup, 6);
    ret = op_request_term(sock, CDB_OP_SUBSCRIBE, -1, 0, arg, &status);
    erl_free_compound(arg);

    if (ret == NULL) {
        return status;
    }
    if (status == CONFD_OK) {
        if (spoint) {
            *spoint = ERL_INT_VALUE(ret);
        }
        cdb_active_subscriptions++;
    }
    erl_free_compound(ret);
    return status;
}

int cdb_subscribe(int sock, int priority, int namespace, int *spoint,
                  const char *fmt, ...)
{
    int ret;
    va_list args;

    va_start(args,fmt);
    ret = cdb_vsubscribe(sock, priority, namespace, spoint, fmt, args);
    va_end(args);
    return ret;
}

int cdb_vsubscribe(int sock, int priority, int namespace, int *spoint,
                   const char *fmt, va_list args)
{
    int isrel, status;
    ETERM *arg, *ret;
    ETERM *epath;
    ETERM *tup[3];

    clr_confd_err();
    epath = parse_path(&isrel, fmt, args);
    if (!epath) return ret_err(CONFD_ERR_BADPATH, "Bad path <%s>", fmt);
    tup[0] = erl_mk_int(priority);
    tup[1] = erl_mk_int(namespace);
    tup[2] = epath;
    arg = erl_mk_tuple(tup, 3);
    ret = op_request_term(sock, CDB_OP_SUBSCRIBE, -1, 0, arg, &status);
    erl_free_compound(arg);

    if (ret == NULL) {
        return status;
    }
    if (status == CONFD_OK) {
        *spoint = ERL_INT_VALUE(ret);
        cdb_active_subscriptions++;
    }
    erl_free_compound(ret);
    return status;
}

int cdb_oper_subscribe(int sock, int namespace, int *spoint,
                       const char *fmt, ...)
{
    int ret;
    va_list args;

    va_start(args,fmt);
    ret = cdb_voper_subscribe(sock, namespace, spoint, fmt, args);
    va_end(args);
    return ret;
}

int cdb_voper_subscribe(int sock, int namespace, int *spoint,
                        const char *fmt, va_list args)
{
    int isrel, status;
    ETERM *arg, *ret;
    ETERM *epath;
    ETERM *tup[2];

    clr_confd_err();
    epath = parse_path(&isrel, fmt, args);
    if (!epath) return ret_err(CONFD_ERR_BADPATH, "Bad path <%s>", fmt);
    tup[0] = erl_mk_int(namespace);
    tup[1] = epath;
    arg = erl_mk_tuple(tup, 2);
    ret = op_request_term(sock, CDB_OP_OPER_SUBSCRIBE, -1, 0, arg, &status);
    erl_free_compound(arg);

    if (ret == NULL) {
        return status;
    }
    if (status == CONFD_OK) {
        *spoint = ERL_INT_VALUE(ret);
        cdb_active_subscriptions++;
    }
    erl_free_compound(ret);
    return status;
}

int cdb_subscribe_done(int sock)
{
    int status = CONFD_OK;
    op_request_term(sock, CDB_OP_SUBSCRIBE_DONE, -1, 0, NULL, &status);
    return status;
}

int cdb_trigger_subscriptions(int sock, int sub_points[], int len)
{
    int i;
    int status = CONFD_OK;
    ETERM *term;
    ETERM *list[len];
    for (i=0; i<len; i++) {
        list[i] = erl_mk_int(sub_points[i]);
    }
    term = erl_mk_list(list, len);
    op_request_term(sock, CDB_OP_TRIGGER_SUBS, -1, 0, term, &status);
    erl_free_compound(term);
    return status;
}

int cdb_trigger_oper_subscriptions(int sock, int sub_points[], int len,
                                   int flags)
{
    int i;
    int status = CONFD_OK;
    ETERM *term;
    ETERM *tup[2];
    ETERM *list[len];
    for (i=0; i<len; i++) {
        list[i] = erl_mk_int(sub_points[i]);
    }
    tup[0] = erl_mk_list(list, len);
    tup[1] = erl_mk_int(flags);
    term = erl_mk_tuple(tup, 2);
    op_request_term(sock, CDB_OP_TRIGGER_OPER_SUBS, -1, 0, term, &status);
    erl_free_compound(term);
    return status;
}

int cdb_replay_subscriptions(int sock, struct cdb_txid *txid,
                             int sub_points[], int len)
{
    int i;
    int status = CONFD_OK;
    ETERM *req, *local;
    ETERM *ltup[3], *mtup[2], *rtup[2];
    ETERM *list[len];

    /* txid */
    ltup[0] = erl_mk_uint(txid->s1);
    ltup[1] = erl_mk_uint(txid->s2);
    ltup[2] = erl_mk_uint(txid->s3);
    local = erl_mk_tuple(ltup, 3);
    if (txid->master[0] == '\000') {
        rtup[0] = local;
    } else {
        mtup[0] = erl_mk_binary(txid->master, strlen(txid->master));
        mtup[1] = local;
        rtup[0] = erl_mk_tuple(mtup, 2);
    }
    /* subscription points */
    for (i=0; i<len; i++) {
        list[i] = erl_mk_int(sub_points[i]);
    }
    rtup[1] = erl_mk_list(list, len);
    req = erl_mk_tuple(rtup, 2);
    op_request_term(sock, CDB_OP_REPLAY_SUBS, -1, 0, req, &status);
    erl_free_compound(req);
    return status;
}

int cdb_get_replay_txids(int sock, struct cdb_txid **txid, int *resultlen)
{
    ETERM *reply, *list;
    int status, rlen;
    struct cdb_txid *txidl;
    reply =
        op_request_term(sock, CDB_OP_GET_REPLAY_TXID, -1, 0, NULL, &status);
    if (confd_debug_level > CONFD_TRACE && confd_debug_stream) {
        fprintf(confd_debug_stream, "cdb_get_replay_txid() got ");
        erl_print_term(confd_debug_stream, reply);
        fprintf(confd_debug_stream, "\n");
    }
    if (!reply)
        return status;
    for (rlen=0, list=reply; !ERL_IS_NIL(list); rlen++) {
        if (!ERL_IS_CONS(list)) {
            erl_free_compound(reply);
            return confd_internal_error("Internal error, bad value list\n");
        }
        list = ERL_CONS_TAIL(list);
    }
    txidl = (struct cdb_txid *)confd_malloc(sizeof(struct cdb_txid) * rlen);
    if (txidl == NULL) {
        erl_free_compound(reply);
        return CONFD_ERR;
    }
    memset(txidl, 0, sizeof(struct cdb_txid) * rlen);
    *txid = txidl;
    *resultlen = rlen;
    for (list = reply; !ERL_IS_NIL(list); txidl++, list = ERL_CONS_TAIL(list)) {
        ETERM *hd = ERL_CONS_HEAD(list);
        ETERM *timestamp = NULL;

        if (ERL_IS_TUPLE(hd) && (ERL_TUPLE_SIZE(hd) == 2)) {
            ETERM *node = ERL_TUPLE_ELEMENT(hd, 0);
            confd_value_t val;
            if (eterm_to_val(node, &val) == NULL)
                goto error;
            confd_pp_value(txidl->master, MAXHOSTLEN, &val);
            timestamp = ERL_TUPLE_ELEMENT(hd, 1);
        } else if (ERL_IS_TUPLE(hd) && (ERL_TUPLE_SIZE(hd) == 3)) {
            txidl->master[0] = 0;
            timestamp = hd;
        } else {
            confd_internal_error("Internal error, bad transaction id\n");
            goto error;
        }
        txidl->s1 = ERL_INT_VALUE(ERL_TUPLE_ELEMENT(timestamp, 0));
        txidl->s2 = ERL_INT_VALUE(ERL_TUPLE_ELEMENT(timestamp, 1));
        txidl->s3 = ERL_INT_VALUE(ERL_TUPLE_ELEMENT(timestamp, 2));
    }
    erl_free_compound(reply);
    return status;
error:
    erl_free_compound(reply);
    free(*txid);
    *txid = NULL;
    *resultlen = rlen;
    return CONFD_ERR;
}


int cdb_read_subscription_socket(int sock, int sub_points[], int *resultlen)
{
    int status, n=0;
    ETERM *hd, *val, *tl;
    clr_confd_err();
    val = term_read(sock, &status, CDB_OP_SUB_EVENT);
    if (val == NULL) {
        return status;
    }
    tl = ERL_TUPLE_ELEMENT(val, 2);
    while (! ERL_IS_EMPTY_LIST(tl)) {
        hd = ERL_CONS_HEAD(tl);
        tl = ERL_CONS_TAIL(tl);
        sub_points[n++] = ERL_INT_VALUE(hd);
    }
    erl_free_compound(val);
    *resultlen = n;

    if (confd_debug_level >= CONFD_TRACE) {
        int i;
        confd_trace_printf("TRACE CDB_SUBSCRIPTION_EVENT -->");
        for (i=0; i<n; i++) {
            confd_trace_printf(" %d", sub_points[i]);
        }
        confd_trace_printf("\n");
    }

    return CONFD_OK;
}

int cdb_read_subscription_socket2(int sock,
                                  enum cdb_sub_notification *type, int *flags,
                                  int *subpoints[], int *resultlen)
{
    int status, len=0;
    ETERM *val, *hd, *tl;
    clr_confd_err();
    val = term_read(sock, &status, CDB_OP_SUB_EVENT);
    if (val == NULL) {
        return status;
    }
    tl = ERL_TUPLE_ELEMENT(val, 2);
    len = erl_length(tl);

    if (type) { *type = ERL_INT_VALUE(ERL_TUPLE_ELEMENT(val, 0)); }
    if (flags) { *flags = ERL_INT_VALUE(ERL_TUPLE_ELEMENT(val, 1)); }
    if (resultlen) { *resultlen = len; }
    if (subpoints) {
        int n = 0;
        *subpoints = confd_malloc(len * sizeof(**subpoints));
        if (*subpoints == NULL) return CONFD_ERR;
        while (! ERL_IS_EMPTY_LIST(tl)) {
            hd = ERL_CONS_HEAD(tl);
            tl = ERL_CONS_TAIL(tl);
            (*subpoints)[n++] = ERL_INT_VALUE(hd);
        }
    }

    erl_free_compound(val);

    if (confd_debug_level >= CONFD_TRACE) {
        int i;
        confd_trace_printf("TRACE CDB_SUBSCRIPTION_EVENT -->");
        for (i=0; i<len; i++) {
            confd_trace_printf(" %d", (*subpoints)[i]);
        }
        confd_trace_printf("\n");
    }

    return CONFD_OK;
}


int cdb_diff_iterate(int sock, int subid,
                     enum cdb_iter_ret (*iter)(confd_hkeypath_t *kp,
                                               enum cdb_iter_op op,
                                               confd_value_t *oldv,
                                               confd_value_t *newv,
                                               void *state),
                     int flags,
                     void *initstate)
{
    int ret;
    char xbuf[4];

    if ((flags & ITER_WANT_SCHEMA_ORDER &&
         flags & ITER_WANT_LEAF_FIRST_ORDER) ||
        (flags & ITER_WANT_SCHEMA_ORDER && flags & ITER_WANT_LEAF_LAST_ORDER) ||
        (flags & ITER_WANT_LEAF_FIRST_ORDER &&
         flags & ITER_WANT_LEAF_LAST_ORDER))
        return ret_err(CONFD_ERR_PROTOUSAGE,"Ambigous iteration order (%d)\n",
                       flags);

    put_int32(flags, xbuf);
    ret = op_write_buf(sock, CDB_OP_SUB_ITERATE, xbuf, 4, subid);

    if (confd_debug_level >= CONFD_TRACE) {
        confd_trace_printf("TRACE CDB_SUB_ITERATE %d\n", subid);
    }

    if (ret == CONFD_OK) {
        return _confd_iterate(sock, 1, iter, initstate);
    } else {
        return ret;
    }
}

int cdb_cli_diff_iterate(int sock, int subid, cli_diff_iter_function_t *iter,
                         int flags, void *initstate)
{
    int ret;
    char xbuf[4];

    flags |= ITER_WANT_CLI_STR;
    put_int32(flags, xbuf);
    ret = op_write_buf(sock, CDB_OP_SUB_ITERATE, xbuf, 4, subid);

    if (confd_debug_level >= CONFD_TRACE) {
        confd_trace_printf("TRACE CDB_CLI_SUB_ITERATE %d\n", subid);
    }

    if (ret == CONFD_OK) {
        return _confd_iterate(sock, 1, iter, initstate);
    } else {
        return ret;
    }
}

int cdb_diff_iterate_resume(int sock, enum cdb_iter_ret reply,
                            enum cdb_iter_ret (*iter)(confd_hkeypath_t *kp,
                                                      enum cdb_iter_op op,
                                                      confd_value_t *oldv,
                                                      confd_value_t *newv,
                                                      void *state),
                            void *resumestate)
{
    int ret;

    if (reply == ITER_SUSPEND) {
        return CONFD_OK;
    }

    ret = _confd_iterate_send_reply(sock, reply);

    if (confd_debug_level >= CONFD_TRACE) {
        confd_trace_printf("TRACE CDB_SUB_ITERATE_RESUME\n");
    }

    if ((ret == CONFD_OK) && (reply != ITER_STOP)) {
        return _confd_iterate(sock, 1, iter, resumestate);
    } else {
        return ret;
    }
}



struct itermatch {
    struct xml_tag *tags;
    int taglen;
    int retval;
};


static enum cdb_iter_ret iter(confd_hkeypath_t *hkp,
                              enum cdb_iter_op op,
                              confd_value_t *oldv,
                              confd_value_t *newv,
                              void *state)
{
    struct itermatch *im = (struct itermatch*)state;
    int match = confd_hkp_tagmatch(im->tags, im->taglen, hkp);

    if (match & CONFD_HKP_MATCH_TAGS) {
        im->retval = 1;
        return ITER_STOP;
    }
    if (match & CONFD_HKP_MATCH_HKP) {
        return ITER_RECURSE;
    }
    return ITER_CONTINUE;
}



int cdb_diff_match(int sock, int subid,
                   struct xml_tag tags[], int tagslen)
{
    int ret;
    struct itermatch state = {tags, tagslen, 0};
    if ((ret = cdb_diff_iterate(sock, subid, iter, 0, &state)) != CONFD_OK)
        return ret;
    return state.retval;
}


int cdb_vget_modifications(int s, int subid, int flags,
                           confd_tag_value_t **values, int *nvalues,
                           const char *fmt, va_list args)
{
    int isrel, ret, n;
    ETERM *epath, *t[3], *req, *reply;

    clr_confd_err();
    epath = parse_path(&isrel, fmt, args);
    if (!epath) return ret_err(CONFD_ERR_BADPATH, "Bad path <%s>", fmt);
    t[0] = erl_mk_int(subid);
    t[1] = erl_mk_int(flags);
    t[2] = epath;
    req = erl_mk_tuple(t, 3);
    reply = op_request_term(s, CDB_OP_GET_MODIFICATIONS, -1, isrel, req, &ret);
    erl_free_compound(req);
    if (reply == NULL) {
        return ret;
    }
    if (ret == CONFD_OK) {
        ETERM *list = reply;
        if ((n = erl_length(list)) >= 0) {
            confd_tag_value_t *tmp = confd_malloc(n * sizeof(*tmp));
            if (tmp != NULL) {
                int i;
                for (i=0; i<n; i++, list = ERL_CONS_TAIL(list)) {
                    if ((eterm_to_tag_val(ERL_CONS_HEAD(list), &tmp[i])
                         == NULL) ||
                        (confd_dup_value(CONFD_GET_TAG_VALUE(&tmp[i]))
                         == CONFD_ERR))
                    {
                        for (i--; i>= 0; i--) {
                            confd_free_value(CONFD_GET_TAG_VALUE(&tmp[i]));
                        }
                        ret = CONFD_ERR;
                        break;
                    }
                }
                if (ret == CONFD_OK) {
                    *values = tmp;
                    *nvalues = n;
                } else {
                    free(tmp);
                }
            } else {
                ret = CONFD_ERR;
            }
        } else {
            ret = confd_internal_error("Internal error\n");
        }
    }
    erl_free_compound(reply);
    return ret;
}

int cdb_get_modifications(int s, int subid, int flags,
                          confd_tag_value_t **values, int *nvalues,
                          const char *fmt, ...)
{
    int ret;
    va_list args;

    va_start(args,fmt);
    ret = cdb_vget_modifications(s, subid, flags, values, nvalues, fmt, args);
    va_end(args);

    return ret;
}

int cdb_get_modifications_iter(int sock, int flags,
                               confd_tag_value_t **values, int *nvalues)
{
    return cdb_get_modifications(sock, 0, flags, values, nvalues, NULL);
}

int cdb_get_modifications_cli(int sock, int subid, int flags, char **str)
{
    int status = CONFD_OK;
    ETERM *result, *arg, *t[2];

    t[0] = erl_mk_int(subid);
    t[1] = erl_mk_int(flags);
    arg = erl_mk_tuple(t, 2);
    result = op_request_term(sock, CDB_OP_GET_CLI, -1, 0, arg, &status);
    erl_free_compound(arg);
    if ((status == CONFD_OK) && result && ERL_IS_BINARY(result)) {
        int len = ERL_BIN_SIZE(result);
        char *tmp = (char *)malloc((size_t)(len+1));
        if (tmp) {
            memcpy(tmp, ERL_BIN_PTR(result), (size_t)(len + 1));
            *(tmp + len) = '\000';
            *str = tmp;
        } else {
            status = ret_err(CONFD_ERR_MALLOC, "Cannot allocate");
        }
    } else {
        if (status == CONFD_OK) {
            status = confd_internal_error("Internal error\n");
        }
    }
    if (result) {
        erl_free_compound(result);
    }
    return status;
}

int cdb_sync_subscription_socket(int sock, enum cdb_subscription_sync_type st)
{
    int status;
    ETERM *arg = erl_mk_int(st);
    op_request_term(sock, CDB_OP_SYNC_SUB, -1, 0, arg, &status);
    erl_free_compound(arg);
    return status;
}

int cdb_sub_vprogress(int sock, const char *fmt, va_list args)
{
    char buf[BUFSIZ];
    ETERM *arg;
    int status, len;

    len = 0; buf[0] = '\000';
    if (fmt != NULL) {
        len = vsnprintf(buf, sizeof(buf), fmt, args);
    }
    arg = erl_mk_binary(buf, (len > sizeof(buf)) ? (int)sizeof(buf) : len);
    op_request_term(sock, CDB_OP_SUB_PROGRESS, -1, 0, arg, &status);
    erl_free_compound(arg);
    return status;
}

int cdb_sub_progress(int sock, const char *fmt, ...)
{
    int ret;
    va_list args;

    va_start(args, fmt);
    ret = cdb_sub_vprogress(sock, fmt, args);
    va_end(args);
    return ret;
}

static int do_abort_trans(int sock, enum confd_errcode code,
                          u_int32_t apptag_ns, u_int32_t apptag_tag,
                          const confd_tag_value_t *error_info, int n,
                          const char *fmt, va_list args)
{
    int status;
    ETERM *arg;
    ETERM *tup[2];
    struct confd_error err;

    memset(&err, 0, sizeof(err));
    err.code = CONFD_ERRCODE_APPLICATION;

    if ((status = _confd_vset_error(&err, code, apptag_ns, apptag_tag,
                                    error_info, n, 0, fmt, args)) != CONFD_OK) {
        return status;
    }

    tup[0] = erl_mk_int(5);
    tup[1] = _confd_make_error(&err);

    if ((tup[1] == NULL) || ((arg = erl_mk_tuple(tup, 2)) == NULL)) {
        return ret_err(CONFD_ERR_MALLOC, "Cannot allocate");
    }

    op_request_term(sock, CDB_OP_SYNC_SUB, -1, 0, arg, &status);

    erl_free_compound(arg);

    return status;
}

int cdb_sub_abort_trans(int sock, enum confd_errcode code,
                        u_int32_t apptag_ns, u_int32_t apptag_tag,
                        const char *fmt, ...)
{
    va_list args;
    int ret;

    va_start(args, fmt);
    ret = do_abort_trans(sock, code, apptag_ns, apptag_tag, NULL, 0, fmt, args);
    va_end(args);
    return ret;
}

int cdb_sub_abort_trans_info(int sock, enum confd_errcode code,
                             u_int32_t apptag_ns, u_int32_t apptag_tag,
                             const confd_tag_value_t *error_info, int n,
                             const char *fmt, ...)
{
    va_list args;
    int ret;

    va_start(args, fmt);
    ret = do_abort_trans(sock, code, apptag_ns, apptag_tag,
                         error_info, n, fmt, args);
    va_end(args);
    return ret;
}

int cdb_initiate_journal_compaction(int sock)
{
    int status = CONFD_OK;
    op_request_term(sock, CDB_OP_INITIATE_COMPACTION, -1, 0, NULL, &status);
    return status;
}

#define check_type(X, _type) { \
    if (v.type == _type) { \
        *rval = X(&v); \
        return CONFD_OK; }\
    else { \
        confd_set_errno(CONFD_ERR_BADTYPE); \
        confd_set_lasterr("Returned type is not " #_type); \
        confd_trace(CONFD_DEBUG, \
             "Type error, returned type is not " #_type);\
        return CONFD_ERR; }}

#define mget(X, _type) {  \
    confd_value_t v; \
    int ret; \
    va_list args; \
    va_start(args,fmt); \
    if ((ret = cdb_vget(sock, &v, fmt, args)) != CONFD_OK) \
        {va_end(args); return ret;} \
    va_end(args); \
    check_type(X, _type)}

#define vmget(X, _type) {  \
    confd_value_t v; \
    int ret; \
    if ((ret = cdb_vget(sock, &v, fmt, args)) != CONFD_OK) \
        {return ret;} \
    check_type(X, _type)}


int cdb_get_list(int sock, confd_value_t **values, int *n, const char *fmt, ...)
{
    int ret;
    va_list args;

    va_start(args,fmt);
    ret = cdb_vget_list(sock, values, n, fmt, args);
    va_end(args);
    return ret;
}

int cdb_vget_list(int sock, confd_value_t **values, int *n,
                  const char *fmt, va_list args)
{
    confd_value_t v;
    int ret;

    if ((ret = cdb_vget(sock, &v, fmt, args)) != CONFD_OK)
        return ret;
    if (v.type == C_LIST) {
        *values = CONFD_GET_LIST(&v);
        *n = CONFD_GET_LISTSIZE(&v);
        return CONFD_OK; }
    else {
        confd_set_errno(CONFD_ERR_BADTYPE);
        confd_set_lasterr("Returned type is not C_LIST");
        confd_trace(CONFD_DEBUG, "Type error, returned type is not C_LIST\n");
        return CONFD_ERR;
    }
}


int cdb_get_int8(int sock, int8_t *rval, const char *fmt, ...)
{    mget(CONFD_GET_INT8, C_INT8) }

int cdb_vget_int8(int sock, int8_t *rval, const char *fmt, va_list args)
{    vmget(CONFD_GET_INT8, C_INT8) }

int cdb_get_int16(int sock, int16_t *rval, const char *fmt, ...)
{    mget(CONFD_GET_INT16, C_INT16) }

int cdb_vget_int16(int sock, int16_t *rval, const char *fmt, va_list args)
{    vmget(CONFD_GET_INT16, C_INT16) }

int cdb_get_int32(int sock, int32_t *rval, const char *fmt, ...)
{    mget(CONFD_GET_INT32, C_INT32) }

int cdb_vget_int32(int sock, int32_t *rval, const char *fmt, va_list args)
{    vmget(CONFD_GET_INT32, C_INT32) }

int cdb_get_int64(int sock, int64_t *rval, const char *fmt, ...)
{    mget(CONFD_GET_INT64, C_INT64) }

int cdb_vget_int64(int sock, int64_t *rval, const char *fmt, va_list args)
{    vmget(CONFD_GET_INT64, C_INT64) }

int cdb_get_u_int8(int sock, u_int8_t *rval, const char *fmt, ...)
{    mget(CONFD_GET_UINT8, C_UINT8) }

int cdb_vget_u_int8(int sock, u_int8_t *rval, const char *fmt, va_list args)
{    vmget(CONFD_GET_UINT8, C_UINT8) }

int cdb_get_u_int16(int sock, u_int16_t *rval, const char *fmt, ...)
{    mget(CONFD_GET_UINT16, C_UINT16) }

int cdb_vget_u_int16(int sock, u_int16_t *rval, const char *fmt, va_list args)
{    vmget(CONFD_GET_UINT16, C_UINT16) }

int cdb_get_u_int32(int sock, u_int32_t *rval, const char *fmt, ...)
{    mget(CONFD_GET_UINT32, C_UINT32) }

int cdb_vget_u_int32(int sock, u_int32_t *rval, const char *fmt, va_list args)
{    vmget(CONFD_GET_UINT32, C_UINT32) }

int cdb_get_u_int64(int sock, u_int64_t *rval, const char *fmt, ...)
{    mget(CONFD_GET_UINT64, C_UINT64) }

int cdb_vget_u_int64(int sock, u_int64_t *rval, const char *fmt, va_list args)
{    vmget(CONFD_GET_UINT64, C_UINT64) }

int cdb_get_bit32(int sock, u_int32_t *rval, const char *fmt, ...)
{    mget(CONFD_GET_BIT32, C_BIT32) }

int cdb_vget_bit32(int sock, u_int32_t *rval, const char *fmt, va_list args)
{    vmget(CONFD_GET_BIT32, C_BIT32) }

int cdb_get_bit64(int sock, u_int64_t *rval, const char *fmt, ...)
{    mget(CONFD_GET_BIT64, C_BIT64) }

int cdb_vget_bit64(int sock, u_int64_t *rval, const char *fmt, va_list args)
{    vmget(CONFD_GET_BIT64, C_BIT64) }

int cdb_get_ipv4(int sock, struct in_addr *rval, const char *fmt, ...)
{    mget(CONFD_GET_IPV4, C_IPV4) }

int cdb_vget_ipv4(int sock, struct in_addr *rval, const char *fmt, va_list args)
{    vmget(CONFD_GET_IPV4, C_IPV4) }

int cdb_get_ipv6(int sock, struct in6_addr *rval, const char *fmt, ...)
{    mget(CONFD_GET_IPV6, C_IPV6) }

int cdb_vget_ipv6(int sock, struct in6_addr *rval,
                  const char *fmt, va_list args)
{    vmget(CONFD_GET_IPV6, C_IPV6) }

int cdb_get_double(int sock, double *rval, const char *fmt, ...)
{    mget(CONFD_GET_DOUBLE, C_DOUBLE) }

int cdb_vget_double(int sock, double *rval, const char *fmt, va_list args)
{    vmget(CONFD_GET_DOUBLE, C_DOUBLE) }

int cdb_get_bool(int sock, int *rval, const char *fmt, ...)
{    mget(CONFD_GET_BOOL, C_BOOL) }

int cdb_vget_bool(int sock, int *rval, const char *fmt, va_list args)
{    vmget(CONFD_GET_BOOL, C_BOOL) }

int cdb_get_datetime(int sock, struct confd_datetime *rval,
                     const char *fmt, ...)
{    mget(CONFD_GET_DATETIME, C_DATETIME) }

int cdb_vget_datetime(int sock, struct confd_datetime *rval,
                      const char *fmt, va_list args)
{    vmget(CONFD_GET_DATETIME, C_DATETIME) }

int cdb_get_date(int sock, struct confd_date *rval, const char *fmt, ...)
{    mget(CONFD_GET_DATE, C_DATE) }

int cdb_vget_date(int sock, struct confd_date *rval,
                  const char *fmt, va_list args)
{    vmget(CONFD_GET_DATE, C_DATE) }

int cdb_get_time(int sock, struct confd_time *rval, const char *fmt, ...)
{    mget(CONFD_GET_TIME, C_TIME) }

int cdb_vget_time(int sock, struct confd_time *rval,
                  const char *fmt, va_list args)
{    vmget(CONFD_GET_TIME, C_TIME) }

int cdb_get_duration(int sock, struct confd_duration *rval,
                     const char *fmt, ...)
{    mget(CONFD_GET_DURATION, C_DURATION) }

int cdb_vget_duration(int sock, struct confd_duration *rval,
                      const char *fmt, va_list args)
{    vmget(CONFD_GET_DURATION, C_DURATION) }

int cdb_get_enum_value(int sock, int32_t *rval, const char *fmt, ...)
{    mget(CONFD_GET_ENUM_HASH, C_ENUM_HASH) }

int cdb_vget_enum_value(int sock, int32_t *rval, const char *fmt, va_list args)
{    vmget(CONFD_GET_ENUM_HASH, C_ENUM_HASH) }

/* Return a pointer to a malloc()ed confd_hkeypath_t - up to the caller
 * to free (with confd_free_hkeypath()) when done with it */
int cdb_get_objectref(int sock, confd_hkeypath_t **rval, const char *fmt, ...)
{    mget(CONFD_GET_OBJECTREF, C_OBJECTREF) }

int cdb_vget_objectref(int sock, confd_hkeypath_t **rval,
                       const char *fmt, va_list args)
{    vmget(CONFD_GET_OBJECTREF, C_OBJECTREF) }

/* Return a pointer to a malloc()ed confd_snmp_oid - up to the caller
 * to free when done with it */
int cdb_get_oid(int sock, struct confd_snmp_oid **rval, const char *fmt, ...)
{    mget(CONFD_GET_OID, C_OID) }

int cdb_vget_oid(int sock, struct confd_snmp_oid **rval,
                 const char *fmt, va_list args)
{    vmget(CONFD_GET_OID, C_OID) }

int cdb_get_ipv4prefix(int sock, struct confd_ipv4_prefix *rval,
                       const char *fmt, ...)
{    mget(CONFD_GET_IPV4PREFIX, C_IPV4PREFIX) }

int cdb_vget_ipv4prefix(int sock, struct confd_ipv4_prefix *rval,
                        const char *fmt, va_list args)
{    vmget(CONFD_GET_IPV4PREFIX, C_IPV4PREFIX) }

int cdb_get_ipv6prefix(int sock, struct confd_ipv6_prefix *rval,
                       const char *fmt, ...)
{    mget(CONFD_GET_IPV6PREFIX, C_IPV6PREFIX) }

int cdb_vget_ipv6prefix(int sock, struct confd_ipv6_prefix *rval,
                        const char *fmt, va_list args)
{    vmget(CONFD_GET_IPV6PREFIX, C_IPV6PREFIX) }

int cdb_get_decimal64(int sock, struct confd_decimal64 *rval,
                      const char *fmt, ...)
{    mget(CONFD_GET_DECIMAL64, C_DECIMAL64) }

int cdb_vget_decimal64(int sock, struct confd_decimal64 *rval,
                       const char *fmt, va_list args)
{    vmget(CONFD_GET_DECIMAL64, C_DECIMAL64) }

int cdb_get_identityref(int sock, struct confd_identityref *rval,
                        const char *fmt, ...)
{    mget(CONFD_GET_IDENTITYREF, C_IDENTITYREF) }

int cdb_vget_identityref(int sock, struct confd_identityref *rval,
                         const char *fmt, va_list args)
{    vmget(CONFD_GET_IDENTITYREF, C_IDENTITYREF) }

int cdb_get_ipv4_and_plen(int sock, struct confd_ipv4_prefix *rval,
                       const char *fmt, ...)
{    mget(CONFD_GET_IPV4_AND_PLEN, C_IPV4_AND_PLEN) }

int cdb_vget_ipv4_and_plen(int sock, struct confd_ipv4_prefix *rval,
                        const char *fmt, va_list args)
{    vmget(CONFD_GET_IPV4_AND_PLEN, C_IPV4_AND_PLEN) }

int cdb_get_ipv6_and_plen(int sock, struct confd_ipv6_prefix *rval,
                       const char *fmt, ...)
{    mget(CONFD_GET_IPV6_AND_PLEN, C_IPV6_AND_PLEN) }

int cdb_vget_ipv6_and_plen(int sock, struct confd_ipv6_prefix *rval,
                        const char *fmt, va_list args)
{    vmget(CONFD_GET_IPV6_AND_PLEN, C_IPV6_AND_PLEN) }

int cdb_get_dquad(int sock, struct confd_dotted_quad *rval,
                       const char *fmt, ...)
{    mget(CONFD_GET_DQUAD, C_DQUAD) }

int cdb_vget_dquad(int sock, struct confd_dotted_quad *rval,
                        const char *fmt, va_list args)
{    vmget(CONFD_GET_DQUAD, C_DQUAD) }


#define check_buftype(XP, XS, _type) {                  \
    if (v.type == _type) { \
        *rval = XP(&v); \
        *bufsiz = XS(&v); \
        return CONFD_OK; }\
    else { \
        confd_set_errno(CONFD_ERR_BADTYPE); \
        confd_set_lasterr("Returned type is not " #_type); \
        confd_report_err(CONFD_DEBUG, \
             "Type error, returned type is not " #_type);\
        return CONFD_ERR; }}

#define mget_buf(XP, XS, _type) {               \
    confd_value_t v; \
    int ret; \
    va_list args; \
    va_start(args,fmt); \
    ret = cdb_vget(sock, &v, fmt, args);        \
    va_end(args); \
    if (ret != CONFD_OK)                        \
        return ret;                             \
    check_buftype(XP, XS, _type)}

#define vmget_buf(XP, XS, _type) {              \
    confd_value_t v; \
    int ret; \
    ret = cdb_vget(sock, &v, fmt, args);        \
    if (ret != CONFD_OK) \
        return ret; \
    check_buftype(XP, XS, _type)}

/* Return a pointer to a malloc()ed buffer and its size - up to the caller
 * to free buffer when done with it */
int cdb_get_buf(int sock, unsigned char **rval, int *bufsiz,
                const char *fmt, ...)
{    mget_buf(CONFD_GET_BUFPTR, CONFD_GET_BUFSIZE, C_BUF) }

int cdb_vget_buf(int sock, unsigned char **rval, int *bufsiz,
                 const char *fmt, va_list args)
{    vmget_buf(CONFD_GET_BUFPTR, CONFD_GET_BUFSIZE, C_BUF) }


/* Return a pointer to a malloc()ed buffer and its size - up to the caller
 * to free buffer when done with it */
int cdb_get_binary(int sock, unsigned char **rval, int *bufsiz,
                   const char *fmt, ...)
{    mget_buf(CONFD_GET_BINARY_PTR, CONFD_GET_BINARY_SIZE, C_BINARY) }

int cdb_vget_binary(int sock, unsigned char **rval, int *bufsiz,
                    const char *fmt, va_list args)
{    vmget_buf(CONFD_GET_BINARY_PTR, CONFD_GET_BINARY_SIZE, C_BINARY) }


/* Return a pointer to a malloc()ed buffer and its size - up to the caller
 * to free buffer when done with it */
int cdb_get_hexstr(int sock, unsigned char **rval, int *bufsiz,
                   const char *fmt, ...)
{    mget_buf(CONFD_GET_HEXSTR_PTR, CONFD_GET_HEXSTR_SIZE, C_HEXSTR) }

int cdb_vget_hexstr(int sock, unsigned char **rval, int *bufsiz,
                    const char *fmt, va_list args)
{    vmget_buf(CONFD_GET_HEXSTR_PTR, CONFD_GET_HEXSTR_SIZE, C_HEXSTR) }


/* If a buffer returned from cdb_get will fit into *n bytes then copy
 * it into buf. Upon successful return *n is set to the amount of
 * bytes written into buf. */
int cdb_get_buf2(int sock, unsigned char *buf, int *n, const char *fmt, ...)
{
    int ret;
    va_list args;

    va_start(args,fmt);
    ret = cdb_vget_buf2(sock, buf, n, fmt, args);
    va_end(args);
    return ret;
}

int cdb_vget_buf2(int sock, unsigned char *buf, int *n,
                  const char *fmt, va_list args)
{
    confd_value_t v;
    int ret;

    ret = cdb_vget(sock, &v, fmt, args);
    if (ret != CONFD_OK)
        return ret;
    if (v.type != C_BUF) {
        confd_set_errno(CONFD_ERR_BADTYPE);
        confd_set_lasterr("Returned type is not a string");
        confd_trace(CONFD_DEBUG, "Type error, returned type is"
                    " not a string\n");
        return CONFD_ERR;
    }
    if (CONFD_GET_BUFSIZE(&v) > *n) {
        confd_trace(CONFD_DEBUG, "buffer too small in cdb_get_buf2() "
                    "(returned buffer is %d bytes)\n", CONFD_GET_BUFSIZE(&v));
        free(CONFD_GET_BUFPTR(&v));
        return CONFD_ERR;
    }
    memcpy(buf, CONFD_GET_BUFPTR(&v), CONFD_GET_BUFSIZE(&v));
    *n = CONFD_GET_BUFSIZE(&v);
    free(CONFD_GET_BUFPTR(&v));
    return CONFD_OK;
}

/* If a buffer returned from cdb_get could fit into (n-1) bytes then
 * copy it into buf and terminate it with a nul character */
int cdb_get_str(int sock, char *buf, int n, const char *fmt, ...)
{
    int ret;
    va_list args;

    va_start(args,fmt);
    ret = cdb_vget_str(sock, buf, n, fmt, args);
    va_end(args);
    return ret;
}

int cdb_vget_str(int sock, char *buf, int n, const char *fmt, va_list args)
{
    confd_value_t v;
    int ret;

    ret = cdb_vget(sock, &v, fmt, args);
    if (ret != CONFD_OK)
        return ret;
    if (v.type != C_BUF) {
        confd_set_errno(CONFD_ERR_BADTYPE);
        confd_set_lasterr("Returned type is not a string");
        confd_trace(CONFD_DEBUG, "Type error, returned type is"
                    " not a string\n");
        return CONFD_ERR;
    }
    if (CONFD_GET_BUFSIZE(&v) >= n) {
        confd_trace(CONFD_DEBUG, "buffer too small in cdb_get_str() "
                    "(returned buffer is %d bytes)\n", CONFD_GET_BUFSIZE(&v));
        free(CONFD_GET_BUFPTR(&v));
        return CONFD_ERR;
    }
    memcpy(buf, CONFD_GET_BUFPTR(&v), CONFD_GET_BUFSIZE(&v));
    buf[CONFD_GET_BUFSIZE(&v)] = 0;
    free(CONFD_GET_BUFPTR(&v));
    return CONFD_OK;
}


int cdb_get_qname(int sock,
                  unsigned char **prefix, int *prefixsz,
                  unsigned char **name, int *namesz,
                  const char *fmt, ...)
{
    int ret;
    va_list args;

    va_start(args,fmt);
    ret = cdb_vget_qname(sock, prefix, prefixsz, name, namesz, fmt, args);
    va_end(args);
    return ret;
}

int cdb_vget_qname(int sock,
                   unsigned char **prefix, int *prefixsz,
                   unsigned char **name, int *namesz,
                   const char *fmt, va_list args)
{
    confd_value_t v;
    int ret;

    ret = cdb_vget(sock, &v, fmt, args);
    if (ret != CONFD_OK)
        return ret;
    *prefix = CONFD_GET_QNAME_PREFIX_PTR(&v);
    *name = CONFD_GET_QNAME_NAME_PTR(&v);
    *prefixsz = CONFD_GET_QNAME_PREFIX_SIZE(&v);
    *namesz = CONFD_GET_QNAME_NAME_SIZE(&v);
    return CONFD_OK;
}

static int get_object(ETERM *list, confd_value_t *values, int n)
{
    int len, i;

    len = etermlist_to_vals(list, values, n);
    if (len == CONFD_ERR)
        return CONFD_ERR;
    if (n > len)
        n = len;
    for (i = 0; i < n; i++) {
        if (confd_dup_value(&values[i]) != CONFD_OK)
            return CONFD_ERR;
    }
    return len;
}

int cdb_get_object(int sock, confd_value_t *values, int n,
                   const char *fmt, ...)
{
    int ret;
    va_list args;

    va_start(args, fmt);
    ret = cdb_vget_object(sock, values, n, fmt, args);
    va_end(args);
    return ret;
}

int cdb_vget_object(int sock, confd_value_t *values, int n,
                    const char *fmt, va_list args)
{
    int isrel;
    ETERM *epath;
    ETERM *result;
    int status;

    clr_confd_err();
    epath = parse_path(&isrel, fmt, args);
    if (epath == NULL)
        return ret_err(CONFD_ERR_BADPATH,"Bad path <%s>", fmt);
    result =
        op_request_term(sock, CDB_OP_GET_OBJECT, -1, isrel, epath, &status);
    erl_free_compound(epath);
    if (result == NULL)
        return status;
    status = get_object(result, values, n);
    erl_free_compound(result);
    return status;
}

int cdb_get_objects(int sock, confd_value_t *values, int n, int ix, int nobj,
                    const char *fmt, ...)
{
    int ret;
    va_list args;

    va_start(args, fmt);
    ret = cdb_vget_objects(sock, values, n, ix, nobj, fmt, args);
    va_end(args);
    return ret;
}

int cdb_vget_objects(int sock, confd_value_t *values, int n, int ix, int nobj,
                    const char *fmt, va_list args)
{
    int isrel;
    ETERM *tup[3];
    ETERM *req;
    ETERM *result, *list;
    int status, i, ret;

    clr_confd_err();
    tup[0] = parse_path(&isrel, fmt, args);
    if (tup[0] == NULL)
        return ret_err(CONFD_ERR_BADPATH, "Bad path <%s>", fmt);
    tup[1] = erl_mk_int(ix);
    tup[2] = erl_mk_int(nobj);
    req = erl_mk_tuple(tup, 3);
    result = op_request_term(sock, CDB_OP_GET_OBJECTS, -1, isrel, req, &status);
    erl_free_compound(req);
    if (result == NULL)
        return status;
    list = result;
    for (i = 0; i < nobj && status != CONFD_ERR; i++) {
        if (!ERL_IS_CONS(list))
            return confd_internal_error("Internal error, bad object list\n");
        ret = get_object(ERL_CONS_HEAD(list), &values[i*n], n);
        if (ret == CONFD_ERR || ret > status)
            status = ret;
        list = ERL_CONS_TAIL(list);
    }
    erl_free_compound(result);
    return status;
}

static int set_value(void *valp, confd_value_t *v)
{
    switch (v->type) {
    case C_STR:
        *(char **)valp = v->val.s; break;
    case C_BUF:
    case C_BINARY:
    case C_HEXSTR:
        *(confd_buf_t *)valp = v->val.buf; break;
    case C_DOUBLE:
        *(double *)valp = v->val.d; break;
    case C_IPV4:
        *(struct in_addr *)valp = v->val.ip; break;
    case C_IPV6:
        *(struct in6_addr *)valp = v->val.ip6; break;
    case C_INT8:
        *(int8_t *)valp = v->val.i8; break;
    case C_INT16:
        *(int16_t *)valp = v->val.i16; break;
    case C_INT32:
        *(int32_t *)valp = v->val.i32; break;
    case C_INT64:
        *(int64_t *)valp = v->val.i64; break;
    case C_UINT8:
        *(u_int8_t *)valp = v->val.u8; break;
    case C_UINT16:
        *(u_int16_t *)valp = v->val.u16; break;
    case C_UINT32:
        *(u_int32_t *)valp = v->val.u32; break;
    case C_UINT64:
        *(u_int64_t *)valp = v->val.u64; break;
    case C_BOOL:
        *(int *)valp = v->val.boolean; break;
    case C_QNAME:
        *(struct confd_qname *)valp = v->val.qname; break;
    case C_DATETIME:
        *(struct confd_datetime *)valp = v->val.datetime; break;
    case C_DATE:
        *(struct confd_date *)valp = v->val.date; break;
    case C_TIME:
        *(struct confd_time *)valp = v->val.time; break;
    case C_DURATION:
        *(struct confd_duration *)valp = v->val.duration; break;
    case C_ENUM_HASH:
        *(int32_t *)valp = v->val.enumhash; break;
    case C_BIT32:
        *(u_int32_t *)valp = v->val.b32; break;
    case C_BIT64:
        *(u_int64_t *)valp = v->val.b64; break;
    case C_LIST:
        *(struct confd_list *)valp = v->val.list; break;
    case C_XMLTAG:
    case C_XMLBEGIN:
    case C_XMLEND:
        *(struct xml_tag *)valp = v->val.xmltag; break;
    case C_OBJECTREF:
        *(struct confd_hkeypath **)valp = v->val.hkp; break;
    case C_OID:
        *(struct confd_snmp_oid **)valp = v->val.oidp; break;
    case C_IPV4PREFIX:
        *(struct confd_ipv4_prefix *)valp = v->val.ipv4prefix; break;
    case C_IPV6PREFIX:
        *(struct confd_ipv6_prefix *)valp = v->val.ipv6prefix; break;
    case C_DECIMAL64:
        *(struct confd_decimal64 *)valp = v->val.d64; break;
    case C_IDENTITYREF:
        *(struct confd_identityref *)valp = v->val.idref; break;
    case C_IPV4_AND_PLEN:
        *(struct confd_ipv4_prefix *)valp = v->val.ipv4prefix; break;
    case C_IPV6_AND_PLEN:
        *(struct confd_ipv6_prefix *)valp = v->val.ipv6prefix; break;
    case C_DQUAD:
        *(struct confd_dotted_quad *)valp = v->val.dquad; break;
    case C_DEFAULT:
        break;
    case C_SYMBOL:
    case C_UNION:
    case C_PTR:
    case C_NOEXISTS:
    case C_CDBBEGIN:
    case C_XMLBEGINDEL:
    case C_MAXTYPE:
        /* These are all "can't happen" */
        return 0;
    }
    return 1;
}


int cdb_get_values(int sock, confd_tag_value_t *values, int n,
                   const char *fmt, ...)
{
    int ret;
    va_list args;

    va_start(args, fmt);
    ret = cdb_vget_values(sock, values, n, fmt, args);
    va_end(args);
    return ret;
}

int cdb_vget_values(int sock, confd_tag_value_t *values, int n,
                    const char *fmt, va_list args)
{
    int isrel;
    ETERM *epath;
    ETERM *tup[2];
    ETERM *req, *result;
    ETERM *list;
    int status, i;
    confd_value_t *want_vp;
    confd_tag_value_t tv;
    confd_value_t *got_vp = CONFD_GET_TAG_VALUE(&tv);

    clr_confd_err();
    epath = parse_path(&isrel, fmt, args);
    if (epath == NULL)
        return ret_err(CONFD_ERR_BADPATH, "Bad path <%s>", fmt);
    if ((tup[0] = tag_vals_to_termlist(values, n, 0)) == NULL) {
        erl_free_compound(epath);
        return CONFD_ERR;
    }
    tup[1] = epath;
    req = erl_mk_tuple(tup, 2);
    result = op_request_term(sock, CDB_OP_GET_VALUES, -1, isrel, req, &status);
    erl_free_compound(req);
    if (result == NULL)
        return status;
    /* Can't use etermlist_to_tag_vals() here */
    list = result;
    for (i = 0; i < n; i++) {
        if (!ERL_IS_CONS(list)) {
            erl_free_compound(result);
            return confd_internal_error(
                "Internal error, bad tag value list\n");
        }
        want_vp = CONFD_GET_TAG_VALUE(&values[i]);
        if (want_vp->type == C_NOEXISTS || want_vp->type == C_PTR ||
            want_vp->type == C_XMLBEGIN || want_vp->type == C_XMLEND) {
            if (eterm_to_tag_val(ERL_CONS_HEAD(list), &tv) == NULL ||
                confd_dup_value(got_vp) == CONFD_ERR) {
                erl_free_compound(result);
                return CONFD_ERR;
            }
            switch (want_vp->type) {
            case C_PTR:
                if (got_vp->type != C_NOEXISTS) {
                    if (CONFD_GET_PTR_TYPE(want_vp) != got_vp->type) {
                        erl_free_compound(result);
                        confd_free_value(got_vp);
                        return ret_err(CONFD_ERR_BADTYPE,
                                       "Returned type %d is wrong "
                                       "for element %d", got_vp->type, i);
                    }
                    if (!set_value(CONFD_GET_PTR_VALP(want_vp), got_vp))
                        return confd_internal_error(
                            "Internal error, bad type for tag-value\n");
                }
                break;
            case C_XMLBEGIN:
            case C_XMLEND:
                /* special case: non-existing optional container */
                if (got_vp->type == C_NOEXISTS)
                    want_vp->type = C_NOEXISTS;
                break;
            default:
                *want_vp = *got_vp;
            }
        }
        list = ERL_CONS_TAIL(list);
    }
    if (!ERL_IS_NIL(list))
        return confd_internal_error(
            "Internal error, too many elems in tag value list\n");
    erl_free_compound(result);
    return status;
}


static int vcdb_set(int sock, int op, ETERM *arg,
                    const char *fmt, va_list args)
{
    int status, isrel;
    ETERM *req;
    ETERM *tup[2];
    ETERM *epath = parse_path(&isrel, fmt, args);

    if (epath == NULL) {
        erl_free_compound(arg);
        return ret_err(CONFD_ERR_BADPATH, "Bad path <%s>", fmt);
    }
    tup[0] = arg;
    tup[1] = epath;
    req = erl_mk_tuple(tup, 2);
    op_request_term(sock, op, -1, isrel, req, &status);
    erl_free_compound(req);
    return status;
}


int cdb_set_elem(int sock, confd_value_t *val, const char *fmt, ...)
{
    va_list args;
    int ret;

    va_start(args, fmt);
    ret = cdb_vset_elem(sock, val, fmt, args);
    va_end(args);
    return ret;
}

int cdb_vset_elem(int sock, confd_value_t *val, const char *fmt, va_list args)
{
    ETERM *arg;

    if ((arg = val_to_term(val)) == NULL)
        return CONFD_ERR;
    return vcdb_set(sock, CDB_OP_SET_ELEM, arg, fmt, args);
}

int cdb_set_elem2(int sock, const char *strval, const char *fmt, ...)
{
    int ret;
    va_list args;

    va_start(args, fmt);
    ret = cdb_vset_elem2(sock, strval, fmt, args);
    va_end(args);
    return ret;
}

int cdb_vset_elem2(int sock, const char *strval, const char *fmt, va_list args)
{
    ETERM *arg;

    if ((arg = erl_mk_binary(strval, strlen(strval))) == NULL)
        return ret_err(CONFD_ERR_MALLOC, "Cannot allocate");
    return vcdb_set(sock, CDB_OP_SET_ELEM2, arg, fmt, args);
}

int cdb_set_case(int sock, const char *choice, const char *scase,
                 const char *fmt, ...)
{
    int ret;
    va_list args;

    va_start(args, fmt);
    ret = cdb_vset_case(sock, choice, scase, fmt, args);
    va_end(args);
    return ret;
}

int cdb_vset_case(int sock, const char *choice, const char *scase,
                  const char *fmt, va_list args)
{
    ETERM *echoice;
    ETERM *ecase;
    ETERM *tup[2];
    ETERM *req;

    if ((echoice = _confd_parse_choice_path(choice)) == NULL)
        return CONFD_ERR;

    if ((ecase = mk_tag_elem2(scase != NULL ? scase : "")) == NULL)
        return ret_err(CONFD_ERR_MALLOC, "Cannot allocate");

    tup[0] = echoice;
    tup[1] = ecase;
    req = erl_mk_tuple(tup, 2);

    return vcdb_set(sock, CDB_OP_SET_CASE, req, fmt, args);
}

int cdb_create(int sock, const char *fmt, ...)
{
    int ret;
    va_list args;

    va_start(args,fmt);
    ret = fmt_request(sock, CDB_OP_CREATE, -1, fmt, args);
    va_end(args);
    return ret;
}

int cdb_vcreate(int sock, const char *fmt, va_list args)
{
    return fmt_request(sock, CDB_OP_CREATE, -1, fmt, args);
}

int cdb_delete(int sock, const char *fmt, ...)
{
    int ret;
    va_list args;

    va_start(args,fmt);
    ret = fmt_request(sock, CDB_OP_DELETE, -1, fmt, args);
    va_end(args);
    return ret;
}

int cdb_vdelete(int sock, const char *fmt, va_list args)
{
    return fmt_request(sock, CDB_OP_DELETE, -1, fmt, args);
}

int cdb_set_object(int sock, const confd_value_t *values, int n,
                   const char *fmt, ...)
{
    int ret;
    va_list args;

    va_start(args, fmt);
    ret = cdb_vset_object(sock, values, n, fmt, args);
    va_end(args);
    return ret;
}

int cdb_vset_object(int sock, const confd_value_t *values, int n,
                    const char *fmt, va_list args)
{
    ETERM *arg;

    if ((arg = vals_to_termlist(values, n, 0)) == NULL)
        return CONFD_ERR;
    return vcdb_set(sock, CDB_OP_SET_OBJECT, arg, fmt, args);
}

int cdb_set_values(int sock, const confd_tag_value_t *values, int n,
                   const char *fmt, ...)
{
    int ret;
    va_list args;

    va_start(args, fmt);
    ret = cdb_vset_values(sock, values, n, fmt, args);
    va_end(args);
    return ret;
}

int cdb_vset_values(int sock, const confd_tag_value_t *values, int n,
                    const char *fmt, va_list args)
{
    ETERM *arg;

    if ((arg = tag_vals_to_termlist(values, n, 0)) == NULL)
        return CONFD_ERR;
    return vcdb_set(sock, CDB_OP_SET_VALUES, arg, fmt, args);
}
